﻿function onCreate()
	
	makeLuaSprite('salon', 'zero/SnowMemory', -340, -220); 
	setLuaSpriteScrollFactor('salon', 1.0, 1.0);
	scaleObject('salon', 0.9, 0.9);
 
        makeAnimatedLuaSprite('BottomBoppers_Right', 'zero/BottomBoppers_Right', 1500, 460);
	setLuaSpriteScrollFactor('BottomBoppers_Right', 1.5 , 1.5);
	scaleObject('BottomBoppers_Right', 1.6, 1.6)

        makeAnimatedLuaSprite('BottomBoppers_Left', 'zero/BottomBoppers_Left', -380, 600);
	setLuaSpriteScrollFactor('BottomBoppers_Left', 1.5 , 1.5);
	scaleObject('BottomBoppers_Left', 1.6, 1.6)



	makeLuaSprite('sillas', 'zero/SnowFront', -400, -480);     setLuaSpriteScrollFactor('sillas', 1.0, 1.0);
	scaleObject('sillas', 1.0, 1.0);
	

	addLuaSprite('bodega', false);
	addLuaSprite('salon', false);
    addLuaSprite('BottomBoppers_Right', true);
    addAnimationByPrefix('BottomBoppers_Right','idle','Bottom Level Boppers Right',24, false);
    addLuaSprite('BottomBoppers_Left', true);
    addAnimationByPrefix('BottomBoppers_Left','idle','Bottom Level Boppers Left',24, false);
    addLuaSprite('sillas', true);

end

function onEvent(name,value1,value2)
	if name == 'Play Animation' then 
		
		if value1 == 'normalbaka' then
    setProperty('baka.visible', true);
    setProperty('baka2.visible', false);

		end
		
		if value1 == 'rockbaka' then
    setProperty('baka.visible', false);
    setProperty('baka2.visible', true);

		end

		if value1 == 'nobaka' then
    setProperty('baka.visible', false);
    setProperty('baka2.visible', false);

		end

	end
end

function onBeatHit()
	if curBeat % 2== 0 then
		objectPlayAnimation('BottomBoppers_Right', 'idle', false);
		objectPlayAnimation('BottomBoppers_Left', 'idle', false);
	end
	end
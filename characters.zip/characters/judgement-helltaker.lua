isInAir = false
function onCreate()
	playAnim('gf', 'prejump', true)
	--setProperty('gf.visible', false)
	setProperty('gf.x', getProperty('gf.x'))
	setProperty('gf.y', getProperty('gf.y') - 104)
end
function onCountdownTick(counter)
	if counter == 0 then
		playAnim('gf', 'jump', true)
	end
	if counter == 2 then
		isInAir = false
		playAnim('gf', 'jump2', true)
	end
end

function onUpdate(elapsed)
	if isInAir then
		playAnim('gf', 'prejump', true)
	end
	if getProperty('gf.animation.curAnim.name') == 'jump' and getProperty('dad.animation.curAnim.finished') then
		isInAir = true
	end
	if getProperty('gf.animation.curAnim.name') == 'jump2' and getProperty('dad.animation.curAnim.finished') then
		playAnim('gf', 'idle', true)
	end
end
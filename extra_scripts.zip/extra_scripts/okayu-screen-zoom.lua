function onSectionHit()
	if mustHitSection then
		setProperty('defaultCamZoom', 0.8)
	elseif not mustHitSection then
		setProperty('defaultCamZoom', 1.25)
	end
end
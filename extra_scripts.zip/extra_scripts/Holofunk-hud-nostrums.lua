
function onCreate()
    addHaxeLibrary('ClientPrefs')
    --to change the ui, simply just change the string based the ui name
    -- example: myth
    -- fantasy or myth
    createUI('myth')

end

function onCreatePost()
    checkCharacter()

    setProperty('timeBarBG.color', getColorFromHex'ffffff')    
    setProperty('camZoomingMult',1.2)
    setProperty('camZoomingDecay',2)

    setTextFont('timeTxt', fontName)
    setTextSize('timeTxt', 27)

    scaleObject('timeBarBG', 1.07, 1)
    setProperty('timeBarBG.visible', false)
    scaleObject('timeBar', 1.255, 1)
    --setProperty('timeBar.visible', false)
    scaleObject('healthBar', 1.05, 1)
    scaleObject('healthBarBG', 1.05, 1)
    runHaxeCode([[
        game.healthBar.visible = false;
        game.scoreTxt.visible = false;
        game.healthBarBG.destroy();


    
    

        //game.timeBar.offset.x -= 2;
        //game.timeBar.offset.y -= 3;
        game.timeBar.x -= 44;
        game.timeBar.y += (ClientPrefs.downScroll ? 7 : -12);
        game.timeTxt.y += (ClientPrefs.downScroll ? 7 : -12);
        game.healthBar.x -= 18;
        game.healthBar.visible = false;
    ]])
    
end

function onUpdatePost(e)

	setProperty('UI_Health_LEFT._frame.frame.width', 35 + (math.lerp(700, 0, getProperty('health')/2)))
    setTextString('timeTxt', '('..formatTime(songLength - (getSongPosition() - noteOffset))..')')
    runHaxeCode("for (sp in game.grpNoteSplashes) sp.cameras = [strumHUD]")
    setProperty('strumHUD.zoom',getProperty('camHUD.zoom'))
    setProperty('strumHUD.x',getProperty('camHUD.x'))
    setProperty('strumHUD.y',getProperty('camHUD.y'))
    setProperty('strumHUD.alpha',getProperty('camHUD.alpha'))
    setProperty('UI_Time_Bar.alpha',getProperty('timeBarBG.alpha'))

end
function onUpdateScore()
    setTextString('UI_Score_Txt', score)
    setTextString('UI_Breaks_Txt', misses)
    if score > 0 then
        setTextString('UI_Accuracy_Txt', round((getProperty('ratingPercent') * 100), 2) ..'%')
        setTextString('UI_Rank_Txt', score > 0 and ratingFC or 'Clear')
    end
end
function goodNoteHit(id,dir,nt,sus)
    runHaxeCode([[
        for (n in game.notes) if (!n.isSustainNote) for (sus in n.tail) sus.blockHit = false;
    ]])
    if not sus then
        pulse('ffffff')
    end
end
function noteMiss(id,dir,nt,sus)
    if not sus then
        pulse('ff0000')
    end
    if sus then
        runHaxeCode([[
            var tail = game.notes.members[]]..id..[[].parent.tail;
            for (note in tail) {
                note.blockHit = true;
                note.ignoreNote = true;
                note.alpha = 0.2;
                note.copyAlpha = false;
            }
        ]])
    else
        runHaxeCode([[
            var tail = game.notes.members[]]..id..[[].tail;
            for (note in tail){
                note.blockHit = true;
                note.ignoreNote = true;
            }
        ]])
    end
end
function onEvent(n,v1,v2)
    if n == 'Change Character' then
        checkCharacter()
    end
end
--- functions
function createUI(uitype)
    local ui_x, ui_y = 0, (downscroll and 55 or 610)
    if uitype == 'myth' then
        ui = 'holofunk_UI/'
        fontName = 'Montserrat.ttf'
    elseif uitype == 'fantasy' then
        ui = 'ui/fantasy/'
        fontName = 'Krungthep.ttf'
    end

    makeLuaSprite('UI_Health_RIGHT', ui..'health_Bar', ui_x, ui_y+1)
    screenCenter('UI_Health_RIGHT', 'x')
    setObjectCamera('UI_Health_RIGHT', 'camHUD')
    addLuaSprite('UI_Health_RIGHT')

    makeLuaSprite('UI_Health_LEFT', ui..'health_Bar', ui_x, ui_y+1)
    screenCenter('UI_Health_LEFT', 'x')
    setObjectCamera('UI_Health_LEFT', 'camHUD')
    addLuaSprite('UI_Health_LEFT')

    makeLuaSprite('UI_Health_Frame', ui..'health_border', ui_x, ui_y)
    screenCenter('UI_Health_Frame', 'x')
    setObjectCamera('UI_Health_Frame', 'camHUD')
    addLuaSprite('UI_Health_Frame')

    -- so it doesn't looks ugly
    local songText = capitalizeText(songName)..' - '..capitalizeText(difficultyName)
    makeLuaText('UI_Song_Text', songText, 1280, 5, screenHeight-30)
    setTextAlignment('UI_Song_Text','left')
    setTextFont('UI_Song_Text', fontName)
    setTextSize('UI_Song_Text', 18)
    setTextBorder('UI_Song_Text',1,'000000')
    --addLuaText('UI_Song_Text')

-------
    makeLuaSprite('UI_Score_Box', ui..'score_box', ui_x, ui_y + 45)
    screenCenter('UI_Score_Box', 'x')
    setObjectCamera('UI_Score_Box', 'camHUD')
    addLuaSprite('UI_Score_Box')
---
    local boxX, boxY = getProperty('UI_Score_Box.x'), getProperty('UI_Score_Box.y')
    local textSize = 20
    makeLuaText('UI_Score_Text', 'SCORE', 0, boxX + 25, boxY + 10)
    setTextFont('UI_Score_Text', fontName)
    setTextSize('UI_Score_Text', textSize)
    setTextBorder('UI_Score_Text',0,'000000')
    addLuaText('UI_Score_Text')

    makeLuaText('UI_Accuracy_Text', 'ACCURACY', 0, boxX + 230, boxY + 10)
    setTextFont('UI_Accuracy_Text', fontName)
    setTextSize('UI_Accuracy_Text', textSize)
    setTextBorder('UI_Accuracy_Text',0,'000000')
    addLuaText('UI_Accuracy_Text')

    makeLuaText('UI_Breaks_Text', 'BREAKS', 0, boxX + 460, boxY + 10)
    setTextFont('UI_Breaks_Text', fontName)
    setTextSize('UI_Breaks_Text', textSize)
    setTextBorder('UI_Breaks_Text',0,'000000')
    addLuaText('UI_Breaks_Text')

    makeLuaText('UI_Rank_Text', 'RANK', 0, boxX + 600, boxY + 10)
    setTextFont('UI_Rank_Text', fontName)
    setTextSize('UI_Rank_Text', textSize)
    setTextBorder('UI_Rank_Text',0,'000000')
    addLuaText('UI_Rank_Text')
--
    local textSize = 27
    makeLuaText('UI_Score_Txt', '0', 1280, boxX - 1050, boxY + 3)
    setTextAlignment('UI_Score_Txt', 'right')
    setTextFont('UI_Score_Txt', fontName)
    setTextSize('UI_Score_Txt', textSize)
    setTextBorder('UI_Score_Txt',0,'000000')
    addLuaText('UI_Score_Txt')

    makeLuaText('UI_Accuracy_Txt', '100%', 1280, boxX - 818, boxY + 3)
    setTextAlignment('UI_Accuracy_Txt', 'right')
    setTextFont('UI_Accuracy_Txt', fontName)
    setTextSize('UI_Accuracy_Txt', textSize)
    setTextBorder('UI_Accuracy_Txt',0,'000000')
    addLuaText('UI_Accuracy_Txt')

    makeLuaText('UI_Breaks_Txt', '0', 1280, boxX - 680, boxY + 3)
    setTextAlignment('UI_Breaks_Txt', 'right')
    setTextFont('UI_Breaks_Txt', fontName)
    setTextSize('UI_Breaks_Txt', textSize)
    setTextBorder('UI_Breaks_Txt',0,'000000')
    addLuaText('UI_Breaks_Txt')

    makeLuaText('UI_Rank_Txt', 'Clear', 1280, boxX + 45, boxY + 3)
    setTextFont('UI_Rank_Txt', fontName)
    setTextSize('UI_Rank_Txt', textSize)
    setTextBorder('UI_Rank_Txt',0,'000000')
    scaleObject('UI_Rank_Txt',0.75,1,false)
    addLuaText('UI_Rank_Txt')

    makeLuaSprite('UI_Time_Bar', ui..'timeBar', 0, 12)
    screenCenter('UI_Time_Bar', 'x')
    setObjectCamera('UI_Time_Bar', 'camHUD')
    addLuaSprite('UI_Time_Bar')

end

function checkCharacter()
    setProperty('UI_Health_LEFT.color', getIconColor('dad'))
    setProperty('UI_Health_RIGHT.color', getIconColor('boyfriend'))
    runHaxeCode([[
        game.timeBar.createGradientBar(
            [0xFF000000],
            [0xFF]]..rgbToHex(getProperty('boyfriend.healthColorArray'))..[[,
             0xFF]]..rgbToHex(getProperty('dad.healthColorArray'))..[[]
        );
    ]])
end

curPul = 0
function pulse(col)
    curPul = curPul + 1
    if curPul > 30 then
        curPul = 1
    end
    local tag = 'UI_Health_Frame_PULSE'..curPul
    makeLuaSprite(tag, ui..'health_border_pulse', 0, (downscroll and 57 or 610))
    screenCenter(tag, 'x')
    setObjectCamera(tag, 'camHUD')
    setObjectOrder(tag,getObjectOrder('UI_Health_Frame')-1)
    setProperty(tag..'.color',getColorFromHex(col))
    addLuaSprite(tag)
    doTweenX('UI_HealthPULSE_SCALEX'..curPul,tag..'.scale',1.2,1,'quartOut')
    doTweenAlpha('UI_HealthPULSE_ALPHA'..curPul,tag,0,1,'quartOut')
end

function getIconColor(chr)
	return getColorFromHex(rgbToHex(getProperty(chr .. ".healthColorArray")))
end

--library
function math.lerp(a, b, t)
	return a + t * (b - a);

end
function rgbToHex(array)
	return string.format('%.2x%.2x%.2x', array[1], array[2], array[3])

end
function formatTime(millisecond)
    local seconds = math.floor(millisecond / 1000)
    return string.format("%01d:%02d", (seconds / 60) % 60, seconds % 60)  

end
function round(x, n)
    n = math.pow(10, n or 0)
    x = x * n
    if x >= 0 then x = math.floor(x + 0.5) else x = math.ceil(x - 0.5) end
    return x / n

end
function capitalizeText(input)
    local output = ""
    local capitalizeNext = true
    for i = 1, #input do
        local char = input:sub(i, i)   
        if char:match("%a") then
            if capitalizeNext then
                char = char:upper()
                capitalizeNext = false
            else
                char = char:lower()
            end
        elseif char == " " or char == "-" then
            capitalizeNext = true
        end
    
        output = output .. char
    end
    return output

end





--The strum cam thing


--strumHUD = new FlxCamera();
--strumHUD.bgColor = 0x00000000;
--FlxG.cameras.add(strumHUD,false);
--FlxG.cameras.add(game.camOther,false);
--game.variables.set('strumHUD', strumHUD);
--
--game.modchartTexts.get('UI_Song_Text').cameras = [game.camOther];
--
--for (i in 0...4) game.strumLineNotes.members[i].x += 50;
--for (i in 4...8) game.strumLineNotes.members[i].x -= 50;
--for (i in 0...8) game.strumLineNotes.members[i].cameras = [strumHUD];
--for (splash in game.grpNoteSplashes) splash.cameras = [strumHUD];
--for (note in game.unspawnNotes) 
--{
--   note.cameras = [strumHUD];
--    if (note.isSustainNote)
--    {
--        note.cameras = [game.camHUD];
--        note.blockHit = true; 
--    }
--};

JM_clickable = false

JM_clicked = false

function onCreate()
    makeLuaSprite('doki_button', 'JustMonika_button', 420, -1000);
    setObjectCamera('doki_button', 'camHUD');
    addLuaSprite('doki_button', false)


    makeLuaSprite('doki_cursor','DDLC-cursor',getMouseX('other'),getMouseY('other'))
    setObjectCamera('doki_cursor', 'other')
    scaleObject('doki_cursor', 0.5, 0.5)
    setProperty('doki_cursor.alpha', 0)
    addLuaSprite('doki_cursor', true)


    makeLuaSprite('over', '', 600, 410)
    makeGraphic('over', 100, 70, '000000')
    setObjectCamera('over', 'camHUD')
    --setProperty('over.alpha', 0)
    --addLuaSprite('over', false)
end




function onUpdate()
    setPropertyFromClass('flixel.FlxG','mouse.visible',false)
    setProperty('doki_cursor.x',getMouseX('other'))
    setProperty('doki_cursor.y',getMouseY('other'))


    if JM_clickable == true and getMouseX('hud') >= 600 and getMouseX('hud') <= 700 and getMouseY('hud') >= 410 and getMouseY('hud') <= 480 and mouseClicked('left') then
       JM_clicked = true
       playSound('DokiSelect', 1)
       doTweenX('jmx', 'doki_button.scale', 0, 0.5, 'backInOut')
       doTweenY('jmy', 'doki_button.scale', 0, 0.5, 'backInOut')
       doTweenAlpha('mousebye', 'doki_cursor', 0, 0.5, 'linear')
    end

    if curBeat > 324 and JM_clicked == false then
        setProperty('health', -500);
    end

end

function onBeatHit()
if curBeat == 318 then
    JM_clickable = true
end
end
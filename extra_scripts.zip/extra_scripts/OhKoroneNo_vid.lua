function onSongStart()

        makeLuaSprite('videoSprite','', 215, 130)
        addLuaSprite('videoSprite', true)
        setObjectCamera('videoSprite', 'other')
        scaleObject('videoSprite', 1.55, 1.55)
        setObjectOrder('videoSprite', 999999)

    addHaxeLibrary('MP4Handler','vlc')
    addHaxeLibrary('Event','openfl.events')
    

    runHaxeCode([[
        var filepath = Paths.video('KoroneOhGodNo');		
        var video = new MP4Handler();
        video.playVideo(filepath);
        video.visible = false;
        setVar('video',video);
        FlxG.stage.removeEventListener('enterFrame', video.update); 
    ]])
setProperty('videoSprite.alpha', 0)
end

function onBeatHit()
	if curBeat == 7 then
		doTweenAlpha('OhKoroneNo-bye', 'videoSprite', 0, 1, 'cubeOut')
	end
end

function onStepHit()
	if curStep == 1 then
		doTweenAlpha('OhKoroneNo-intro', 'videoSprite', 1, 1, 'cubeOut')
	end
end

function onUpdatePost()

    runHaxeCode([[
        var video = getVar('video');
        game.getLuaObject('videoSprite').loadGraphic(video.bitmapData);
        video.volume = FlxG.sound.volume - 100;	
        if(game.paused)video.pause();
    ]])
end


function onResume()
    runHaxeCode([[
        var video = getVar('video');
        video.resume();
    ]])
end

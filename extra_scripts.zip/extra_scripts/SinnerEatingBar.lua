function onCreate()
    
makeAnimatedLuaSprite('neko','holofunk-week6/SinnerPixelBar', 800, 600)
addAnimationByPrefix('neko','idle','Yummy', 24, true)
setObjectCamera('neko', 'other')
scaleObject('neko', 4, 4)
setProperty('neko.antialiasing', false);
addLuaSprite('neko', true);
setProperty('neko.alpha', 0)

end

--the rest of the code is on the stage lmao xd    ~Ces4r 01
function onUpdate(elapsed)
	if curStep == 300 then
    for i = 0, getProperty('opponentStrums.length')-1 do
      setPropertyFromGroup('opponentStrums', i, 'texture', 'new');
    end
    for i = 0, getProperty('unspawnNotes.length')-1 do
      if getPropertyFromGroup('unspawnNotes', i, 'mustPress') == false then
      setPropertyFromGroup('unspawnNotes', i, 'texture', 'new');
      end
    end
    for i = 0, getProperty('playerStrums.length')-1 do
    setPropertyFromGroup('playerStrums', i, 'texture', 'new');
    end
    for i = 0, getProperty('unspawnNotes.length')-1 do
      if getPropertyFromGroup('unspawnNotes', i, 'mustPress') then
      setPropertyFromGroup('unspawnNotes', i, 'texture', 'new');
      end
    end
	end

	


    if curStep == 492 then
      for i = 0, getProperty('opponentStrums.length')-1 do
        setPropertyFromGroup('opponentStrums', i, 'texture', 'BLITZONOTE_assets');
      end
      for i = 0, getProperty('unspawnNotes.length')-1 do
        if getPropertyFromGroup('unspawnNotes', i, 'mustPress') == false then
        setPropertyFromGroup('unspawnNotes', i, 'texture', 'BLITZONOTE_assets');
        end
      end
      for i = 0, getProperty('playerStrums.length')-1 do
      setPropertyFromGroup('playerStrums', i, 'texture', 'NOTE_assets_helluva');
      end
      for i = 0, getProperty('unspawnNotes.length')-1 do
        if getPropertyFromGroup('unspawnNotes', i, 'mustPress') then
        setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets_helluva');
        end
      end
	end




    if curStep == 620 then
      for i = 0, getProperty('opponentStrums.length')-1 do
        setPropertyFromGroup('opponentStrums', i, 'texture', 'NOTE_assets_soft');
      end
      for i = 0, getProperty('unspawnNotes.length')-1 do
        if getPropertyFromGroup('unspawnNotes', i, 'mustPress') == false then
        setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets_soft');
        end
      end
      for i = 0, getProperty('playerStrums.length')-1 do
      setPropertyFromGroup('playerStrums', i, 'texture', 'Rem_Notes');
      end
      for i = 0, getProperty('unspawnNotes.length')-1 do
        if getPropertyFromGroup('unspawnNotes', i, 'mustPress') then
        setPropertyFromGroup('unspawnNotes', i, 'texture', 'Rem_Notes');
        end
      end
	    
	end


	
  if curStep == 748 then
    for i = 0, getProperty('opponentStrums.length')-1 do
      setPropertyFromGroup('opponentStrums', i, 'texture', 'NOTE_assets_ddlc');
    end
    for i = 0, getProperty('unspawnNotes.length')-1 do
      if getPropertyFromGroup('unspawnNotes', i, 'mustPress') == false then
      setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets_ddlc');
      end
    end
    for i = 0, getProperty('playerStrums.length')-1 do
    setPropertyFromGroup('playerStrums', i, 'texture', 'NOTE_assets_ddlc');
    end
    for i = 0, getProperty('unspawnNotes.length')-1 do
      if getPropertyFromGroup('unspawnNotes', i, 'mustPress') then
      setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets_ddlc');
      end
    end
    
end


if curStep == 876 then
  for i = 0, getProperty('opponentStrums.length')-1 do
    setPropertyFromGroup('opponentStrums', i, 'texture', 'NOTE_assets');
  end
  for i = 0, getProperty('unspawnNotes.length')-1 do
    if getPropertyFromGroup('unspawnNotes', i, 'mustPress') == false then
    setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets');
    end
  end
  for i = 0, getProperty('playerStrums.length')-1 do
  setPropertyFromGroup('playerStrums', i, 'texture', 'NOTE_assets');
  end
  for i = 0, getProperty('unspawnNotes.length')-1 do
    if getPropertyFromGroup('unspawnNotes', i, 'mustPress') then
    setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets');
    end
  end
  
end



if curStep == 1020 then
  for i = 0, getProperty('opponentStrums.length')-1 do
    setPropertyFromGroup('opponentStrums', i, 'texture', 'NOTE_assets_holo');
  end
  for i = 0, getProperty('unspawnNotes.length')-1 do
    if getPropertyFromGroup('unspawnNotes', i, 'mustPress') == false then
    setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets_holo');
    end
  end
  for i = 0, getProperty('playerStrums.length')-1 do
  setPropertyFromGroup('playerStrums', i, 'texture', 'NOTE_assets_holo');
  end
  for i = 0, getProperty('unspawnNotes.length')-1 do
    if getPropertyFromGroup('unspawnNotes', i, 'mustPress') then
    setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets_holo');
    end
  end
  
end



if curStep == 1148 then
  for i = 0, getProperty('opponentStrums.length')-1 do
    setPropertyFromGroup('opponentStrums', i, 'texture', 'NOTE_assets_azula');
  end
  for i = 0, getProperty('unspawnNotes.length')-1 do
    if getPropertyFromGroup('unspawnNotes', i, 'mustPress') == false then
    setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets_azula');
    end
  end
  for i = 0, getProperty('playerStrums.length')-1 do
  setPropertyFromGroup('playerStrums', i, 'texture', 'NOTE_assets_azula');
  end
  for i = 0, getProperty('unspawnNotes.length')-1 do
    if getPropertyFromGroup('unspawnNotes', i, 'mustPress') then
    setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets_azula');
    end
  end

end



  if curStep == 1180 then
    for i = 0, getProperty('opponentStrums.length')-1 do
      setPropertyFromGroup('opponentStrums', i, 'texture', 'NOTE_assets_pandita');
    end
    for i = 0, getProperty('unspawnNotes.length')-1 do
      if getPropertyFromGroup('unspawnNotes', i, 'mustPress') == false then
      setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets_pandita');
      end
    end
    for i = 0, getProperty('playerStrums.length')-1 do
    setPropertyFromGroup('playerStrums', i, 'texture', 'NOTE_assets_pandita');
    end
    for i = 0, getProperty('unspawnNotes.length')-1 do
      if getPropertyFromGroup('unspawnNotes', i, 'mustPress') then
      setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets_pandita');
      end
    end

end



    if curStep == 1248 then
      for i = 0, getProperty('opponentStrums.length')-1 do
        setPropertyFromGroup('opponentStrums', i, 'texture', 'NOTE_assets_nanda');
      end
      for i = 0, getProperty('unspawnNotes.length')-1 do
        if getPropertyFromGroup('unspawnNotes', i, 'mustPress') == false then
        setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets_nanda');
        end
      end
      for i = 0, getProperty('playerStrums.length')-1 do
      setPropertyFromGroup('playerStrums', i, 'texture', 'NOTE_assets_nanda');
      end
      for i = 0, getProperty('unspawnNotes.length')-1 do
        if getPropertyFromGroup('unspawnNotes', i, 'mustPress') then
        setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets_nanda');
        end
      end

    end



end






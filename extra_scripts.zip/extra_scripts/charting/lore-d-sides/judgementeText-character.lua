function onCreatePost(elapsed)
	health = getProperty('health');
	healthPer = math.floor((health*50)*1000)/1000;
	accuracyLua = math.floor((rating*100)*1000)/1000;
	scorePer = math.floor((score/maxScore)*100000)/1000;
	missesTxtExist = spriteExists('missesTxt');
	tnhTxtExist = spriteExists('tnhTxt');

	setProperty('scoreTxtLua.x', getProperty('scoreTxt.x'))
	setProperty('scoreTxtLua.y', getProperty('scoreTxt.y'))
	setProperty('scoreTxtLua.scale.x', getProperty('scoreTxt.scale.x'))
	setProperty('scoreTxtLua.scale.y', getProperty('scoreTxt.scale.y'))
	setTextFont('scoreTxtLua', 'vcr-ourple.ttf')

	if boyfriendName == "ved-player" then
	if missesTxtExist == 'false' and tnhTxtExist == 'false' then
        setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How ved you are: '..score)..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	elseif missesTxtExist == 'true' and tnhTxtExist == 'true' then
        setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How ved you are: '..score)..(not botPlay and (misses == 0 and ' |' or '') or '')..(misses == 0 and not botPlay and ' FC' or '')..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	elseif missesTxtExist == 'false' and tnhTxtExist == 'true' then
        setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How ved you are: '..score)..(not botPlay and ' |' or '')..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	elseif missesTxtExist == 'true' and tnhTxtExist == 'false' then
	    setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How ved you are: '..score)..(not botPlay and ' |' or '')..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	end
    end
	if dadName == "kizuna-ai-closeup" then
		if missesTxtExist == 'false' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How AI you are: '..score)..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How AI you are: '..score)..(not botPlay and (misses == 0 and ' |' or '') or '')..(misses == 0 and not botPlay and ' FC' or '')..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'false' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How AI you are: '..score)..(not botPlay and ' |' or '')..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How AI you are: '..score)..(not botPlay and ' |' or '')..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	    end
	end
	if Name == "yotsuba-fachera-closeup" then
		if missesTxtExist == 'false' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How based you are: '..score)..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How based you are: '..score)..(not botPlay and (misses == 0 and ' |' or '') or '')..(misses == 0 and not botPlay and ' FC' or '')..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'false' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How based you are: '..score)..(not botPlay and ' |' or '')..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How based you are: '..score)..(not botPlay and ' |' or '')..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	    end
	end
	if dadName == "haachama-christmas" then
		if missesTxtExist == 'false' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How CHAMA you are: '..score)..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How CHAMA you are: '..score)..(not botPlay and (misses == 0 and ' |' or '') or '')..(misses == 0 and not botPlay and ' FC' or '')..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'false' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How CHAMA you are: '..score)..(not botPlay and ' |' or '')..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How CHAMA you are: '..score)..(not botPlay and ' |' or '')..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	    end
	end
	if dadName == "haachama-christmas-swearing" then
		if missesTxtExist == 'false' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How CHAMA you are: '..score)..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How CHAMA you are: '..score)..(not botPlay and (misses == 0 and ' |' or '') or '')..(misses == 0 and not botPlay and ' FC' or '')..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'false' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How CHAMA you are: '..score)..(not botPlay and ' |' or '')..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How CHAMA you are: '..score)..(not botPlay and ' |' or '')..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	    end
	end
	if dadName == "big-monika" then
		if missesTxtExist == 'false' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'Reality score: '..score)..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Trashed files: '..misses)..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'Reality score: '..score)..(not botPlay and (misses == 0 and ' |' or '') or '')..(misses == 0 and not botPlay and ' FC' or '')..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'false' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'Reality score: '..score)..(not botPlay and ' |' or '')..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Trashed files: '..misses)..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'Reality score: '..score)..(not botPlay and ' |' or '')..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	    end
	end
	if dadName == "yuri-gore" then
		if missesTxtExist == 'false' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How crazy you are: '..score)..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Glitches: '..misses)..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Madness: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How crazy you are: '..score)..(not botPlay and (misses == 0 and ' |' or '') or '')..(misses == 0 and not botPlay and ' FC' or '')..' | Combo: '..getProperty('combo')..' | Madness: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'false' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How crazy you are: '..score)..(not botPlay and ' |' or '')..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Glitches: '..misses)..' | Combo: '..getProperty('combo')..' | Madness: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How crazy you are: '..score)..(not botPlay and ' |' or '')..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Madness: '..ratingName..' ('..accuracyLua..'%)' or '')
	    end
	end
	if dadName == "suyen" then
		if missesTxtExist == 'false' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How cool you are: '..score)..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Misses: '..misses)..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Acc.: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How cool you are: '..score)..(not botPlay and (misses == 0 and ' |' or '') or '')..(misses == 0 and not botPlay and ' FC' or '')..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'false' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How cool you are: '..score)..(not botPlay and ' |' or '')..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Misses: '..misses)..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How cool you are: '..score)..(not botPlay and ' |' or '')..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	    end
	else
		if missesTxtExist == 'false' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How ved you are: '..score)..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Misses: '..misses)..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Acc.: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How ved you are: '..score)..(not botPlay and (misses == 0 and ' |' or '') or '')..(misses == 0 and not botPlay and ' FC' or '')..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'false' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How ved you are: '..score)..(not botPlay and ' |' or '')..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Misses: '..misses)..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How ved you are: '..score)..(not botPlay and ' |' or '')..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	    end
	end
end
function onCreate() 
	setProperty('introSoundsSuffix', '-amogusinirl')
end


--Countdown Time
function onCountdownTick(counter)
	if counter == 0 then
		--playSound('intro3')
	elseif counter == 1 then
		setProperty('CountTwo.visible', false)
		setProperty('countdownReady.visible', false)
		--playSound('intro2')	
	elseif counter == 2 then
        setProperty('CountOne.visible', false)
		setProperty('countdownSet.visible', false)
		--playSound('intro1')
	elseif counter == 3 then
		setProperty('CountGO.visible', false)
		setProperty('countdownGo.visible', false)
		--playSound('introGo')
	end
end
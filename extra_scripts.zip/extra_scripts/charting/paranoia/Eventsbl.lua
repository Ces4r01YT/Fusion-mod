
function onCreate()
    makeLuaSprite('transition', '', 0, 0)
	makeGraphic("transition", 1280, 720, '000000')
	addLuaSprite('transition', false);
	scaleObject('transition', 1, 1)
    setObjectCamera("transition", 'other')
    setProperty("transition.alpha", 0)

    makeLuaText('lyric', '', screenWidth, 0, 550)
    setTextFont('lyric', 'Felixti.ttf')
    setTextString('lyric', '')
    setTextColor('lyric', 'FF0000')
    setTextSize('lyric', 40)
    setTextBorder('lyric', '3.5', '000000')
    setTextAlignment('lyric', 'center')
    setObjectCamera('lyric', 'other')
    addLuaText('lyric')
end

local x = 0

function onBeatHit()
    if curStep >= 47 and curStep <= 174 then
        triggerEvent('ess_Bump Controller', 'bloom,u_brightness', '3,0')
    end
    if curStep >= 255 and curStep <= 383 then
        triggerEvent('ess_Bump Controller', 'bloom,u_brightness', '3,0')
    end
    if curStep >= 399 and curStep <= 447 then
        triggerEvent('ess_Bump Controller', 'bloom,u_brightness', '3,0')
    end
    if curStep >= 447 and curStep <= 575 then
        if x == 0 then
            x = 1
        elseif x == 1 then
            triggerEvent('ess_Bump Controller', 'bloom,u_brightness', '3,0')
            x = 1
        end
    end
    if curStep >= 575 and curStep <= 959 then
        triggerEvent('ess_Bump Controller', 'bloom,u_brightness', '3,0')
    end
    if curStep >= 1471 and curStep <= 1743 then
        triggerEvent('ess_Bump Controller', 'bloom,u_brightness', '3,0')
    end
    if curStep >= 1759 and curStep <= 1872 then
        triggerEvent('ess_Bump Controller', 'bloom,u_brightness', '3,0')
    end
    if curStep >= 1887 and curStep <= 2016 then
        triggerEvent('ess_Bump Controller', 'bloom,u_brightness', '3,0')
    end
end

local ShakeIntensity = 0

function onStepHit()
    --debugPrint(getProperty("healthBar.y")..'|', getProperty("scoreTxt.y")..'|', getProperty("timeTxt.y")..'|', getProperty("iconP1.y")..'|', getProperty("iconP2.y"))

    if curStep == 488 or curStep == 489 then
        x = 0
    end
    if curStep == 963 or curStep == 964 then
        setTextString('lyric', "What's the Matter Boy?")
    end
    if curStep == 989 or curStep == 990 then
        setTextString('lyric', "Don't you recognise your own girlfriend?")
	end
    if curStep == 993 or curStep == 994 then
        playAnim('GF','dance', true)
		setProperty("GF.alpha", 1)
	end
    if curStep >= 1013 and curStep <= 1024 then
		cameraShake("game", ShakeIntensity, 0.1)
        ShakeIntensity = ShakeIntensity + 0.009
        doTweenAlpha("lyricgone", "lyric", 0, 0.25, "linear")
	end
    if curStep == 1024 or curStep == 1025 then
		setProperty("transition.alpha", 1)
        removeLuaSprite("GF", true)
        removeLuaSprite("lyric", true)
        setTextString('lyric', "")
	end
    if curStep == 1040 or curStep == 1041 then
		setProperty("transition.alpha", 0)
        ShakeIntensity = 0.005
        x = 0
	end
    if curStep >= 1040 and curStep <= 1295 then
        cameraShake("game", ShakeIntensity, 0.1)
	end
    if curStep >= 1296 and curStep <= 1316 then
        cameraShake("game", ShakeIntensity, 0.1)
        ShakeIntensity = ShakeIntensity - 0.00025
	end
    if curStep == 1744 or curStep == 1745 then
        noteTweenAlpha("o1a", 0, 0, 1, "QuadIn")
        noteTweenAlpha("o2a", 1, 0, 1, "QuadIn")
        noteTweenAlpha("o3a", 2, 0, 1, "QuadIn")
        noteTweenAlpha("o4a", 3, 0, 1, "QuadIn")
	end
    if curStep == 1872 or curStep == 1873 then
        if downscroll == true then
            doTweenY("healthBarY", "healthBar", 83.2 - 300, 1, "BackIn")
            doTweenY("scoreTxtY", "scoreTxt", 115.2 - 300, 1, "BackIn")
            doTweenY("timeTxtY", "timeTxt", 676 + 300, 1, "BackIn")
            doTweenY("iconP1", "iconP1", 8.2 - 300, 1, "BackIn")
            doTweenY("iconP2", "iconP2", 8.2 - 300, 1, "BackIn")
        else
            doTweenY("healthBarY", "healthBar", 644.8 + 150, 1, "BackIn")
            doTweenY("scoreTxtY", "scoreTxt", 676.8 + 150, 1, "BackIn")
            doTweenY("timeTxtY", "timeTxt", 19 - 150, 1, "BackIn")
            doTweenY("iconP1", "iconP1", 569.8 + 150, 1, "BackIn")
            doTweenY("iconP2", "iconP2", 569.8 + 150, 1, "BackIn")
        end
	end
    if curStep == 2000 or curStep == 2001 then
        noteTweenAlpha("o1a", 0, 1, 1, "QuadIn")
        noteTweenAlpha("o2a", 1, 1, 1, "QuadIn")
        noteTweenAlpha("o3a", 2, 1, 1, "QuadIn")
        noteTweenAlpha("o4a", 3, 1, 1, "QuadIn")
	end
    if curStep == 2016 or curStep == 2017 then
        if downscroll == true then
            doTweenY("healthBarY", "healthBar", 83.2, 1, "BackOut")
            doTweenY("scoreTxtY", "scoreTxt", 115.2, 1, "BackOut")
            doTweenY("timeTxtY", "timeTxt", 676, 1, "BackOut")
            doTweenY("iconP1", "iconP1", 8.2, 1, "BackOut")
            doTweenY("iconP2", "iconP2", 8.2, 1, "BackOut")
        end
	end
    if curStep == 2016 or curStep == 2017 then
		doTweenAlpha("headbgA", "headbg", 0, 20, "linear")
	end
    if curStep == 2208 or curStep == 2209 then
		setProperty("transition.alpha", 1)
	end
end
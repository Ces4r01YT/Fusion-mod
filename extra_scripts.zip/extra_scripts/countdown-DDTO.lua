function onCreate()
	makeLuaSprite('two', 'ready_doki', 100, 100)
	screenCenter('two', 'xy')
	setObjectCamera('two', 'other')
	makeLuaSprite('one', 'set_doki', 100, 100)
	screenCenter('one', 'xy')
	setObjectCamera('one', 'other')
	makeLuaSprite('go', 'go_doki', 100, 100)
	screenCenter('go', 'xy')
	setObjectCamera('go', 'other')
	setProperty('countdownReady.visible', false)
	setProperty('countdownSet.visible', false)
	setProperty('countdownGo.visible', false)
	setProperty('introSoundsSuffix', '-NADALAVERGAEXACTO')
end
  
function onCountdownTick(counter)
	if counter == 0 then
		playSound('DokiOverlap', 0.5)
	
	elseif counter == 1 then
		addLuaSprite('two')
		playSound('DokiOverlap',0.5)
		doTweenAlpha('countdown2', 'two',0 ,0.3, 'cubeIn')
		setProperty('countdownReady.visible', false)
				
	elseif counter == 2 then
		addLuaSprite('one')
		playSound('DokiOverlap',0.5)
		doTweenAlpha('countdown1', 'one',0 ,0.3, 'cubeIn')
		setProperty('countdownSet.visible', false)

	elseif counter == 3 then
		addLuaSprite('go')
		playSound('DokiSelect',0.5)
		doTweenAlpha('countdownGo', 'go',0 ,0.3, 'cubeIn')
		setProperty('countdownGo.visible', false)
	end
end
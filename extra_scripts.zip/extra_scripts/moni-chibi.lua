function onCreate() 
	makeLuaSprite('chibimoni', 'Monika-chibi/air', 950, 1000)   --y 490
    setObjectCamera('chibimoni', 'other')
    scaleObject('chibimoni', 2.25, 2.25)
	addLuaSprite('chibimoni', true)


	makeLuaText('helpmoni', "I will give you\na hand", 0, 850, 1000);   --y 485
setTextSize('helpmoni', 50);
setTextFont('helpmoni', 'Metropolische_2016.ttf')
setObjectCamera('helpmoni', 'other');
setTextColor('helpmoni', 'FFFFFF')
addLuaText('helpmoni');
end

function onBeatHit()
	if curBeat == 230 then
		doTweenY('appearschibi', 'chibimoni', 490, 1.25, 'sineInOut')
		doTweenY('appearstexthelp', 'helpmoni', 485, 1.25, 'sineInOut')
	end
	if curBeat == 235 then
		doTweenY('byechibi', 'chibimoni', 1000, 1.25, 'sineInOut')
		doTweenY('byetexthelp', 'helpmoni', 1000, 1.25, 'sineInOut')
	end
end

function onUpdate(elapsed)
	if curStep == 300 then --This one MUST be at least 16 or 32 steps earlier (depends of the version of Psych Engine)
    for i = 0, getProperty('unspawnNotes.length')-1 do
  setPropertyFromGroup('unspawnNotes', i, 'noteSplashTexture', 'noteSplashesHololive');
    end
  end

	


    if curStep == 492 then
      for i = 0, getProperty('unspawnNotes.length')-1 do
        setPropertyFromGroup('unspawnNotes', i, 'noteSplashTexture', 'noteSplashesDefault');
      end
	  end




    if curStep == 620 then
      for i = 0, getProperty('unspawnNotes.length')-1 do
        setPropertyFromGroup('unspawnNotes', i, 'noteSplashTexture', 'Rem_Splashes');
      end
	  end

	
    if curStep == 748 then
      for i = 0, getProperty('unspawnNotes.length')-1 do
        setPropertyFromGroup('unspawnNotes', i, 'noteSplashTexture', 'NOTE_splashes_doki');
      end
	  end


    if curStep == 876 then
      for i = 0, getProperty('unspawnNotes.length')-1 do
        setPropertyFromGroup('unspawnNotes', i, 'noteSplashTexture', 'noteSplashesDefault');
      end
	  end

    if curStep == 1148 then
      for i = 0, getProperty('unspawnNotes.length')-1 do
        setPropertyFromGroup('unspawnNotes', i, 'noteSplashTexture', 'noteSplashes_devil');
      end
	  end




end
function start (song)
       print("cool")
end

function update (elapsed)

end

function stepHit (step)
         if curStep == 16
            ShowOnlyStrums = true
end
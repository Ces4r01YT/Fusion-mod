function onEvent(eventName, value1, value2)

	if eventName=='virtualboyOn' then
	
	addLuaScript('extra_scripts/virtualboy-shader.lua')
	
	end

end
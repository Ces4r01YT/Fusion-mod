-- Event notes hooks
function onEvent(name, value1, value2)
	if name == 'KoyoriCutsceneEnd' then
		removeLuaSprite('videoSprite1', false)
	end
end
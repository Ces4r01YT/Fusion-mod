function opponentNoteHit()
	setPropertyFromClass('openfl.Lib','application.window.x', math.random(-100,100))
    setPropertyFromClass('openfl.Lib','application.window.y', math.random(-100,100))
end
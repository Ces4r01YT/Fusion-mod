function onEvent(name,value1,value2)
	setPropertyFromClass('ClientPrefs', 'downScroll', true);
	end
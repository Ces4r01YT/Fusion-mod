function opponentNoteHit()
    setPropertyFromClass('PlayState', 'SONG.speed', math.random(1, 5))
end
function onEvent(name)
    if name == 'Trompeta Diablo Leakers' then
        objectPlayAnimation('DiabloLeakers','trompeta',true)
    end
end

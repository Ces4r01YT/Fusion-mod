function opponentNoteHit(id, direction, noteType, isSustainNote)
	if curHealth > damageValue then
			setProperty('health', curHealth - damageValue);
		
	end
end
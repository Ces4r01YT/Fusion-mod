function onEvent(name,value1,value2)
	if n == "ChangeScroll" then
		for i=0, 3 do
			if v1 == 0 then --BF
		change()
	end
end

function change()
	if getPropertyFromClass('ClientPrefs', 'middleScroll') then
	setPropertyFromClass("ClientPrefs", "middleScroll", false)
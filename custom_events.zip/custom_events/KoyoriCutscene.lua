function onEvent(name, value1, value2)
	if name == 'KoyoriCutscene' then
		 startVideo("KoyoriVsChoco")
		 setProperty('inCutscene', false);
	end
	return Function_Continue
end
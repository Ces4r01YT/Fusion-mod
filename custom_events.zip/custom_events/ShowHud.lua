function onEvent(name, value1)
	if name == 'ShowHud' then
		setProperty('camHUD.visible', true);
	end
end

function onUpdate()
    if getPropertyFromClass('flixel.FlxG', 'keys.justPressed.SEVEN') then
        endSong();
    end
end
--THANKS AGAIN L'Étranger#9279 YOU FUCKING LEGEND
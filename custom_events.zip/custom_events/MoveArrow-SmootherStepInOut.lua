function mysplit (inputstr, sep)
    if sep == nil then
        sep = "%s";
    end
    local t={};
    for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
        table.insert(t, str);
    end
    return t;
end

-- Event notes hooks
function onEvent(name, value1, value2)
    if name == "MoveArrow-SmootherStepInOut" then
        local tableee=mysplit(value2,", "); -- Splits value1 into a table
        value1 = tonumber(value1);
        tableee[1] = tonumber(tableee[1]);
        tableee[2] = tonumber(tableee[2]);
        tableee[3] = tonumber(tableee[3]);
        tableee[4] = tonumber(tableee[4]);
        tableee[5] = tonumber(tableee[5]);

        if value1 < 4 then
            notePosX = getPropertyFromGroup('opponentStrums', value1, 'x');
            notePosY = getPropertyFromGroup('opponentStrums', value1, 'y');
        else
            notee = value1 - 4;
            notePosX = getPropertyFromGroup('playerStrums', notee, 'x');
            notePosY = getPropertyFromGroup('playerStrums', notee, 'y');
        end

        newnotePosX = notePosX + tableee[1];
        newnotePosY = notePosY + tableee[2];

        duration = tableee[5];
        rotation = tableee[3];
        opacity = tableee[4];


        if value1 == 0 then
            noteTweenX("smoothIOx1",0,newnotePosX,duration,"smoothStepInOut");
            noteTweenY("smoothIOx1y1",0,newnotePosY,duration,"smoothStepInOut");
            noteTweenAngle("smoothIOx1r1",0,rotation,duration, "smoothStepInOut");
            noteTweenAlpha("smoothIOx1o1",0,opacity,duration,"smoothStepInOut");
        elseif value1 == 1 then
            noteTweenX("smoothIOx1x2",1,newnotePosX,duration,"smoothStepInOut");
            noteTweenY("smoothIOx1y2",1,newnotePosY,duration,"smoothStepInOut");
            noteTweenAngle("smoothIOx1r2",1,rotation,duration, "smoothStepInOut");
            noteTweenAlpha("smoothIOx1o2",1,opacity,duration,"smoothStepInOut");
        elseif value1 == 2 then
            noteTweenX("smoothIOx1x3",2,newnotePosX,duration,"smoothStepInOut");
            noteTweenY("smoothIOx1y3",2,newnotePosY,duration,"smoothStepInOut");
            noteTweenAngle("smoothIOx1r3",2,rotation,duration, "smoothStepInOut");
            noteTweenAlpha("smoothIOx1o3",2,opacity,duration,"smoothStepInOut");
        elseif value1 == 3 then
            noteTweenX("smoothIOx1x4",3,newnotePosX,duration,"smoothStepInOut");
            noteTweenY("smoothIOx1y4",3,newnotePosY,duration,"smoothStepInOut");
            noteTweenAngle("smoothIOx1r4",3,rotation,duration, "smoothStepInOut");
            noteTweenAlpha("smoothIOx1o4",3,opacity,duration,"smoothStepInOut");
        elseif value1 == 4 then
            noteTweenX("smoothIOx1x5",4,newnotePosX,duration,"smoothStepInOut");
            noteTweenY("smoothIOx1y5",4,newnotePosY,duration,"smoothStepInOut");
            noteTweenAngle("smoothIOx1r5",4,rotation,duration, "smoothStepInOut");
            noteTweenAlpha("smoothIOx1o5",4,opacity,duration,"smoothStepInOut");
        elseif value1 == 5 then
            noteTweenX("smoothIOx1x6",5,newnotePosX,duration,"smoothStepInOut");
            noteTweenY("smoothIOx1y6",5,newnotePosY,duration,"smoothStepInOut");
            noteTweenAngle("smoothIOx1r6",5,rotation,duration, "smoothStepInOut");
            noteTweenAlpha("smoothIOx1o6",5,opacity,duration,"smoothStepInOut");
        elseif value1 == 6 then
            noteTweenX("smoothIOx1x7",6,newnotePosX,duration,"smoothStepInOut");
            noteTweenY("smoothIOx1y7",6,newnotePosY,duration,"smoothStepInOut");
            noteTweenAngle("smoothIOx1r7",6,rotation,duration, "smoothStepInOut");
            noteTweenAlpha("smoothIOx1o7",6,opacity,duration,"smoothStepInOut");
        elseif value1 == 7 then
            noteTweenX("smoothIOx1x8",7,newnotePosX,duration,"smoothStepInOut");
            noteTweenY("smoothIOx1y8",7,newnotePosY,duration,"smoothStepInOut");
            noteTweenAngle("smoothIOx1r8",7,rotation,duration, "smoothStepInOut");
            noteTweenAlpha("smoothIOx1o8",7,opacity,duration,"smoothStepInOut");
        end
    end
end
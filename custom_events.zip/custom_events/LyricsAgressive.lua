function onEvent(name, value1, value2)
    local var string = (value1)
    local var color = (value2)
    if name == "LyricsAgressive" then

        makeLuaText('captions', 'Lyrics go here', 1000, 150, 620)
        setTextString('captions',  '' .. string)
        setTextFont('captions', 'KillTheNoise-2VM8.ttf')
        setTextColor('FFFFFF', FFFFFF)
        setTextSize('captions', 40);
        addLuaText('captions')
	setObjectCamera('captions', 'other');
        setTextAlignment('captions', 'center')
        --removeLuaText('captions', true)
        
    end
end


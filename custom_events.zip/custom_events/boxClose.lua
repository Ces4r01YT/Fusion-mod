-- Event notes hooks
function onEvent(name, value1, value2)
	--naa
end
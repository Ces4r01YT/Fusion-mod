function onEvent(name, value1, value2)
    if name == "addScript" then
    addLuaScript(value1)
    end
end
function getNoteXs()
	getDefaultOpX1 = getPropertyFromGroup('strumLineNotes', 0, 'x')
	getDefaultOpX2 = getPropertyFromGroup('strumLineNotes', 1, 'x')
	getDefaultOpX3 = getPropertyFromGroup('strumLineNotes', 2, 'x')
	getDefaultOpX4 = getPropertyFromGroup('strumLineNotes', 3, 'x')
	getDefaultPX1 = getPropertyFromGroup('strumLineNotes', 8, 'x')
	getDefaultPX2 = getPropertyFromGroup('strumLineNotes', 9, 'x')
	getDefaultPX3 = getPropertyFromGroup('strumLineNotes', 10, 'x')
	getDefaultPX4 = getPropertyFromGroup('strumLineNotes', 11, 'x')
end

function onEvent(n, a, b)
	if n == 'sexy part' and a == 'DO IT' then
		-- Judgement Scroll --
        	setPropertyFromGroup('opponentStrums', 4, 'direction', -90)
	    	setPropertyFromGroup('opponentStrums', 5, 'direction', -90)
	    	setPropertyFromGroup('opponentStrums', 6, 'direction', -90)
    		setPropertyFromGroup('opponentStrums', 7, 'direction', -90)
		if not downscroll then
			noteTweenY('1', 4, screenHeight - 150, 1, 'quintOut');
			noteTweenY('2', 5, screenHeight - 150, 1, 'quintOut');
			noteTweenY('3', 6, screenHeight - 150, 1, 'quintOut');
			noteTweenY('4', 7, screenHeight - 150, 1, 'quintOut');
		else
			noteTweenY('1', 4, 50, 1, 'quintOut');
			noteTweenY('2', 5, 50, 1, 'quintOut');
			noteTweenY('3', 6, 50, 1, 'quintOut');
			noteTweenY('4', 7, 50, 1, 'quintOut');
		end

		-- Player Middlescroll --
		noteTweenX('5', 8, defaultPlayerStrumX0 - 620, 1, 'quintInOut');
		noteTweenX('6', 9, defaultPlayerStrumX1 - 580, 1, 'quintInOut');
		noteTweenX('7', 10, defaultPlayerStrumX2 - 80, 1, 'quintInOut');
		noteTweenX('8', 11, defaultPlayerStrumX3 - 40, 1, 'quintInOut');
		noteTweenX('9', 0, defaultPlayerStrumX0 - 620, 1, 'quintInOut');
		noteTweenX('10', 1, defaultPlayerStrumX1 - 580, 1, 'quintInOut');
		noteTweenX('11', 2, defaultPlayerStrumX2 - 80, 1, 'quintInOut');
		noteTweenX('12', 3, defaultPlayerStrumX3 - 40, 1, 'quintInOut');
	end
	
		if n == 'sexy part' and b == 'MOVETHEBITCH1' then
			noteTweenX('9x', 8, defaultOpponentStrumX0, 0.2, 'quadIn');
			noteTweenX('10x', 9, defaultOpponentStrumX1, 0.2, 'quadIn');
			noteTweenX('11x', 10, defaultOpponentStrumX2, 0.2, 'quadIn');
			noteTweenX('12x', 11, defaultOpponentStrumX3, 0.2, 'quadIn');
		end
		if n == 'sexy part' and b == 'MOVETHEBITCH2' then
			noteTweenX('9x', 8, defaultPlayerStrumX0, 0.2, 'quadIn');
			noteTweenX('10x', 9, defaultPlayerStrumX1, 0.2, 'quadIn');
			noteTweenX('11x', 10, defaultPlayerStrumX2, 0.2, 'quadIn');
			noteTweenX('12x', 11, defaultPlayerStrumX3, 0.2, 'quadIn');
		end
		if n == 'sexy part' and b == 'MOVETHEBITCH3' then
			noteTweenX('5x', 8, defaultPlayerStrumX0 - 620, 0.2, 'quadInOut');
			noteTweenX('6x', 9, defaultPlayerStrumX1 - 580, 0.2, 'quadtInOut');
			noteTweenX('7x', 10, defaultPlayerStrumX2 - 80, 0.2, 'quadInOut');
			noteTweenX('8x', 11, defaultPlayerStrumX3 - 40, 0.2, 'quadInOut');
			noteTweenX('9x', 0, defaultPlayerStrumX0 - 620, 0.2, 'quadInOut');
			noteTweenX('10x', 1, defaultPlayerStrumX1 - 580, 0.2, 'quadInOut');
			noteTweenX('11x', 2, defaultPlayerStrumX2 - 80, 0.2, 'quadInOut');
			noteTweenX('12x', 3, defaultPlayerStrumX3 - 40, 0.2, 'quadInOut');
		end
	if n == 'sexy part' and a == 'UNDO IT' then
		-- Judgement Scroll --
        		setPropertyFromGroup('opponentStrums', 4, 'direction', 90)
	    	setPropertyFromGroup('opponentStrums', 5, 'direction', 90)
	    	setPropertyFromGroup('opponentStrums', 6, 'direction', 90)
    		setPropertyFromGroup('opponentStrums', 7, 'direction', 90)
		if not downscroll then
			noteTweenY('1x', 4, 50, 1, 'quintOut');
			noteTweenY('2x', 5, 50, 1, 'quintOut');
			noteTweenY('3x', 6, 50, 1, 'quintOut');
			noteTweenY('4x', 7, 50, 1, 'quintOut');
		else
			noteTweenY('1x', 4, screenHeight - 150, 1, 'quintOut');
			noteTweenY('2x', 5, screenHeight - 150, 1, 'quintOut');
			noteTweenY('3x', 6, screenHeight - 150, 1, 'quintOut');
			noteTweenY('4x', 7, screenHeight - 150, 1, 'quintOut');
		end

		-- Player Scroll --
		for i = 0, 3 do
			--noteTweenX(i..'x', i, screenWidth / 2 - screenWidth / 3, 1, 'quintInOut');
		end
		for n = 8, 11 do
			--noteTweenX(n..'x', n, (screenWidth / 2 + screenWidth / 3), 1, 'quintInOut');
		end
		
		for i = 0, 3 do
			setPropertyFromGroup('opponentStrums', i, 'visible', true)
			noteTweenAlpha('a', 0, 1, 0.1, 'quintInOut');
			noteTweenAlpha('s', 1, 1, 0.1, 'quintInOut');
			noteTweenAlpha('d', 2, 1, 0.1, 'quintInOut');
			noteTweenAlpha('f', 3, 1, 0.1, 'quintInOut');
		end
		noteTweenX('5x', 8, defaultPlayerStrumX0 + 128, 1, 'quintInOut');
		noteTweenX('6x', 9, defaultPlayerStrumX1 + 122, 1, 'quintInOut');
		noteTweenX('7x', 10, defaultPlayerStrumX2 + 116, 1, 'quintInOut');
		noteTweenX('8x', 11, defaultPlayerStrumX3 + 110, 1, 'quintInOut');

		noteTweenX('9x', 0, defaultOpponentStrumX0 - 92, 1, 'quintInOut');
		noteTweenX('10x', 1, defaultOpponentStrumX1 - 98, 1, 'quintInOut');
		noteTweenX('11x', 2, defaultOpponentStrumX2 - 104, 1, 'quintInOut');
		noteTweenX('12x', 3, defaultOpponentStrumX3 - 110, 1, 'quintInOut');
	end
end

function onTweenCompleted(t)
	if t == '12' then
		for i = 0, 3 do
			setPropertyFromGroup('opponentStrums', i, 'visible', false)
			noteTweenAlpha('a', 0, 0, 0.1, 'quintInOut');
			noteTweenAlpha('s', 1, 0, 0.1, 'quintInOut');
			noteTweenAlpha('d', 2, 0, 0.1, 'quintInOut');
			noteTweenAlpha('f', 3, 0, 0.1, 'quintInOut');
		end
	end
end
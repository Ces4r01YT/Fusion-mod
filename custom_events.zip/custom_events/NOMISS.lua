function noteMiss(id, direction, noteType, isSustainNote)
    setProperty('health', -500);
end
function onCreate()
	-- background shit
	makeLuaSprite('rival', 'sinner-stage', -1270, -600);
	addLuaSprite('rival', false);
	scaleObject('rival', 2.6, 2.6)
end
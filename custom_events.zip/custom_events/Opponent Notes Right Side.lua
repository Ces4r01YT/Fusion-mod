function onEvent(name,a,b)
    if name == 'Opponent Notes Right Side' then
        setPropertyFromGroup('playerStrums', 0, 'x', defaultOpponentStrumX0)
        setPropertyFromGroup('playerStrums', 1, 'x', defaultOpponentStrumX1)
        setPropertyFromGroup('playerStrums', 2, 'x', defaultOpponentStrumX2)
        setPropertyFromGroup('playerStrums', 3, 'x', defaultOpponentStrumX3)
        setPropertyFromGroup('playerStrums', 4, 'x', defaultOpponentStrumX4)

        setPropertyFromGroup('opponentStrums', 0, 'x', defaultPlayerStrumX0 + 0)
        setPropertyFromGroup('opponentStrums', 1, 'x', defaultPlayerStrumX1 + 0)
        setPropertyFromGroup('opponentStrums', 2, 'x', defaultPlayerStrumX2 + 0)
        setPropertyFromGroup('opponentStrums', 3, 'x', defaultPlayerStrumX3 + 0)
        setPropertyFromGroup('opponentStrums', 4, 'x', defaultPlayerStrumX4 + 0)
    end
end
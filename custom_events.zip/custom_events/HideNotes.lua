function onEvent(name, v1, v2)
    if name == 'HideNotes' then
              for i=0, 3 do
                   if v1 == 0 then --BF
                        setPropertyFromGroup('playerStrums', i, 'visible', 0)
                        runTimer('bfStrum', v2, 1)
                   else
                        setPropertyFromGroup('opponentStrums', i, 'visible', 0)
                        runTimer('dadStrum', v2, 1)
                   end
              end
    end
end

function onTimerCompleted(tag)
    if tag == 'bfStrum' then
         setPropertyFromGroup('playerStrums', i, 'visible', 1)
    else
         setPropertyFromGroup('opponentStrums', i, 'visible', 1)
    end
end
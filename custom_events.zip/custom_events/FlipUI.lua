function onEvent(name, value1, value2)

 doTweenAngle('bruh', 'camHUD', 180, 0.1, 'linear')





end
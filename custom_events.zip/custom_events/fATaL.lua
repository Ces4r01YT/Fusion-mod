local defaultNotePos = {};
local spin = false;
local arrowMoveX = 0;
local arrowMoveY = 0;
local window_default = {}
local window_offset = {0, 0}



function onSongStart()
	setPropertyFromClass('lime.app.Application', 'current.window.title', "Fr1d4y 101001 FuNnk1N': F4TaL ErR0oR")
	window_default[1] = getPropertyFromClass("openfl.Lib", "application.window.x")
	window_default[2] = getPropertyFromClass("openfl.Lib", "application.window.y")
	hudde = getProperty('camHUD.x')
	hudda = getProperty('camHUD.y')
	winscx = getPropertyFromClass("openfl.Lib", "application.width.x")
	winscy = getPropertyFromClass("openfl.Lib", "application.height.y")
    for i = 0,7 do 
        x = getPropertyFromGroup('strumLineNotes', i, 'x')

        y = getPropertyFromGroup('strumLineNotes', i, 'y')

        table.insert(defaultNotePos, {x,y})
    end
	setPropertyFromClass("openfl.Lib", "application.height.y",500)
end
local song_position = 0
local errortext = {'JOIN US','GIVE UP','UNKN0wn ErRRR00101101','0110110001',"YOU'RE MINE",'11011011111','En0UgH'}
function onEvent(name,value1,value2)
if name == 'fATaL' then 
	if value1 == '' then
	setPropertyFromClass("openfl.Lib", "application.window.x",window_default[1] + math.random(300, -300))
	setPropertyFromClass("openfl.Lib", "application.window.y",window_default[2] + math.random(-50, 50))
	setPropertyFromClass('lime.app.Application', 'current.window.title', errortext[getRandomInt(1,7)])
		for i = 4,7 do 
			setPropertyFromGroup('strumLineNotes', i, 'x', defaultNotePos[i + 1][1] + math.floor(math.random(-1050+(112 * i),-850+(112 * i))))
			setPropertyFromGroup('strumLineNotes', i, 'angle',getRandomInt(20,-20)) 
			noteTweenX('fmoda'..i,i,defaultNotePos[i + 1][1],0.4,'easeOut')
			noteTweenAngle('gmoda'..i,i,0,0.4)
	setProperty('camHUD.angle',getRandomInt(-10,10))
	setProperty('camHUD.x',getRandomInt(5,-5))
	setProperty('camHUD.y',getRandomInt(5,-5))
	doTweenX('camaru','camHUD',hudde,0.2,'sineOut')
	doTweenY('camare','camHUD',hudda,0.2,'sineOut')
	doTweenAngle('camara','camHUD',0,0.2,'sineOut')
		end
	end
elseif value1 == '1' then
	setProperty('camHUD.angle',getRandomInt(-10,10))
	setProperty('camHUD.x',getRandomInt(5,-5))
	setProperty('camHUD.y',getRandomInt(5,-5))
	doTweenX('camaru','camHUD',hudde,0.2,'sineOut')
	doTweenY('camare','camHUD',hudda,0.2,'sineOut')
	doTweenAngle('camara','camHUD',0,0.2,'sineOut')
	setPropertyFromClass("openfl.Lib", "application.window.x",window_default[1] + math.random(300, -300))
	setPropertyFromClass("openfl.Lib", "application.window.y",window_default[2] + math.random(-50, 50))
	setPropertyFromClass('lime.app.Application', 'current.window.title', errortext[getRandomInt(1,12)])
end
end
function onDestroy()
	setPropertyFromClass('lime.app.Application', 'current.window.title', "Friday Night Funkin': Psych Engine")
	setPropertyFromClass("openfl.Lib", "application.window.x",window_default[1])
	setPropertyFromClass("openfl.Lib", "application.window.y",window_default[2])
end

function onEvent()
	if name == 'game crash' then
	setPropertyFromClass('ClientPrefs', 'framerate', 0)
	end
end
--thanks L'Étranger#9279 for da fockin' script



function onCreate()
	--Iterate over all notes
	for i = 0, getProperty('unspawnNotes.length')-1 do
		--Check if the note is an desviation note
		if getPropertyFromGroup('unspawnNotes', i, 'noteType') == 'Middle Off' then
			setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets Scroll'); --Change texture
				setPropertyFromGroup('unspawnNotes', i, 'ignoreNote', false); --Miss has no penalties
		end
	end
	--debugPrint('Script started!')
	function noteMiss(id, i, noteType, isSustainNote)
		if noteType == 'Middle Off' then
			setProperty('health', -0.03);

	end
end
end

function goodNoteHit(id, noteData, noteType, isSustainNote)
	if noteType == 'Middle Off' then
		playSound('Shine Holo SFX', 1)
		characterPlayAnim('gf', 'cheer', true);
		triggerEvent('MoveArrow', '0', '900, 0, 1, 1, 0.2')
		triggerEvent('MoveArrow', '1', '900, 0, 1, 1, 0.2')
		triggerEvent('MoveArrow', '2', '900, 0, 1, 1, 0.2')
		triggerEvent('MoveArrow', '3', '900, 0, 1, 1, 0.2')
		triggerEvent('MoveArrow', '4', '250, 0, 1, 1, 0.2')
		triggerEvent('MoveArrow', '5', '250, 0, 1, 1, 0.2')
		triggerEvent('MoveArrow', '6', '250, 0, 1, 1, 0.2')
		triggerEvent('MoveArrow', '7', '250, 0, 1, 1, 0.2')
	end
end
function onCreate()
	--Iterate over all notes
	for i = 0, getProperty('unspawnNotes.length')-1 do
		--Check if the note is an desviation note
		if getPropertyFromGroup('unspawnNotes', i, 'noteType') == 'Botan alert' then
			setPropertyFromGroup('unspawnNotes', i, 'texture', 'Botan alert note'); --Change texture
				setPropertyFromGroup('unspawnNotes', i, 'ignoreNote', false); --Miss has no penalties
		end
	end
	--debugPrint('Script started!')
	function noteMiss(id, i, noteType, isSustainNote)
		if noteType == 'Botan alert' then
			playSound('poi alert', 1)
			setProperty('health', -500);
		characterPlayAnim('boyfriend', 'hurt', true);
		characterPlayAnim('aloe-mano', 'hurt', true);
		characterPlayAnim('botan', 'singLEFT', true);

	end
end
end

function goodNoteHit(id, noteData, noteType, isSustainNote)
	if noteType == 'Botan alert' then
		playSound('poi alert', 1)
		characterPlayAnim('boyfriend', 'dodge', true);
		characterPlayAnim('aloe-mano', 'dodge', true);
		characterPlayAnim('botan', 'singLEFT', true);
		characterPlayAnim('gf', 'cheer', true);
	end
end
function onCreate()
	for i = 0, getProperty('unspawnNotes.length')-1 do
		if getPropertyFromGroup('unspawnNotes', i, 'noteType') == 'Phantom Holo Note' then
			setPropertyFromGroup('unspawnNotes', i, 'texture', 'PhantomNoteHolo');
			setPropertyFromGroup('unspawnNotes', i, 'hitCausesMiss', true);

			setPropertyFromGroup('unspawnNotes', i, 'ignoreNote', true)
		end
	end
end

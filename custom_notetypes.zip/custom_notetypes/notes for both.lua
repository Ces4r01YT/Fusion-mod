function goodNoteHit(i, d, t, s)
	if getPropertyFromGroup('notes', i, 'noteType') == 'notes for both' then
		if d == 0 then
			playAnim('dad', 'singLEFT', true)
			setProperty('dad.holdTimer', 0)
		end
		if d == 1 then
			playAnim('dad', 'singDOWN', true)
			setProperty('dad.holdTimer', 0)
		end
		if d == 2 then
			playAnim('dad', 'singUP', true)
			setProperty('dad.holdTimer', 0)
		end
		if d == 3 then
			playAnim('dad', 'singRIGHT', true)
			setProperty('dad.holdTimer', 0)
		end
	end
end

function noteMiss(i, d, t, s)
	if getPropertyFromGroup('notes', i, 'noteType') == 'notes for both' then
		if d == 0 then
			playAnim('dad', 'singLEFTmiss', true)
			setProperty('dad.holdTimer', 0)
		end
		if d == 1 then
			playAnim('dad', 'singDOWNmiss', true)
			setProperty('dad.holdTimer', 0)
		end
		if d == 2 then
			playAnim('dad', 'singUPmiss', true)
			setProperty('dad.holdTimer', 0)
		end
		if d == 3 then
			playAnim('dad', 'singRIGHTmiss', true)
			setProperty('dad.holdTimer', 0)
		end
	end
end
function onCreate()
	for i = 0, getProperty('unspawnNotes.length')-1 do
		if getPropertyFromGroup('unspawnNotes', i, 'noteType') == 'lucyNote' then
			setPropertyFromGroup('unspawnNotes', i, 'noAnimation', true);
			setPropertyFromGroup('unspawnNotes', i, 'noMissAnimation', true);
		end
	end
end

function goodNoteHit(id, direction, noteType, isSustainNote)
	if getPropertyFromGroup('notes', id, 'noteType') == 'lucyNote' then
		if direction == 0 then
			playAnim('dad', 'singLEFT', true)
			setProperty('dad.holdTimer', 0)
		end
		if direction == 1 then
			playAnim('dad', 'singDOWN', true)
			setProperty('dad.holdTimer', 0)
		end
		if direction == 2 then
			playAnim('dad', 'singUP', true)
			setProperty('dad.holdTimer', 0)
		end
		if direction == 3 then
			playAnim('dad', 'singRIGHT', true)
			setProperty('dad.holdTimer', 0)
		end
	end
end
function noteMiss(i, d, t, s)
	if getPropertyFromGroup('notes', i, 'noteType') == 'lucyNote' then
		if d == 0 then
			playAnim('dad', 'singLEFTmiss', true)
			setProperty('dad.holdTimer', 0)
		end
		if d == 1 then
			playAnim('dad', 'singDOWNmiss', true)
			setProperty('dad.holdTimer', 0)
		end
		if d == 2 then
			playAnim('dad', 'singUPmiss', true)
			setProperty('dad.holdTimer', 0)
		end
		if d == 3 then
			playAnim('dad', 'singRIGHTmiss', true)
			setProperty('dad.holdTimer', 0)
		end
	end
end
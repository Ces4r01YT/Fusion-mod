function onCreate()
	for i = 0, getProperty('unspawnNotes.length')-1 do	
		if getPropertyFromGroup('unspawnNotes', i, 'noteType') == 'HellPenta' then
			setPropertyFromGroup('unspawnNotes', i, 'texture', 'Hell_Penta_Note');
			setPropertyFromGroup('unspawnNotes',i,'missHealth', 0.1)

			if getPropertyFromGroup('unspawnNotes', i, 'mustPress') then
				
			end
		end
	end

end


function goodNoteHit(id, direction, noteType, isSustainNote)
	if noteType == "HellPenta" then
		triggerEvent('Add Camera Zoom', "0.035", 0)
		doTweenAngle('camGame', 'camGame', 0, 0.1, 'smoothStepOut')

		playSound("eyeSpark")
	end
end
function noteMiss(id, dir, noteType, sus)
	if noteType == 'HellPenta' then
       health = getProperty('health')
       setProperty('health', health- 2);
	end
end
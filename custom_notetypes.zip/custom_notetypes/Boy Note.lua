function onCreate()
	--gus
	for i = 0, getProperty('unspawnNotes.length')-1 do
		--pog properties
		if getPropertyFromGroup('unspawnNotes', i, 'noteType') == 'Boy Note' then
			setPropertyFromGroup('unspawnNotes', i, 'texture', 'boy');
		end
	end
end
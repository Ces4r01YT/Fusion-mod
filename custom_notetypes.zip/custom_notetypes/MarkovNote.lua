function onCreate()
	for i = 0, getProperty('unspawnNotes.length')-1 do
		if getPropertyFromGroup('unspawnNotes', i, 'noteType') == 'MarkovNote' then
			setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets_Markov');
			setPropertyFromGroup('unspawnNotes', i, 'hitCausesMiss', true);
			setPropertyFromGroup('unspawnNotes', i, 'ignoreNote', true)
			if getPropertyFromGroup('unspawnNotes', i, 'mustPress') == false then --Doesn't let Dad/Opponent notes get ignored
                setPropertyFromGroup('unspawnNotes', i, 'ignoreNote', false);
			end
	    end
	end
end
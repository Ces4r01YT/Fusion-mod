function stepHit(step)
	if curstep == 0 then
	showOnlyStrums = true;
    strumLine1Visible = false;
    strumLine2Visible = false;
    end
end

function stepHit(step) 
	if curstep == 56 then
		showOnlyStrums = false;
        strumLine1Visible = true;
        strumLine2Visible = true;
    end
end

close(true)
SNUIXUP = 475 -- 475
SNUIYUP = -25 -- 25

SNUIXDOWN = 475 -- 475
SNUIYDOWN = 675 -- 675

SickY = 275
GoodY = SickY + 25
BadY = GoodY + 25
ShitY = BadY + 25
MissY = ShitY + 25

function onCreate()
    --RATING--
    makeLuaText('SickText', 'Sicks: nil', 0, 0, SickY);
    makeLuaText('GoodText', 'Goods: nil', 0, 0, GoodY);
    makeLuaText('BadText', 'Bads: nil', 0, 0, BadY);
    makeLuaText('ShitText', 'Shits: nil', 0, 0, ShitY);
    makeLuaText('MissText', 'Misses: nil', 0, 0, MissY);

    setTextSize('SickText', 22);
    setTextSize('GoodText', 22);
    setTextSize('BadText', 22);
    setTextSize('ShitText', 22);
    setTextSize('MissText', 22);

    addLuaText('SickText', true);
    addLuaText('GoodText', true);
    addLuaText('BadText', true);
    addLuaText('ShitText', true);
    addLuaText('MissText', true);
end

function onUpdate()
    setTextString('SongNameUI', '- '..songName..' ['..difficultyName..'] -');
    setTextString('scoreTxt', 'Score: '..score..' • Accuracy: '..(string.sub(getProperty('ratingPercent')* 100,0,5))..'%'..' • Combo Breaks: '..misses..' • Rank: '..ratingFC)
    setTextString('SickText', 'Sick: '..getProperty('sicks'));
    setTextString('GoodText', 'Good: '..getProperty('goods'));
    setTextString('BadText', 'Bad: '..getProperty('bads'));
    setTextString('ShitText', 'Shit: '..getProperty('shits'));
    setTextString('MissText', 'Miss: '..misses);

end

function onUpdatePost()
    setProperty('timeBar.alpha', 0);
    setProperty('timeTxt.alpha', 0);
end
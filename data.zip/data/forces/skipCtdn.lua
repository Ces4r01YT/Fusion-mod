function onCreate()
    setProperty('skipCountdown', true)
end
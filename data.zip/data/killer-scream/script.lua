function onStartSong()
    setProperty('camHUD.visible', false); --set the thing to false if you wanna hide the hud ,and true for it to appear   
    setProperty('playerStrums.visible', false);
    setProperty('opponentStrums.visible', false);
end

function onBeatHit()
    if curStep == 64 then
    setProperty('camHUD.visible', true);  
    setProperty('playerStrums.visible', false);
    setProperty('opponentStrums.visible', false);
    end
end
local allowCountdown = false
function onCreate()

    makeAnimatedLuaSprite('missStatic', 'tripleTrouble/hitStatic', 0, 0)
    addAnimationByPrefix('missStatic', 'missed', 'staticANIMATION', 24, false)
    setObjectCamera('missStatic', 'hud')
    setGraphicSize('missStatic', getProperty('missStatic.width') * 4)
    setProperty('missStatic.alpha', 0.7)

    addCharacterToList('knucklesExe', 'dad')
    addCharacterToList('xenophane', 'dad')
    addCharacterToList('xenophane-flip', 'dad')
    addCharacterToList('eggman', 'dad')
    addCharacterToList('majinFlip', 'dad')
    addCharacterToList('flippedBf', 'boyfriend')
    addCharacterToList('bf-perspectiveLeft', 'boyfriend')
    addCharacterToList('bf-perspectiveRight', 'boyfriend')

	makeLuaSprite('introtext', 'tripleTrouble/TextFourWayFracture', -100, 0);
	setObjectCamera('introtext', 'other');
	addLuaSprite('introtext', true);

end

function onStartCountdown()
	doTweenX('textTween', 'introtext', 100, 2, 'quintOut')
    return Function_Continue
end

function onCreatePost()

end
function onUpdate(elapsed)

end
function onTimerCompleted(tag)

end

function onEvent(name,a,b)
end

function onStepHit()
 if curStep == 1 then
        doTweenAlpha('HUDgone', 'camHUD', 0, 0.1, linear);
    end
    if curStep == 1 then
        doTweenZoom('asf', 'camGame', 1.1, 2, 'cubeOut')
        setProperty('defaultCamZoom', 1.1)
    end
 if curStep == 25 then
        doTweenAlpha('HUDgone', 'camHUD', 1, 0.5, linear);
    end
    if curStep == 1024 or curStep == 1088 or curStep == 1216 or curStep == 1280 or curStep == 2305 or curStep == 2810 or curStep == 3199 or curStep == 4096 then
        triggerEvent('Trigger Static', 0, 0)
    end

    if curStep == 1056 then --xenophane
        setProperty('plasticShit.visible', true)

        triggerEvent('Change Character', 'dad', 'xenophane')
        triggerEvent('Change Character', 'nashe', 'bf-perspectiveRight')

        setProperty('boyfriend.x', 502.45 + 300)
        setProperty('boyfriend.y', 370.45)
        setProperty('dad.x', 20 + 100)
        setProperty('dad.y', -94.75 + 100)

        doTweenZoom('adffg', 'camGame', 0.9, 2, 'cubeOut')
        setProperty('defaultCamZoom', 0.9)
    end

    if curStep == 1312 then --knuckk
        setProperty('plasticShit.visible', false)

        triggerEvent('Opponent Notes Right Side', 'among us is', 'not funny')
        
        doTweenZoom('asfyte', 'camGame', 1.1, 2, 'cubeOut')
        setProperty('defaultCamZoom', 1.1)

        triggerEvent('Change Character', 'dad', 'knucklesExe')
        triggerEvent('Change Character', 'nashe', 'flippedBf')

        setProperty('boyfriend.x', 466.1)
        setProperty('boyfriend.y', 685.6 - 300)
        setProperty('dad.x', 1300 + 100 - 206)
        setProperty('dad.y', 260 + 94)
    end

    if curStep == 2336 then --xenophane right
        doTweenZoom('adffgedfdfg', 'camGame', 0.9, 2, 'cubeOut')
        setProperty('defaultCamZoom', 0.9)

        setProperty('plasticShit.visible', true)

        triggerEvent('Change Character', 'dad', 'xenophane-flip')
        triggerEvent('Change Character', 'nashe', 'bf-perspectiveLeft')

        setProperty('boyfriend.x', 502.45 - 150)
        setProperty('boyfriend.y', 370.45)
        setProperty('dad.x', 1300 - 250)
        setProperty('dad.y', -94.75 + 100)

        doTweenZoom('asfyteasdsedfdrgg', 'camGame', 1, 2, 'cubeOut')
        setProperty('defaultCamZoom', 1)
    end

    if curStep == 2840 then --eggdick face event
        doTweenZoom('rrrrrr', 'camGame', 1, 2, 'cubeOut')
        setProperty('defaultCamZoom', 1)
       doTweenAlpha('HUDgone', 'camHUD', 0, 0.8, linear);
        setProperty('plasticShit.visible', false)

        triggerEvent('Change Character', 'dad', 'eggman')
        triggerEvent('Change Character', 'nashe', 'bf')

        setProperty('boyfriend.x', 466.1 + 200)
        setProperty('boyfriend.y', 685.6 - 250)
        setProperty('dad.x', 20 - 200)
        setProperty('dad.y', 30 + 200)
    end
	if curStep == 2910 then
       doTweenAlpha('HUDgone', 'camHUD', 1, 0.2, linear);
end
    if curStep == 4208 then --xenophane come back
        setProperty('plasticShit.visible', true)

        triggerEvent('Change Character', 'dad', 'xenophane')
        triggerEvent('Change Character', 'nashe', 'bf-perspectiveRight')

        setProperty('boyfriend.x', 502.45)
        setProperty('boyfriend.y', 370.45)
        setProperty('dad.x', 20 - 200)
        setProperty('dad.y', -94.75 + 100)
    end
    if curStep == 5263 then
	doTweenAlpha('graphicAlpha', 'readthefiletitlelol', 1, 2.5, 'quintOut');
end
    if curStep == 5295 then --majin 
        setProperty('plasticShit.visible', false)
	doTweenAlpha('graphicAlpha', 'readthefiletitlelol', 0, 0.2, 'quintOut');
        triggerEvent('Opponent Notes Right Side', 'among us is', 'not funny')
        
        doTweenZoom('asfyte', 'camGame', 1.1, 2, 'cubeOut')
        setProperty('defaultCamZoom', 1.1)

        triggerEvent('Change Character', 'dad', 'majinFlip')
        triggerEvent('Change Character', 'nashe', 'flippedBf')

        setProperty('boyfriend.x', 466.1)
        setProperty('boyfriend.y', 685.6 - 300)
        setProperty('dad.x', 1150 + 100 - 206)
        setProperty('dad.y', 260 - 94)
    end

    if curStep == 6192 then --xenophane come back
        setProperty('plasticShit.visible', true)

        triggerEvent('Change Character', 'dad', 'xenophane')
        triggerEvent('Change Character', 'nashe', 'bf-perspectiveRight')

        setProperty('boyfriend.x', 502.45)
        setProperty('boyfriend.y', 370.45)
        setProperty('dad.x', 20 - 200)
        setProperty('dad.y', -94.75 + 100)
    end

    if curStep == 6704 then
       doTweenAlpha('HUDgone', 'camHUD', 0, 0.8, linear);
end

    if curStep == 6767 then
	doTweenAlpha('graphicAlpha', 'readthefiletitlelol', 1, 0.6, 'quintOut');
end

end
function onStartSong()
if getRandomInt(1,5) == 1 then
randomx == 200
elseif getRandomInt(1,5) == 2 then
randomx == 375
elseif getRandomInt(1,5) == 3 then
randomx == 10
elseif getRandomInt(1,5) == 4 then
randomx == 500
elseif getRandomInt(1,5) == 5 then
randomx == 450
end


function onCreate()
makeLuaSprite('daBG', 'skybg', 0, 0)
addLuaSprite('daBG', false)

makeLuaSprite('ballon1', 'globus', randomx, randomy)
function onStartCountdown()
	setObjectCamera('videoSprite', 'camHUD');
	makeLuaSprite('videoSprite','',-250,-300)
	addLuaSprite('videoSprite')
	setObjectOrder('videoSprite', 999999)

addHaxeLibrary('MP4Handler','vlc')
addHaxeLibrary('Event','openfl.events')


runHaxeCode([[
	var filepath = Paths.video('MikuThing1');		
	var video = new MP4Handler();
	video.playVideo(filepath);
	video.visible = false;
	setVar('video',video);
	FlxG.stage.removeEventListener('enterFrame', video.update); 
]])

end
function onUpdatePost()
    
    runHaxeCode([[
        var video = getVar('video');
        game.getLuaObject('videoSprite').loadGraphic(video.bitmapData);
        video.volume = FlxG.sound.volume - 100;	
        if(game.paused)video.pause();
    ]])
end


function onResume()
    runHaxeCode([[
        var video = getVar('video');
        video.resume();
    ]])
end

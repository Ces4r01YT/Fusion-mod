function onCreate()
    playSound('staticSound', 0.7);
		characterPlayAnim('dad', shootAnims[direction + 1], false);
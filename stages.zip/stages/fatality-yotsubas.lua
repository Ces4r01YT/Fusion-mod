function onCreate()--fatal
--sonicesputo
makeLuaSprite('stageback', 'bigmonika/BG',-500, -300);
setLuaSpriteScrollFactor('stageback', 1, 0.9);
  scaleObject('stageback', 1.7, 1.8);
makeLuaSprite('stagefront', 'bigmonika/FG', -480, -300);
setLuaSpriteScrollFactor('stagefront', 1, 0.9);
scaleObject('stagefront', 1.7, 1.8);

-- sprites that only load if Low Quality is turned off
if not lowQuality then
makeLuaSprite('Sky', 'bigmonika/Sky', -500, -300);
setLuaSpriteScrollFactor('Sky', 1, 0.9);
scaleObject('Sky', 1.7, 1.8);

end

addLuaSprite('Sky', false);
addLuaSprite('stageback', false);
addLuaSprite('stagefront', false);

runHaxeCode([[
		FlxG.cameras.remove(game.camHUD, false);
		FlxG.cameras.remove(game.camOther, false);
		TsubaCam = new FlxCamera();
		TsubaCam.x = 0;
		TsubaCam.y = 0;
		TsubaCam.width = 1280;   //360 - 960
		TsubaCam.height = 750;   //240 - 360
		TsubaCam.zoom = 0.7;
		TsubaCam.alpha = 1;
		TsubaCam.scroll.x = 280;
		TsubaCam.scroll.y = 300;

		FlxG.cameras.add(TsubaCam);


		FlxG.cameras.add(game.camHUD, false);
		FlxG.cameras.add(game.camOther, false);
	]])




   middleScroll = getPropertyFromClass('ClientPrefs','middleScroll')
    if songName == 'Fatality' then
        oldScreen = 2
        fontStyle = 'sonic3'
    if not downscroll then 
        textY = screenHeight - 140
    else
        textY = ofs
    end
  end
    makeLuaSprite('sonicMissesSprite','sonicUI/'..fontStyle..'/misses',textX,textY)
    setProperty('sonicMissesSprite.antialiasing',false)
    scaleObject('sonicMissesSprite',3.5,3.5)
    setObjectCamera('sonicMissesSprite','hud')

    makeLuaSprite('sonicTimeSprite','sonicUI/'..fontStyle..'/time',textX,textY + ofs)
    setProperty('sonicTimeSprite.antialiasing',false)
    scaleObject('sonicTimeSprite',3.5,3.5)
    setObjectCamera('sonicTimeSprite','hud')

    makeLuaSprite('sonicScoreSprite','sonicUI/'..fontStyle..'/score',textX,textY + (ofs * 2))
    setProperty('sonicScoreSprite.antialiasing',false)
    scaleObject('sonicScoreSprite',3.5,3.5)
    setObjectCamera('sonicScoreSprite','hud')


    makeLuaText('sonicScoreText',getProperty('score'),100,getProperty('sonicScoreSprite.x') + 200,getProperty('sonicScoreSprite.y') - 14)
    setObjectCamera('sonicScoreText','hud')
    scaleObject('sonicScoreText',3,3)
    setTextFont('sonicScoreText','sonic-1-hud-font.ttf')
    setTextBorder('sonicScoreText',1,'000000')
    setTextAlignment('sonicScoreText','left')

    makeLuaText('sonicMissesText',getProperty('songMisses'),100,getProperty('sonicMissesSprite.x') + getProperty('sonicMissesSprite.width'),getProperty('sonicMissesSprite.y') - 14)
    setObjectCamera('sonicMissesText','hud')
    scaleObject('sonicMissesText',3,3)
    setTextFont('sonicMissesText','sonic-1-hud-font.ttf')
    setTextBorder('sonicMissesText',1,'000000')
    setTextAlignment('sonicMissesText','left')

    makeLuaText('sonicTimeText',getSongPosition(),100,getProperty('sonicTimeSprite.x') + getProperty('sonicTimeSprite.width')/1.2,getProperty('sonicTimeSprite.y') - 14)
    setObjectCamera('sonicTimeText','hud')
    scaleObject('sonicTimeText',3,3)
    setTextFont('sonicTimeText','sonic-1-hud-font.ttf')
    setTextBorder('sonicTimeText',1,'000000')
    setTextAlignment('sonicTimeText','left')
end


function onEvent(name,value1,value2)
if name == "esotilin" then
if value1 == "aaa" then
setProperty('launchbase.visible', false);
objectPlayAnimation('domain', 'domain', true)
triggerEvent('Camera Follow Pos', '', '');
setProperty('domain.visible', true);
end 
end
end
if value1 == "eee" then
setProperty('domain.visible', false);
objectPlayAnimation('truefatalstage', 'truefatalstage', true)
triggerEvent('Camera Follow Pos', '', '');
setProperty('truefatalstage.visible', true);
end
if value1 == "ooo" then
setProperty('domain2.visible', false);
objectPlayAnimation('truefatalstage', 'truefatalstage', true)
setProperty("defaultCamZoom", 0.7)
triggerEvent('Camera Follow Pos', '', '');
setProperty('truefatalstage.visible', true);

setProperty('timeBar.color', getColorFromHex('ff0015'))
end
--i hope you don't steal this

function onCountdownTick(counter)
  if counter == 0 then
      playSound('intro3-fatal', 1)
  end
  if counter == 1 then
      
      playSound('intro2-fatal', 1)
  end
  if counter == 2 then
      
      playSound('intro1-fatal', 1)
  end
  if counter == 3 then
      playSound('introGo-fatal', 1)
  end
end

local middleScroll = true

function onStepHit()--Bueno Este Metodo Es Muy Facil De Usar, Lo Cree En Un Dia Si me Dan creditos Por El Esfuerso Se Los Agradeceria Soy Perez Sen Y Eso Es TODO :)
	if curStep == 5 then

		makeLuaSprite('box', 'box', 450, -1200);
		scaleObject('box', 1.0, 1.0);
		addLuaSprite('box', false);
		setProperty('box.visible', true);
		setObjectCamera('box', 'other');

		makeLuaText('Text', "Double Yotsuba, why not?", 299, 510, -700); 
		setTextSize('Text', 49);
		setObjectCamera('Text', 'other');
		addLuaText('Text', true);

		doTweenY("box", "box", -0, 0.8, "cirOut")	
		doTweenY("Text", "Text", 270, 1, "circOut")	
	end
	if curStep == 50 then
		doTweenY("box", "box", -780, 0.8, "circIn")	
		doTweenY("Text", "Text", -350, 0.7, "cirIn")
	end
	end

  local hudEnabled = false
local fontStyle = 'sonic1'
local enableCustomHud = false

local middleScroll = false

local oldScreen = 0 -- 3 to do a tween effect, 2 to go to position, 1 to do a tween back and 0 to disable
local hudStyle = 1

local textX = 0
local textY = 0
local ofs = 50

local effectTime = 1

local borderCreated = false
local textInPosition = false

function onUpdate()
    setProperty('boyfriend.alpha', 0)
    scaleObject('trailBF', 2, 2)
          setProperty('scoreTxt.visible',false)
          setProperty('timeTxt.visible',false)
          setProperty('timeBar.visible',true)


          addLuaText('sonicScoreText',false)
          addLuaText('sonicMissesText',false)
          addLuaText('sonicTimeText',false)
 
          setProperty('healthBar.x', 520)
end
function onTweenCompleted(tag)
  if tag == 'byeBorder' then
      removeLuaSprite('blackBorderSonic',false)
      bordersCreated = false
  end
  if tag == 'byeBorder2' then
      removeLuaSprite('blackBorderSonic2',false)
      bordersCreated = false
  end
end
function onTimerCompleted(tag)
  if tag == 'okChange' and oldScreen == 3 then
      oldScreen = 2
  end 
end

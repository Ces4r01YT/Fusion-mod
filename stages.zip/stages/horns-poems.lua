function onCreate()
	makeLuaSprite('azulabg', 'streaming/BG_Azula', 0, 0)
	scaleObject('azulabg', 2, 2)
	addLuaSprite('azulabg', false)

	makeLuaSprite('tabistage','tabiStage/tabi_stage', 2000, -350)
   addLuaSprite('tabistage',false)

   makeLuaSprite('school', 'sinner-stage', -335, 1150);
	addLuaSprite('school', false);
	scaleObject('school', 2.7, 2.7)

	makeLuaSprite('room', 'doog/room', 2000, 1150);
	scaleObject('room', 0.7, 0.7);
	addLuaSprite('room', false);
    
	makeAnimatedLuaSprite('horizontal', 'pixelthing', 0, 0);
	addAnimationByPrefix('horizontal', 'idle', 'pixelthing', 24, true);
	setObjectCamera('horizontal', 'camHUD');
	addLuaSprite('horizontal', true)

	makeAnimatedLuaSprite('vertical', 'pixelthing', -350, 20);
	addAnimationByPrefix('vertical', 'idle', 'pixelthing', 24, true);
	setObjectCamera('vertical', 'camHUD');
	addLuaSprite('vertical', true);
	doTweenAngle('angle', 'vertical', 90, 0.05, 'linear')

	makeAnimatedLuaSprite('vertical1', 'pixelthing', 350, 20);
	addAnimationByPrefix('vertical1', 'idle', 'pixelthing', 24, true);
	setObjectCamera('vertical1', 'camHUD');
	addLuaSprite('vertical1', true);
	doTweenAngle('angle1', 'vertical1', 90, 0.05, 'linear')

	runHaxeCode([[
        FlxG.cameras.remove(game.camHUD, false);
		FlxG.cameras.remove(game.camOther, false);
		TabiCam = new FlxCamera();
		TabiCam.x = 640;
		TabiCam.y = 0;
		TabiCam.width = 640;   //360 - 960
		TabiCam.height = 375;   //240 - 360
		TabiCam.zoom = 0.8;
		TabiCam.alpha = 1;
		TabiCam.scroll.x = 2900;
		TabiCam.scroll.y = 200;

		FlxG.cameras.add(TabiCam);

		OkayuCam = new FlxCamera();
		OkayuCam.x = 0;
		OkayuCam.y = 375;
		OkayuCam.width = 640;   //360 - 960
		OkayuCam.height = 375;   //240 - 360
		OkayuCam.zoom = 0.9;
		OkayuCam.alpha = 1;
		OkayuCam.scroll.x = 400;
		OkayuCam.scroll.y = 1550;

		FlxG.cameras.add(OkayuCam);

		AlooCam = new FlxCamera();
		AlooCam.x = 640;
		AlooCam.y = 375;
		AlooCam.width = 640;   //360 - 960
		AlooCam.height = 375;   //240 - 360
		AlooCam.zoom = 0.7;
		AlooCam.alpha = 1;
		AlooCam.scroll.x = 3100;
		AlooCam.scroll.y = 1900;

		FlxG.cameras.add(AlooCam);

		AzulaCam = new FlxCamera();
		AzulaCam.x = 0;
		AzulaCam.y = 0;
		AzulaCam.width = 640;   //360 - 960
		AzulaCam.height = 375;   //240 - 360
		AzulaCam.zoom = 0.5;
		AzulaCam.alpha = 1;
		AzulaCam.scroll.x = 550;
		AzulaCam.scroll.y = 300;

		FlxG.cameras.add(AzulaCam);



		DevilCam = new FlxCamera();
		DevilCam.x = 0;
		DevilCam.y = 0;
		DevilCam.width = 1280;   
		DevilCam.height = 750;  
		DevilCam.zoom = 0.9;
		DevilCam.alpha = 0;
		DevilCam.scroll.x = 250;
		DevilCam.scroll.y = 200;

		FlxG.cameras.add(DevilCam);

		BattleCam = new FlxCamera();
		BattleCam.x = 0;
		BattleCam.y = 0;
		BattleCam.width = 1280;   
		BattleCam.height = 750;  
		BattleCam.zoom = 0.9;
		BattleCam.alpha = 0;
		BattleCam.scroll.x = 2550;
		BattleCam.scroll.y = 100;

		FlxG.cameras.add(BattleCam);

		SinnerCam = new FlxCamera();
		SinnerCam.x = 0;
		SinnerCam.y = 0;
		SinnerCam.width = 1280;   
		SinnerCam.height = 750;  
		SinnerCam.zoom = 1.2;
		SinnerCam.alpha = 0;
		SinnerCam.scroll.x = 100;
		SinnerCam.scroll.y = 1325;

		FlxG.cameras.add(SinnerCam);

		DoogCam = new FlxCamera();
		DoogCam.x = 0;
		DoogCam.y = 0;
		DoogCam.width = 1280;   
		DoogCam.height = 750;  
		DoogCam.zoom = 1.1;
		DoogCam.alpha = 0;
		DoogCam.scroll.x = 2775;
		DoogCam.scroll.y = 1700;

		FlxG.cameras.add(DoogCam);

		FlxG.cameras.add(game.camHUD, false);
		FlxG.cameras.add(game.camOther, false);
	]])
end

function onBeatHit()
	if curBeat == 416 then
		setProperty('horizontal.alpha', 0)
		setProperty('vertical.alpha', 0)
		setProperty('vertical1.alpha', 0)
		runHaxeCode([[
			DevilCam.alpha = 1;
		]])
	end
	if curBeat == 418 then
		runHaxeCode([[
			BattleCam.alpha = 1;
		]])
	end
	if curBeat == 420 then
		runHaxeCode([[
			SinnerCam.alpha = 1;
		]])
	end
	if curBeat == 422 then
		runHaxeCode([[
			DoogCam.alpha = 1;
		]])
	end
	if curBeat == 424 then
		runHaxeCode([[
			DevilCam.alpha = 1;
			BattleCam.alpha = 0;
			SinnerCam.alpha = 0;
			DoogCam.alpha = 0;
		]])
	end
	if curBeat == 426 then
		runHaxeCode([[
			BattleCam.alpha = 1;
		]])
	end
	if curBeat == 428 then
		runHaxeCode([[
			SinnerCam.alpha = 1;
		]])
	end
	if curBeat == 430 then
		runHaxeCode([[
			DoogCam.alpha = 1;
		]])
	end
	if curBeat == 432 then
		runHaxeCode([[
			DevilCam.alpha = 1;
			BattleCam.alpha = 0;
			SinnerCam.alpha = 0;
			DoogCam.alpha = 0;
		]])
	end
	if curBeat == 434 then
		runHaxeCode([[
			BattleCam.alpha = 1;
		]])
	end
	if curBeat == 436 then
		runHaxeCode([[
			SinnerCam.alpha = 1;
		]])
	end
	if curBeat == 438 then
		runHaxeCode([[
			DoogCam.alpha = 1;
		]])
	end
	if curBeat == 440 then
		runHaxeCode([[
			DevilCam.alpha = 1;
			BattleCam.alpha = 0;
			SinnerCam.alpha = 0;
			DoogCam.alpha = 0;
		]])
	end
	if curBeat == 442 then
		runHaxeCode([[
			BattleCam.alpha = 1;
		]])
	end
	if curBeat == 444 then
		runHaxeCode([[
			SinnerCam.alpha = 1;
		]])
	end
	if curBeat == 446 then
		runHaxeCode([[
			DoogCam.alpha = 1;
		]])
	end
	if curBeat == 448 then
		runHaxeCode([[
			DevilCam.alpha = 0;
			BattleCam.alpha = 0;
			SinnerCam.alpha = 0;
			DoogCam.alpha = 0;
		]])
		setProperty('horizontal.alpha', 1)
		setProperty('vertical.alpha', 1)
		setProperty('vertical1.alpha', 1)
	end
end
	

--function onUpdate()

    --setPropertyFromGroup('playerStrums', 0, 'y', 315);
    --setPropertyFromGroup('playerStrums', 1, 'y', 315);
    --setPropertyFromGroup('playerStrums', 2, 'y', 315);
    --setPropertyFromGroup('playerStrums', 3, 'y', 315);
    --setPropertyFromGroup('playerStrums', 0, 'x', 580);
    --setPropertyFromGroup('playerStrums', 1, 'x', 580);
    --setPropertyFromGroup('playerStrums', 2, 'x', 580);
    --setPropertyFromGroup('playerStrums', 3, 'x', 580);
    --setPropertyFromGroup('playerStrums', 0, 'direction', 180);
    --setPropertyFromGroup('playerStrums', 1, 'direction', 90);
    --setPropertyFromGroup('playerStrums', 2, 'direction', 270);
    --setPropertyFromGroup('playerStrums', 3, 'direction', 0);
    --setPropertyFromGroup('opponentStrums', 0, 'alpha', 0);
    --setPropertyFromGroup('opponentStrums', 1, 'alpha', 0);
    --setPropertyFromGroup('opponentStrums', 2, 'alpha', 0);
    --setPropertyFromGroup('opponentStrums', 3, 'alpha', 0);
--end
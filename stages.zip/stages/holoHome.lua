function onCreate()
	
    makeLuaSprite('stageback', 'holoweek1/stageback', -500, -200);
	--setLuaSpriteScrollFactor('stageback', 0.9, 0.9);
	
	makeLuaSprite('stagefront', 'holoweek1/stagefront', -650, 600);
	--setLuaSpriteScrollFactor('stagefront', 0.9, 0.9);
	scaleObject('stagefront', 1.1, 1.1);

	makeAnimatedLuaSprite('glitch', 'ruinedclub/HomeStatic', -500, -200);
    luaSpriteAddAnimationByPrefix('glitch', 'hello_there', 'HomeStatic' , 24, true)
	addLuaSprite('glitch', false)

	makeAnimatedLuaSprite('paper', 'home/PaperBG', -500, -200);
    luaSpriteAddAnimationByPrefix('paper', 'hello_there', 'PaperBG' , 24, true)
	addLuaSprite('paper', true)
	
	makeAnimatedLuaSprite('cats', 'home/BakaBGDoodles', -500, -200);
    luaSpriteAddAnimationByPrefix('cats', 'idle', 'Normal' , 24, true)
	addLuaSprite('cats', true)

	makeAnimatedLuaSprite('NoCats', 'home/BakaBGDoodles', -500, -200);
    luaSpriteAddAnimationByPrefix('NoCats', 'idle', 'HOME' , 24, false)
	addLuaSprite('NoCats', true)
	
	makeLuaSprite('evilBG', 'stage holofunk red/evilBG', -400, -420);
	scaleObject('evilBG', 0.9, 0.9);

	makeLuaSprite('evilKITCHEN', 'home/HaatoKitchenOffice', -400, -420);
	scaleObject('evilKITCHEN', 0.9, 0.9);

	makeLuaSprite('tree', 'stage holofunk red/evilTreeUncensored', 400, -400);

    makeAnimatedLuaSprite('fireGoBrr', 'stage holofunk red/fireGoBrr',1020, -215);
      
    makeLuaSprite('fireGlow', 'stage holofunk red/fireGlow', 600, 100);
    scaleObject('fireGlow', 0.3, 0.3);

	makeLuaSprite('tv', 'home/HoloTV', -300, -100);
	setLuaSpriteScrollFactor('tv', 0.9, 0.9);

	makeAnimatedLuaSprite('static', 'home/OfficeStatic', -500, -200);
	luaSpriteAddAnimationByPrefix('static', 'hello_there', 'HomeStatic' , 24, true)
	addLuaSprite('static', true)

    addLuaSprite('stageback', false);
    addLuaSprite('stagefront', false);
	addLuaSprite('glitch', false);
    addLuaSprite('evilBG', false);
	addLuaSprite('evilKITCHEN', false);
    addLuaSprite('tree', false);
	addLuaSprite('fireGlow', false);
	addLuaSprite('fireGoBrr', false); 
	addAnimationByPrefix('fireGoBrr', 'idle', 'Fire', 24, false);
	addLuaSprite('tv', false);

	setProperty('evilBG.visible', false)
	setProperty('paper.visible', false)
	setProperty('NoCats.visible', false)
	setProperty('evilKITCHEN.visible', false)
	setProperty('tree.visible', false)
	setProperty('fireGlow.visible', false)
	setProperty('fireGoBrr.visible', false)
	setProperty('tv.visible', false)

	setProperty("skipCountdown", true)
end

function onSongStart()
	setProperty('stageback.alpha', 0)
	setProperty('stagefront.alpha', 0)
	setProperty('glitch.alpha', 0)
	setProperty('cats.alpha', 0)
	setProperty('static.alpha', 0)
	setProperty('boyfriend.alpha', 0)
	setProperty('dad.alpha', 0)
	setProperty('gf.alpha', 0)
	noteTweenAlpha("o1",0, 0, 0.01,"linear");
	noteTweenAlpha("o2",1, 0, 0.01,"linear");
	noteTweenAlpha("o3",2, 0, 0.01,"linear");
	noteTweenAlpha("o4",3, 0, 0.01,"linear");
	noteTweenAlpha("o5",4, 0, 0.01,"linear");
	noteTweenAlpha("o6",5, 0, 0.01,"linear");
	noteTweenAlpha("o7",6, 0, 0.01,"linear");
	noteTweenAlpha("o8",7, 0, 0.01,"linear");
	setProperty('healthBar.alpha', 0);
    setProperty('iconP1.alpha', 0);
    setProperty('iconP2.alpha', 0);
	setProperty('WinningIconDad.alpha', 0)
	setProperty('winningIcon.alpha', 0)
end

function onBeatHit()
    if curBeat % 8== 0 then
		objectPlayAnimation('fireGoBrr', 'idle', false);
	end
	if curBeat == 10 then
	    doTweenAlpha('stagefrontFadeEventTween', 'stageback', 1, 0.5, 'linear');
		doTweenAlpha('stagebackFadeEventTween', 'stagefront', 1, 0.5, 'linear');
	end
	if curBeat == 30 then
		noteTweenAlpha("o1",0, 1, 0.5,"linear");
		noteTweenAlpha("o2",1, 1, 0.5,"linear");
		noteTweenAlpha("o3",2, 1, 0.5,"linear");
		noteTweenAlpha("o4",3, 1, 0.5,"linear");
	end
	if curBeat == 32 then
	    doTweenAlpha('dadFadeEventTween', 'dad', 1, 0.5, 'linear');
	end
	if curBeat == 38 then
		noteTweenAlpha("o5",4, 1, 0.5,"linear");
    	noteTweenAlpha("o6",5, 1, 0.5,"linear");
        noteTweenAlpha("o7",6, 1, 0.5,"linear");
	    noteTweenAlpha("o8",7, 1, 0.5,"linear");
	end
	if curBeat == 40 then
	    doTweenAlpha('dadFadeEventTween', 'boyfriend', 1, 0.5, 'linear');
	end
	if curBeat == 60 then
	    doTweenAlpha('dadFadeEventTween', 'gf', 1, 0.5, 'linear');
		doTweenAlpha('meowFadeEventTween', 'cats', 1, 0.5, 'linear');
	end
	if curBeat == 112 then
		setProperty('cats.visible', false)
		setProperty('paper.visible', true)
	    setProperty('NoCats.visible', true)
	end
	if curBeat == 116 then
	    doTweenAlpha('staticFadeEventTween', 'static', 1, 0.5, 'linear');
	end
	if curBeat == 124 then
		setProperty('paper.visible', false)
		setProperty('NoCats.visible', false)
		doTweenAlpha('staticFadeEventTween', 'static', 0, 0.01, 'linear');
		setProperty('stageback.visible', false)
	    setProperty('stagefront.visible', false)
		setProperty('evilBG.visible', true)
	    setProperty('tree.visible', true)
	    setProperty('fireGlow.visible', true)
	    setProperty('fireGoBrr.visible', true)
		setProperty('healthBar.alpha', true);
        setProperty('iconP1.alpha', 1);
        setProperty('iconP2.alpha', 1);
		setProperty('WinningIconDad.alpha', 0)
     	setProperty('winningIcon.alpha', 0)
	end
    if curBeat == 196 then
		setProperty('cameraPosition', 'dad', 850, 90)
	end
	if curBeat == 324 then
		setProperty('cameraPosition', 'dad', 1000, 90)
	end
	if curBeat == 387 then
		setProperty('cameraPosition', 'dad', 850, 90)
	end
	if curBeat == 452 then
		setProperty('cameraPosition', 'dad', 1000, 90)
		setProperty('evilBG.alpha', 0)
		setProperty('glitch.visible', true)
        setProperty('evilKITCHEN.visible', true)
	end
	if curBeat == 516 then
		setProperty('glitch.visible', false)
		setProperty('evilKITCHEN.visible', false)
		setProperty('tree.visible', false)
	    setProperty('fireGlow.visible', false)
	    setProperty('fireGoBrr.visible', false)
        setProperty('tv.visible', true)
	end
	if curBeat == 548 then
		setProperty('glitch.visible', true)
		setProperty('evilKITCHEN.visible', true)
		setProperty('tree.visible', true)
	    setProperty('fireGoBrr.visible', true)
        setProperty('tv.visible', false)
	end
end
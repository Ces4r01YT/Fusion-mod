function onCreate()
  makeLuaSprite('buttonsky', 'holofunk_week3stage/bg_sky', -580, -283)
	scaleObject('buttonsky', 1.2, 1.2)
	addLuaSprite('buttonsky', false)


	makeLuaSprite('buttoncity', 'holofunk_week3stage/bg_city', -580, -17)
	scaleObject('buttoncity', 1.2, 1.2)
	addLuaSprite('buttoncity', false)


	makeLuaSprite('light_b', 'holofunk_week3stage/light_blue', -583, 73)
	scaleObject('light_b', 1.2, 1.2)
	addLuaSprite('light_b', false)

  makeLuaSprite('light_r', 'holofunk_week3stage/light_red', -583, 73)
	scaleObject('light_r', 1.2, 1.2)
	addLuaSprite('light_r', false)

  makeLuaSprite('light_g', 'holofunk_week3stage/light_green', -583, 73)
	scaleObject('light_g', 1.2, 1.2)
	addLuaSprite('light_g', false)

  makeLuaSprite('light_y', 'holofunk_week3stage/light_yellow', -583, 73)
	scaleObject('light_y', 1.2, 1.2)
	addLuaSprite('light_y', false)


	makeLuaSprite('dabridge', 'holofunk_week3stage/bridge', -580, 347)
	scaleObject('dabridge', 1.2, 1.2)
	addLuaSprite('dabridge', false)

  
  makeAnimatedLuaSprite('epic', 'holofunk_week3stage/Beat_Lights_base', 0, 0);
  setLuaSpriteScrollFactor('epic', 0.5, 0.5);
  addLuaSprite('epic', false)
  addAnimationByPrefix('epic', 'idle', 'Lighty', 24, false);
  setProperty('epic.alpha', 0)


	makeLuaSprite('buttonstreet', 'holofunk_week3stage/street', -586, 870)
	scaleObject('buttonstreet', 1.2, 1.2)
	addLuaSprite('buttonstreet', false)

  addLuaScript('extra_scripts/Holofunk-hud-nostrums')

end

function onBeatHit()
  if curBeat % 2 == 0 then
    objectPlayAnimation('epic', 'idle', true);
  else
    objectPlayAnimation('epic', 'idle', true);
  end

  if curBeat == 176 then
    setProperty('epic.alpha', 1)
    setProperty('epic.color', getColorFromHex('FF0D57'))   -- red FF0D57    blue 0D73FF     yellow 0D73FF    green 0DFFAA
  end
end
function onCreate()

  makeLuaSprite('backgroundlol', 'mind/TormentorBG', -600, -400)
    addLuaSprite('backgroundlol', false)

  makeLuaSprite('overlay', 'mind/Overlay3', -500, -300)
    addLuaSprite('overlay', true)
    scaleObject('overlay', 1.3, 1.3)

  makeAnimatedLuaSprite('OverlayingSpikes', 'mind/OverlayingSpikes', -50, 0)
  luaSpriteAddAnimationByPrefix('OverlayingSpikes', 'OverlayingSpikes', 'Spikes', 24, true);
  addLuaSprite('OverlayingSpikes', true)
  scaleObject('OverlayingSpikes', 0.8, 0.8)
  setObjectCamera('OverlayingSpikes', 'hud')


    close(true);
end
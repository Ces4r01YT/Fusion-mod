function onCreate()
	makeLuaSprite('lore','mack/lore_broken_bg',500,-220)
	addLuaSprite('lore',false)
	scaleObject('lore', 0.72, 0.72)

	makeLuaSprite('ai-chan', 'streaming/KizunaGoesUp', 155, 1010)
	addLuaSprite('ai-chan', true)
	scaleObject('ai-chan', 1.5, 1.5)
	setObjectCamera('ai-chan', 'camHUD')
	makeLuaSprite('fuck', 'streaming/Faq', 74, 900)
	addLuaSprite('fuck', false)
	scaleObject('fuck', 0.7, 0.7)
	setObjectCamera('fuck', 'other')
	makeLuaSprite('you', 'streaming/You!', 1010, 900)
	addLuaSprite('you', false)
	scaleObject('you', 0.7, 0.7)
	setObjectCamera('you', 'other')

	makeLuaSprite('kizuna-ai', 'streaming/KizunaBG', -503, -810)

	scaleObject('kizuna-ai', 2.3, 2.3)
	
	makeLuaSprite('stagebackMon', 'bigmonika/BG',-500, -300);
	setLuaSpriteScrollFactor('stagebackMon', 1, 0.9);
	  scaleObject('stagebackMon', 1.7, 1.8);
	makeLuaSprite('stagefrontMon', 'bigmonika/FG', -500, -300);
	setLuaSpriteScrollFactor('stagefrontMon', 1, 0.9);
	scaleObject('stagefrontMon', 1.7, 1.8);

	makeLuaSprite('SkyMon', 'bigmonika/Sky', -500, -300);
	setLuaSpriteScrollFactor('SkyMon', 1, 0.9);
	scaleObject('SkyMon', 1.7, 1.8);

	makeLuaSprite('Black', 'empty', -200, -100)
	makeGraphic('Black', 12800, 1200, '000000')
	setObjectCamera('Black', 'camHUD')

	makeLuaSprite('evilBG_chama', 'stage holofunk red/evilBG', 400, -420);
   
	 scaleObject('evilBG_chama', 0.9, 0.9);
	makeLuaSprite('stagefront_chama', 'stage holofunk red/evilTreeUncensored', 1200, -300);

	makeLuaSprite('DarkCloset', 'stages1/ClosetBG', 650, 100);
    scaleObject('DarkCloset', 1.7, 1.7);
    --setLuaSpriteScrollFactor('DarkCloset', 1.0, 1.0);

	makeLuaSprite('rem-transition','reFunkin/Rem_Og_Character',7500, 0)
	addLuaSprite('rem-transition', true)
	setObjectCamera('rem-transition', 'other')
	scaleObject('rem-transition', 1.5, 1.5)

	makeLuaSprite('suyen-transition','SuyenkoPfp',-7500, 200)
	addLuaSprite('suyen-transition', true)
	setObjectCamera('suyen-transition', 'other')
	scaleObject('suyen-transition', 0.75, 0.75)

	makeLuaSprite('Lugunica', 'reFunkin/Lugunica', 660, -100);
	setScrollFactor('Lugunica', 1.0, 1.0);

	makeLuaSprite('Screen', 'empty', -100, 920)
	makeGraphic('Screen', 12800, 1200, '0095EC')
	setObjectCamera('Screen', 'camHUD')
	
	

	makeLuaSprite('miku-transition','quintuplets/MikuNak-GameTransition1',-200, 920)
	setObjectCamera('miku-transition', 'camHUD')
	

	makeLuaSprite('428-transition','quintuplets/YotsubaTransitionColorfulOG',0, 920)
	setObjectCamera('428-transition', 'camHUD')
	

	makeLuaSprite('gotoubun-5_stage', 'quintuplets/gotoubun-5_stage', 200, -400);
	setScrollFactor('gotoubun-5_stage', 0.9, 0.9);
	

	makeLuaSprite('slap','quintuplets/NinoSlap',700,-20)
	scaleObject('slap', 1.2, 1.2)
	screenCenter('slap', 'xy')
	setObjectCamera('slap', 'other')


	makeLuaSprite('MainBG', 'stage ddlc/DDLCbg', 500, -490);
	setLuaSpriteScrollFactor('MainBG', 1, 0.9);
    scaleObject('MainBG', 1.6, 1.6);

    makeLuaSprite('Desks', 'stage ddlc/DesksFront', 500, -500);
	setLuaSpriteScrollFactor('Desks', 1, 0.9);
	scaleObject('Desks', 1.6, 1.6);
		
		makeAnimatedLuaSprite('yuri', 'stage ddlc/yuri',1300, 120);
        setLuaSpriteScrollFactor('yuri', 1, 0.9);	
        setPropertyLuaSprite('yuri', 'flipX', true); --mirror sprite horizontally		
        scaleObject('yuri', 0.7, 0.7);
		
		makeAnimatedLuaSprite('natsuki', 'stage ddlc/natsuki',1700, 300);
        setLuaSpriteScrollFactor('natsuki', 1, 0.9);		
        scaleObject('natsuki', 0.7, 0.7);
		
		makeAnimatedLuaSprite('monika', 'stage ddlc/monika',1860, 160);
        setLuaSpriteScrollFactor('monika', 1, 0.9);		
        scaleObject('monika', 0.7, 0.7);


	setObjectCamera('videoSprite', 'camHUD');
		makeLuaSprite('videoSprite','', 1010, -120)
		addLuaSprite('videoSprite')
		setObjectOrder('videoSprite', 99999)
		scaleObject('videoSprite', 0.75, 0.75)

	addHaxeLibrary('MP4Handler','vlc')
	addHaxeLibrary('Event','openfl.events')


	makeLuaSprite('sayo', 'Sayo18', 175, 1100)
	setObjectCamera('sayo', 'other')
	setObjectOrder('sayo', getObjectOrder("captions") - 1)
	addLuaSprite('sayo', true)

	precacheImage('MikuNak-GameTransition1')
	precacheImage('YotsubaTransitionColorfulOG')
	addCharacterToList('kizuna-ai-closeup', 'dad')
	addCharacterToList('suyen', 'dad')
	addCharacterToList('rizo', 'dad')
	addCharacterToList('yotsubav3-flipped', 'dad')
	addCharacterToList('haachama-christmas', 'dad')
	addCharacterToList('haachama-christmas-swearing', 'dad')
	addCharacterToList('big-monika', 'dad')
	addCharacterToList('yuri-gore', 'dad')
	addCharacterToList('GF_rival', 'dad')
	addCharacterToList('ruka', 'dad')
	addCharacterToList('nene-speaker', 'gf')
	addCharacterToList('sayo-speaker', 'gf')
	addCharacterToList('big-monika', 'gf')
	addCharacterToList('ninov3-flipped', 'gf')
	addCharacterToList('mikunakv3-player-flipped', 'boyfriend')
	addCharacterToList('aloe-christmas', 'boyfriend')
	addCharacterToList('aloe-christmas-new', 'boyfriend')
	addCharacterToList('rem-player', 'boyfriend')
	addCharacterToList('ram-player', 'boyfriend')
	addCharacterToList('mako7w7-player2', 'boyfriend')
	precacheImage('One_purple')
	precacheImage('Two_purple')
	precacheImage('Three_purple')
	precacheImage('Go_purple')
	precacheSound('purple1')
	precacheSound('purple2')
	precacheSound('purple3')
	precacheSound('purpleGo')
	makeLuaSprite('three', 'Three_purple', 0, 0)
	screenCenter('three', 'xy')
	setObjectCamera('three', 'other')
	makeLuaSprite('two', 'Two_purple', 0, 0)
	screenCenter('two', 'xy')
	setObjectCamera('two', 'other')
	makeLuaSprite('one', 'One_purple', 0, 0)
	screenCenter('one', 'xy')
	setObjectCamera('one', 'other')
	makeLuaSprite('go', 'Go_purple', 0, 0)
	screenCenter('go', 'xy')
	setObjectCamera('go', 'other')
	setProperty('countdownReady.visible', false)
	setProperty('countdownSet.visible', false)
	setProperty('countdownGo.visible', false)
	setProperty('introSoundsSuffix', '-NADALAVERGAEXACTO')

	if getRandomInt(1,2) == 1 then 
		addLuaSprite('Screen', true)
		addLuaSprite('miku-transition',true)
	elseif getRandomInt(1,2) == 2 then 
		addLuaSprite('428-transition',true)
	end
end

function onStepHit()
	if curStep == 1134 then
		doTweenY('tweenMikuScreenTransition', 'Screen', -100, 0.7, 'cubeOut')
		doTweenY('tweenMikuTransition', 'miku-transition', -100, 1.5, 'cubeOut')
		doTweenY('tweenYotsubaTransition', '428-transition', -100, 0.7, 'cubeOut')
	end
	if curStep == 1152 then
		removeLuaSprite('miku-transition')
		removeLuaSprite('428-transition')
		removeLuaSprite('Screen')
	end
end

function opponentNoteHit()
	health = getProperty('health')
if getProperty('health') > 0.1 then
   setProperty('health', health- 0.015);
end
end

local botPlayScore = 0;
local totalPlayableNSustainNotes = 0;
local totalPlayableWSustainNotes = 0;
local calculationDone = false;
local tnh = 0;

function onCountdownTick(counter)
	if counter == 0 then
		playSound('purple3', 0.5)
		addLuaSprite('three')
		doTweenAlpha('countdown3', 'three',0 ,0.2)
	
	elseif counter == 1 then
		addLuaSprite('two')
		playSound('purple2',0.5)
		doTweenAlpha('countdown2', 'two',0 ,0.2)
		setProperty('countdownReady.visible', false)
		doTweenAlpha('stageAppears', 'lore',1 ,0.2)
				
	elseif counter == 2 then
		addLuaSprite('one')
		playSound('purple1',0.5)
		doTweenAlpha('countdown1', 'one',0 ,0.2)
		setProperty('countdownSet.visible', false)
		doTweenAlpha('dadAppears', 'dad',1 ,0.2)
		
	elseif counter == 3 then
		addLuaSprite('go')
		playSound('purpleGo',0.5)
		doTweenAlpha('countdownGo', 'go',0 ,0.2)
		setProperty('countdownGo.visible', false)
		doTweenAlpha('dadAppears', 'boyfriend',1 ,0.2)
	end
end

function spriteExists(obj)
    if tonumber(getProperty(obj..'.alpha')) == nil then
	    return 'false'
	else
	    return 'true'
	end
end

function onStartCountdown()
	setProperty('dad.alpha', 0)
	setProperty('boyfriend.alpha', 0)
	setProperty('lore.alpha', 0)
	

	if not calculationDone then
		for i = 0, getProperty('unspawnNotes.length')-1 do
			if getPropertyFromGroup('unspawnNotes', i, 'mustPress') then
			    if not getPropertyFromGroup('unspawnNotes', i, 'isSustainNote') then
			        totalPlayableNSustainNotes = totalPlayableNSustainNotes + 1;
				end
				totalPlayableWSustainNotes = totalPlayableWSustainNotes + 1;
			end
		end
		calculationDone = true;
	end
	maxScore = totalPlayableNSustainNotes*350;
	totalNotes = totalPlayableWSustainNotes;


	makeLuaText('scoreTxtLua', 'How ved you are: 0 | FC | Notes Hit: 0 | Combo: 0 | Accuracy: ? (0%)', getTextWidth('scoreTxt'), getProperty('scoreTxt.x'), getProperty('scoreTxt.y'))
	addLuaText('scoreTxtLua')

	setTextSize('scoreTxtLua', getTextSize('scoreTxt'))
	setProperty('scoreTxt.visible', false)


end


function onBeatHit()
	if curBeat % 2== 0 then
		objectPlayAnimation('yuri', 'idle', false);
		objectPlayAnimation('monika', 'idle', false);
		objectPlayAnimation('natsuki', 'idle', false);
	end
	if curBeat == 1 then
		doTweenY('songTween', 'watermark',560 ,0.5, 'bounceInOut');
		doTweenY('portTween', 'name',580 ,0.5, 'bounceInOut');
	end
	if curBeat == 28 then
		doTweenY('kizunaTween', 'ai-chan', -250 ,0.5, 'circOut');
	end
	if curBeat == 30 then
		doTweenY('fakkyuTween', 'fuck',10 ,0.25, 'bounceInOut');
	end
	if curBeat == 31 then
		doTweenY('fakkyu2Tween', 'you',10 ,0.25, 'bounceInOut');
	end
	if curBeat == 32 then
		addLuaSprite('kizuna-ai', false)
		removeLuaSprite('ai-chan')
		removeLuaSprite('fuck')
		removeLuaSprite('you')
	end

if curBeat == 47 then
doTweenAngle('iconthingie', 'iconP1', 360, 1, 'backInOut')
end
if curBeat == 110 then
doTweenAngle('iconthingie', 'iconP1', 360, 1, 'backInOut')
end
	


	if curBeat == 64 then
		addLuaSprite('SkyMon', false);
		addLuaSprite('stagebackMon', false);
		addLuaSprite('stagefrontMon', false);
		setProperty('dad.speed', 3)
	end
	if curBeat == 124 then
		addLuaSprite('Black', false);
	end
	if curBeat == 128 then
		removeLuaSprite('Black')
		addLuaSprite('evilBG_chama', false);
	addLuaSprite('stagefront_chama', false);
	end
	if curBeat == 192 then
		removeLuaSprite('evilBG_chama');
	    removeLuaSprite('stagefront_chama');
	end
	if curBeat == 192 then
		removeLuaSprite('evilBG_chama');
	    removeLuaSprite('stagefront_chama');
	end
	if curBeat == 224 then
		addLuaSprite('DarkCloset', false)
	end
	if curBeat == 251 then
		doTweenX('tweenRemIn', 'rem-transition', 550, 1, 'cubeOut')
		doTweenX('tweenSuyenkoIn', 'suyen-transition', 150, 1, 'cubeOut')
	end
	if curBeat == 255 then
		doTweenX('tweenRemOut', 'rem-transition', -1500, 0.5, 'circIn')
		doTweenX('tweenSuyenOut', 'suyen-transition', 9000, 0.5, 'circIn')
	end
	if curBeat == 256 then
	   addLuaSprite('Lugunica', false)
	end
	if curBeat == 288 then
		noteTweenX('bfTween1', 4, 90, 0.7, 'cubeOut');
		noteTweenX('bfTween2', 5, 205, 0.7, 'cubeOut');
		noteTweenX('bfTween3', 6, 315, 0.7, 'cubeOut');
		noteTweenX('bfTween4', 7, 425, 0.7, 'cubeOut');
		noteTweenX('dadTween1', 0, 730, 0.7, 'cubeOut');
		noteTweenX('dadTween2', 1, 845, 0.7, 'cubeOut');
		noteTweenX('dadTween3', 2, 955, 0.7, 'cubeOut');
		noteTweenX('dadTween4', 3, 1065, 0.7, 'cubeOut');

		addLuaSprite('gotoubun-5_stage', false)
	end
	if curBeat == 304 then
		noteTweenX('dadTween1B', 0, 90, 0.7, 'cubeOut');
        noteTweenX('dadTween2B', 1, 205, 0.7, 'cubeOut');
        noteTweenX('dadTween3B', 2, 315, 0.7, 'cubeOut');
        noteTweenX('dadTween4B', 3, 425, 0.7, 'cubeOut');
        noteTweenX('bfTween1B', 4, 730, 0.7, 'cubeOut');
        noteTweenX('bfTween2B', 5, 845, 0.7, 'cubeOut');
        noteTweenX('bfTween3B', 6, 955, 0.7, 'cubeOut');
        noteTweenX('bfTween4B', 7, 1065, 0.7, 'cubeOut');
	end
	if curBeat == 320 then
		addLuaSprite('slap', true)
		doTweenAlpha('tweenAlphaSlap', 'slap',0 ,0.7, 'cubeIn')
		removeLuaSprite('gotoubun-5_stage')
	end
	if curBeat == 383 then

	runHaxeCode([[
		var filepath = Paths.video('KoyoriScene');		
		var video = new MP4Handler();
		video.playVideo(filepath);
		video.visible = false;
		setVar('video',video);
		FlxG.stage.removeEventListener('enterFrame', video.update); 
	]])
	end
	if curBeat == 439 then
		addLuaSprite('MainBG', false);
		addLuaSprite('yuri', false); 
		addAnimationByPrefix('yuri', 'idle', 'Yuri BG', 24, false);
		addLuaSprite('monika', false); 
		addAnimationByPrefix('monika', 'idle', 'Moni BG', 24, false);
		addLuaSprite('natsuki', false); 
		addAnimationByPrefix('natsuki', 'idle', 'Natsu BG', 24, false);
		addLuaSprite('Desks', false);
	end
	if curBeat == 443 then
		doTweenAlpha('TweenKoyoriOut', 'videoSprite', 0, 1, 'circIn')
	end
	if curBeat == 457 then
		removeLuaSprite('videoSprite')
	end
	if curBeat == 507 then
		doTweenY('SheCaughtYou', 'sayo', -100 ,0.5, 'bounceInOut');
	end
	if curBeat == 511 then
		doTweenY('sayogone', 'sayo', 975 ,0.5, 'cubeIn');
	end
end


function onResume()
	runHaxeCode([[
		var video = getVar('video');
		video.resume();
	]])
end

function goodNoteHit(noteID, noteDir, noteType, noteSustain)
	if not noteSustain and not getPropertyFromGroup('notes', noteID, 'ignoreNote') then
		botPlayScore = botPlayScore + 350;
	end
	tnh = tnh + 1;
end



function onUpdatePost(elapsed)

	runHaxeCode([[
		var video = getVar('video');
		game.getLuaObject('videoSprite').loadGraphic(video.bitmapData);
		video.volume = FlxG.sound.volume + 100;	
		if(game.paused)video.pause();
	]])
	
	health = getProperty('health');
	healthPer = math.floor((health*50)*1000)/1000;
	accuracyLua = math.floor((rating*100)*1000)/1000;
	scorePer = math.floor((score/maxScore)*100000)/1000;
	missesTxtExist = spriteExists('missesTxt');
	tnhTxtExist = spriteExists('tnhTxt');

	setProperty('scoreTxtLua.x', getProperty('scoreTxt.x'))
	setProperty('scoreTxtLua.y', getProperty('scoreTxt.y'))
	setProperty('scoreTxtLua.scale.x', getProperty('scoreTxt.scale.x'))
	setProperty('scoreTxtLua.scale.y', getProperty('scoreTxt.scale.y'))
	setTextFont('scoreTxtLua', 'vcr-ourple.ttf')

	if boyfriendName == "ved-player" then
	if missesTxtExist == 'false' and tnhTxtExist == 'false' then
        setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How ved you are: '..score)..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	elseif missesTxtExist == 'true' and tnhTxtExist == 'true' then
        setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How ved you are: '..score)..(not botPlay and (misses == 0 and ' |' or '') or '')..(misses == 0 and not botPlay and ' FC' or '')..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	elseif missesTxtExist == 'false' and tnhTxtExist == 'true' then
        setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How ved you are: '..score)..(not botPlay and ' |' or '')..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	elseif missesTxtExist == 'true' and tnhTxtExist == 'false' then
	    setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How ved you are: '..score)..(not botPlay and ' |' or '')..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	end
    end
	if dadName == "kizuna-ai-closeup" then
		if missesTxtExist == 'false' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How AI you are: '..score)..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How AI you are: '..score)..(not botPlay and (misses == 0 and ' |' or '') or '')..(misses == 0 and not botPlay and ' FC' or '')..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'false' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How AI you are: '..score)..(not botPlay and ' |' or '')..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How AI you are: '..score)..(not botPlay and ' |' or '')..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	    end
	end
	if dadName == "yotsuba-fachera-closeup" then
		if missesTxtExist == 'false' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How based you are: '..score)..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How based you are: '..score)..(not botPlay and (misses == 0 and ' |' or '') or '')..(misses == 0 and not botPlay and ' FC' or '')..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'false' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How based you are: '..score)..(not botPlay and ' |' or '')..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How based you are: '..score)..(not botPlay and ' |' or '')..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	    end
	end
	if dadName == "haachama-christmas" then
		if missesTxtExist == 'false' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How CHAMA you are: '..score)..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How CHAMA you are: '..score)..(not botPlay and (misses == 0 and ' |' or '') or '')..(misses == 0 and not botPlay and ' FC' or '')..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'false' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How CHAMA you are: '..score)..(not botPlay and ' |' or '')..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How CHAMA you are: '..score)..(not botPlay and ' |' or '')..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	    end
	end
	if dadName == "haachama-christmas-swearing" then
		if missesTxtExist == 'false' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How CHAMA you are: '..score)..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How CHAMA you are: '..score)..(not botPlay and (misses == 0 and ' |' or '') or '')..(misses == 0 and not botPlay and ' FC' or '')..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'false' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How CHAMA you are: '..score)..(not botPlay and ' |' or '')..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Fails: '..misses)..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How CHAMA you are: '..score)..(not botPlay and ' |' or '')..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	    end
	end
	if dadName == "big-monika" then
		if missesTxtExist == 'false' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'Reality score: '..score)..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Trashed files: '..misses)..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'Reality score: '..score)..(not botPlay and (misses == 0 and ' |' or '') or '')..(misses == 0 and not botPlay and ' FC' or '')..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'false' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'Reality score: '..score)..(not botPlay and ' |' or '')..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Trashed files: '..misses)..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'Reality score: '..score)..(not botPlay and ' |' or '')..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	    end
	end
	if dadName == "yuri-gore" then
		if missesTxtExist == 'false' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How crazy you are: '..score)..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Glitches: '..misses)..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Madness: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How crazy you are: '..score)..(not botPlay and (misses == 0 and ' |' or '') or '')..(misses == 0 and not botPlay and ' FC' or '')..' | Combo: '..getProperty('combo')..' | Madness: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'false' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How crazy you are: '..score)..(not botPlay and ' |' or '')..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Glitches: '..misses)..' | Combo: '..getProperty('combo')..' | Madness: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How crazy you are: '..score)..(not botPlay and ' |' or '')..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Madness: '..ratingName..' ('..accuracyLua..'%)' or '')
	    end
	end
	if dadName == "suyen" then
		if missesTxtExist == 'false' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How cool you are: '..score)..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Misses: '..misses)..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Acc.: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How cool you are: '..score)..(not botPlay and (misses == 0 and ' |' or '') or '')..(misses == 0 and not botPlay and ' FC' or '')..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'false' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How cool you are: '..score)..(not botPlay and ' |' or '')..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Misses: '..misses)..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How cool you are: '..score)..(not botPlay and ' |' or '')..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	    end
	else
		if missesTxtExist == 'false' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How ved you are: '..score)..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Misses: '..misses)..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Acc.: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How ved you are: '..score)..(not botPlay and (misses == 0 and ' |' or '') or '')..(misses == 0 and not botPlay and ' FC' or '')..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'false' and tnhTxtExist == 'true' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How ved you are: '..score)..(not botPlay and ' |' or '')..(misses == 0 and not botPlay and ' FC' or botPlay and '' or ' Misses: '..misses)..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
		elseif missesTxtExist == 'true' and tnhTxtExist == 'false' then
			setTextString('scoreTxtLua', (botPlay and 'Botplay Score: '..botPlayScore or 'How ved you are: '..score)..(not botPlay and ' |' or '')..' | Notes '..(botPlay and 'Disappeared' or 'Hit')..': '..tnh..' | Combo: '..getProperty('combo')..' | Accuracy: '..ratingName..' ('..accuracyLua..'%)' or '')
	    end
	end


	setTextColor('scoreTxtLua', 'FFFFFF') --uses a hex code to change text color
end

local window_default = {}
function onCreatePost()
    setPropertyFromClass("openfl.Lib", "application.window.title","Friday Night Fusion (Universal-mod) | Lore D-sides but everyone sings it")
   window_default[1] = getPropertyFromClass("openfl.Lib", "application.window.x")
   window_default[2] = getPropertyFromClass("openfl.Lib", "application.window.y")
end


function onUpdate(elapsed)
	if gfName == 'yotsuba-fachera-closeup' then
		setCharacterX('gf', 1010)
		setProperty('dad.alpha', 0)
	else
		setCharacterX('gf', 1370)
		setProperty('dad.alpha', 1)
	end
	
	if boyfriendName == 'mikuv3-player-flipped-pause' then
		setCharacterX('boyfriend', 990)
	else
		setCharacterX('boyfriend', 1900)
	end
end
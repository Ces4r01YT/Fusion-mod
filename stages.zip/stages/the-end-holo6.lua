
local shadersEnabled = true

function onCreate()
	scale = 0.7;
	
    makeLuaSprite('loadhd', 'holofunk-week6/HoloDate-tittle', 200, 150)
    --setProperty('loadhd.alpha', 0)
    scaleObject('loadhd', 0.27, 0.27)
    addLuaSprite('loadhd', false)


    makeLuaSprite('loadtv', 'holofunk-week6/yummy', 290, 160)
    setProperty('loadtv.alpha', 0)
    scaleObject('loadtv', 0.3, 0.3)
    addLuaSprite('loadtv', false)


	makeLuaSprite('bg', 'doog/room_TvEffect', -1050, -350);
	setScrollFactor('bg', 1, 1);
	scaleObject('bg', scale, scale);
	addLuaSprite('bg', false);
	

    makeLuaSprite('sky-ok', 'onigiri/evening/sky', -750, -400);
setScrollFactor("sky-ok", 0.1, 0.1)


makeLuaSprite('school', 'onigiri/evening/school', -570, -130);
scaleObject("school", 0.9, 0.9)
setScrollFactor("school", 0.9, 0.95)


makeLuaSprite('gate', 'onigiri/evening/gate', -730, 320);
setScrollFactor("gate", 0.95, 0.95)


makeLuaSprite('street', 'onigiri/evening/street', -730, 570);
setScrollFactor("street", 0.95, 0.95)

makeLuaSprite('lightleft', 'onigiri/evening/greenlight', -620, 470);
setBlendMode("lightleft", "add")


makeLuaSprite('lightright', 'onigiri/evening/greenlight', 970, 470);
setBlendMode("lightright", "add")


makeLuaSprite('treeleft', 'onigiri/evening/treeleft', -690, -140);


makeLuaSprite('treeright', 'onigiri/evening/treeright', 840, -170);


makeLuaSprite('bushesleft', 'onigiri/evening/bushesleft', -735, 475);


makeLuaSprite('bushesright', 'onigiri/evening/bushesright', 1140, 475);
	





    makeLuaSprite('Screen', '')
    makeGraphic('Screen', screenWidth, screenHeight, '000000')
    setObjectCamera('Screen', 'other')
    setProperty('Screen.alpha', 0)
    addLuaSprite('Screen', false)



    makeLuaSprite('okayumhehe', 'doog/OkayuLaugh1', 1500, 400);
    setObjectCamera('okayumhehe', 'other')
    addLuaSprite('okayumhehe', false)


    makeLuaText('tittle', "Broken simulator\n--'The End'--", 0, 1500, 200);
    setTextSize('tittle', 100);
    setTextFont('tittle', 'Krungthep.ttf')
    setObjectCamera('tittle', 'other');
    setTextColor('tittle', 'F8F8F8')
    addLuaText('tittle');


    makeLuaSprite('loadyummy', 'holofunk-week6/yummy', 0, 0)
    setObjectCamera('loadyummy', 'other')
    setProperty('loadyummy.alpha', 0)
    addLuaSprite('loadyummy', false)

    makeLuaSprite('loadsinner', 'holofunk-week6/sinner', 0, 0)
    setObjectCamera('loadsinner', 'other')
    setProperty('loadsinner.alpha', 0)
    addLuaSprite('loadsinner', false)


    makeLuaSprite('shad', '')
    makeGraphic('shad', screenWidth, screenHeight, 'FF9249')
    setObjectCamera('shad', 'camHUD')
    setBlendMode('shad', 'add')
    setProperty('shad.alpha', 0)
    --addLuaSprite('shad', false)

    makeLuaSprite('tran', '')
    makeGraphic('tran', screenWidth, screenHeight, '000000')
    setObjectCamera('tran', 'camHUD')
    setProperty('tran.alpha', 0)
    addLuaSprite('tran', false)

    
    makeLuaSprite('rival', 'holofunk-week6/week6day', -345, -180);
	scaleObject('rival', 1.3, 1.3)
    setScrollFactor("rival", 0.95, 0.95)

	setProperty('skipArrowStartTween',true)
	addLuaScript('extra_scripts/Holofunk-hud-nostrums', false)
	addLuaScript('extra_scripts/countdown-Holofunk', false)
end

function onStartCountdown()
setProperty()
end



function onDestroy()
    if shadersEnabled then
        runHaxeCode([[
            FlxG.game.setFilters([]);
        ]])
    end
end

function onBeatHit()
if curBeat == 18 then
doTweenAlpha('tittlebg', 'Screen', 1, 3.5, 'quarterOut')
end
if curBeat == 29 then
doTweenX('enterokayum', 'okayumhehe', 850, 1, 'backOut') 
doTweenX('thetittlexd', 'tittle', 170, 1, 'cubeOut') 
end
if curBeat == 34 then
setProperty('Screen.alpha', 0)
setProperty('okayumhehe.alpha', 0)
setProperty('tittle.alpha', 0)
end
if curBeat == 114 then
	doTweenAlpha('yummyyummy', 'loadtv', 1, 1, 'quarterOut')
	doTweenAlpha('fuckholodate', 'loadhd', 0, 1, 'quarterOut')
end
if curBeat == 127 then
    doTweenAlpha('camfadingshit', 'tran', 1, 2, 'cubeOut')
end
if curBeat == 130 then
    doTweenAlpha('fadeyummy', 'loadyummy', 1, 1, 'cubeOut')
end
if curBeat == 140 then
    doTweenX('loadscalex', 'loadyummy.scale', 2.5, 1.5, 'cubeOut')
    doTweenY('fadeload', 'loadyummy.scale', 2.5, 1.5, 'cubeOut')
    doTweenAlpha('fadeload1', 'loadyummy', 0, 1, 'cubeOut')
    setProperty('tran.alpha', 0)

    removeLuaSprite('bg')
    addLuaSprite('rival', false);
    if shadersEnabled then
       addLuaScript('extra_scripts/createShader')
        callScript('extra_scripts/createShader','createShader',{'tvShader','TvEffect'})
        callScript('extra_scripts/createShader','runShader',{{'game', 'hud', 'other'},'tvShader'})
    end
end

if curBeat == 268 then
    setProperty('loadsinner.alpha', 1)
end
if curBeat == 271 then


end
if curBeat == 272 then
    doTweenX('loadscalex', 'loadsinner.scale', 2.5, 1.5, 'cubeOut')
    doTweenY('fadeload', 'loadsinner.scale', 2.5, 1.5, 'cubeOut')
    doTweenAlpha('fadeload1', 'loadsinner', 0, 1, 'cubeOut')

removeLuaSprite('rival')

    addLuaSprite('sky-ok', false);
    addLuaSprite('school', false);
    addLuaSprite('gate', false);
    addLuaSprite('street', false);
    addLuaSprite('lightleft', false);
    addLuaSprite('lightright', false);
    addLuaSprite('treeleft', false);
    addLuaSprite('treeright', false);
    addLuaSprite('bushesleft', false);
    addLuaSprite('bushesright', false);

    setProperty("shad.alpha", 0.5)


    setShaderFloat('tvShader','multiply',1.3)
setShaderFloat('tvShader','contrast',-0.05)
setShaderBool('tvShader','lineTv',true)
setShaderBool('tvShader','whiteSpotches',true)
end

if curBeat == 342 then


noteTweenDirection('direc1', 4, 105, 50, 'cubeOut')
noteTweenDirection('direc2', 5, 95, 50, 'cubeOut')
noteTweenDirection('direc3', 6, 85, 50, 'cubeOut')
noteTweenDirection('direc4', 7, 75, 50, 'cubeOut')

--setShaderFloat('tvShader','multiply', 0.5)
--setShaderFloat('tvShader','contrast', 0.5)

runTimer('glitching1', 0.7)
--runTimer('shadering1', 1.2)
end


end


function onTimerCompleted(tag)
    if tag == 'glitching1' then
        runHaxeCode([[game.iconP2.changeIcon('okayu-calm')]]);
        runTimer('glitching2', 0.5)
    end
    if tag == 'glitching2' then
        runHaxeCode([[game.iconP2.changeIcon('okayu')]]);
        runTimer('glitching3', 0.25)
    end
    if tag == 'glitching3' then
        runHaxeCode([[game.iconP2.changeIcon('okayu-sinner')]]);
        runTimer('glitching1', 1)
    end
    if tag == 'shadering1' then
        setShaderFloat('tvShader','multiply', 0.7)
        setShaderFloat('tvShader','contrast', -0.3)
        runTimer('shadering2', 1)
    end
    if tag == 'shadering2' then
        --setShaderFloat('tvShader','multiply', 1.2)
        --setShaderFloat('tvShader','contrast', 1)
        runTimer('shadering3', 1)
    end
    if tag == 'shadering3' then
        --setShaderFloat('tvShader','multiply', 1)
        --setShaderFloat('tvShader','contrast', 0.7)
        runTimer('shadering4', 1)
    end
    if tag == 'shadering4' then
        --setShaderFloat('tvShader','multiply', -0.7)
        --setShaderFloat('tvShader','contrast', 0.2)
        runTimer('shadering5', 1)
    end
    if tag == 'shadering5' then
        --setShaderFloat('tvShader','multiply', -0.25)
        --setShaderFloat('tvShader','contrast', 0.7)
        runTimer('shadering1', 1)
    end
end


function onUpdate()
if dadName == 'okayu-sinner-glitching' or dadName == 'okayu-sinner' then
    setProperty("dad.color", getColorFromHex("FFD8EB"))
    setProperty("boyfriend.color", getColorFromHex("FFD8EB"))
    
end
end



function opponentNoteHit()
    health = getProperty('health')
if dadName == 'okayu-sinner-glitching' then
    if getProperty('health') > 0.7 then
        setProperty('health', health- 0.02);
    end
end
end
function onCreate()

        makeLuaSprite('slow', 'slow',3689, 673);
	setScrollFactor('', 1.25, 1.25);
 
	addLuaSprite('slow', false);

        setProperty('slow.visible', true);
end

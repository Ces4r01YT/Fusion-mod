function onCreate()
	-- background shit
	makeLuaSprite('stageback', 'CJ/bgdusk', -550, -160);
	setLuaSpriteScrollFactor('stageback', 0.5, 0.5);
	
	makeLuaSprite('stage', 'CJ/stage', -510, -260);


	makeAnimatedLuaSprite('stagefront', 'CJ/lights', -510, -260);


	-- sprites that only load if Low Quality is turned off
	if not lowQuality then
	makeAnimatedLuaSprite('Max', 'CJ/Max',1150, 245); 

	
	
	makeAnimatedLuaSprite('Abel', 'CJ/Abel',-220, 205); 
	
	makeAnimatedLuaSprite('frontboppers', 'CJ/frontboppers',-510, 950);
    makeAnimatedLuaSprite('headlights', 'CJ/headlights',-510, -80);
	 makeAnimatedLuaSprite('Olley', 'CJ/Olley',1470, 370);
	end

	addLuaSprite('stageback', false);
	addLuaSprite('stagefront', false);
	addAnimationByPrefix('stagefront', 'idle', 'lights idle', 1, true);
	addLuaSprite('stage', false);

	addLuaSprite('Max', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('Max', 'idle', 'MAX', 24, true);
    addLuaSprite('Abel', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('Abel', 'idle', 'ABEL', 24, true);
	  addLuaSprite('frontboppers', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('frontboppers', 'idle', 'frontboppers', 24, true);
	  addLuaSprite('headlights', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('headlights', 'idle', 'lightsrepeated', 10, true);
	  addLuaSprite('Olley', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('Olley', 'idle', 'OLLEY', 24, true);
	
end
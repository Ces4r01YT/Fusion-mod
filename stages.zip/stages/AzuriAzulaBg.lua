function onCreate()
	makeLuaSprite('azuribg', 'streaming/BG_Azuri', 1510, 30)
	addLuaSprite('azuribg', false)

	makeLuaSprite('azulabg', 'streaming/BG_Azula', -450, 50)
	scaleObject('azulabg', 2, 2)
	addLuaSprite('azulabg', false)

	setProperty('skipCountdown', true)
end

function onBeatHit()
	if curBeat == 420 then
	runHaxeCode([[
        FlxG.cameras.remove(game.camHUD, false);
		FlxG.cameras.remove(game.camOther, false);
		AzuCam = new FlxCamera();
		AzuCam.x = 650;
		AzuCam.y = 0;
		AzuCam.width = 630;   //360 - 960
		AzuCam.height = 750;   //240 - 360
		AzuCam.zoom = 0.8;
		AzuCam.alpha = 1;
		AzuCam.scroll.x = 2350;
		AzuCam.scroll.y = 200;

		FlxG.cameras.add(AzuCam);

		FlxG.cameras.add(game.camHUD, false);
		FlxG.cameras.add(game.camOther, false);
	]])
	end
	if curBeat == 452 then
		runHaxeCode([[
			FlxG.cameras.remove(AzuCam);
		]])
		end
end

function onUpdatePost(elapsed)
    for i = 0, getProperty('opponentStrums.length')-1 do
		setPropertyFromGroup('opponentStrums', i, 'texture', 'NOTE_assets_azula');
	end
	for i = 0, getProperty('unspawnNotes.length')-1 do
		if getPropertyFromGroup('unspawnNotes', i, 'mustPress') == false then
		setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets_azula');
		end
	end
	for i = 0, getProperty('playerStrums.length')-1 do
	setPropertyFromGroup('playerStrums', i, 'texture', 'NOTE_assets_pandita');
	end
	for i = 0, getProperty('unspawnNotes.length')-1 do
		if getPropertyFromGroup('unspawnNotes', i, 'mustPress') then
		setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets_pandita');
		end
	end
end


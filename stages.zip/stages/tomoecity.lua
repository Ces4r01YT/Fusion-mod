﻿function onCreate()

	makeLuaSprite('city', 'city', -700, -260)
	setScrollFactor('city', 0.8, 0.7)

	makeLuaSprite('light1', 'lightsOff', -200, -200)
	makeLuaSprite('light2', 'lightsOff', 950, -200)

	makeLuaSprite('street', 'street', -1200, 650)
	scaleObject('street', 0.6, 0.6)

	makeLuaSprite('limoSunset', 'sky', -300, -250);
	scaleObject('limoSunset', 1.2, 1.2)
	setScrollFactor('limoSunset', 0.1, 0.1);

	makeLuaSprite('bgLimo', 'limoBG', 50, 400)
	setScrollFactor('bgLimo', 1, 1);

	makeLuaSprite('limoDrive', 'limoCar', -140, 560)
	setScrollFactor('limoDrive', 1, 1);
        

	addLuaSprite('limoSunset', false)
	addLuaSprite('city', false)
	addLuaSprite('light1', false) 
	addLuaSprite('light2', false) 
	addLuaSprite('street', false)
	addLuaSprite('bgLimo', false)
	addLuaSprite('limoDrive', false);
    setObjectOrder('limoDrive',7);
	addAnimationByPrefix('limoDrive', 'idle', 'Limo stage', 24, true); 

	close(true);
end
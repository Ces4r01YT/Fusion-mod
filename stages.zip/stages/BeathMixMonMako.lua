function onCreate()
	-- background shit
	makeLuaSprite('MainBG', 'stage festival/MainBG', -700, -490);
	setLuaSpriteScrollFactor('MainBG', 1, 0.9);
    scaleObject('MainBG', 1.6, 1.6);
	makeLuaSprite('FestivalBanner', 'stage festival/FestivalBanner', -700, -440);
	setLuaSpriteScrollFactor('FestivalBanner', 1, 0.9);
	scaleObject('FestivalBanner', 1.6, 1.6);
    makeLuaSprite('DesksFestival', 'stage festival/DesksFestival', -700, -500);
	setLuaSpriteScrollFactor('DesksFestival', 1, 0.9);
	scaleObject('DesksFestival', 1.6, 1.6);
	-- sprites that only load if Low Quality is turned off
	if not lowQuality then
		makeAnimatedLuaSprite('lights_back', 'stage festival/lights_back',210, 130);
        setLuaSpriteScrollFactor('lights_back', 1, 0.9);		
        scaleObject('lights_back', 1.6, 1.6);
		
		makeAnimatedLuaSprite('lights_front', 'stage festival/lights_front',-1305, 700);
        setLuaSpriteScrollFactor('lights_front',1, 0.9);		
        scaleObject('lights_front', 1.5, 1);
		setPropertyLuaSprite('lights_front', 'flipX', true);
   
	end

	addLuaSprite('MainBG', false);
	addLuaSprite('FestivalBanner', false);
	addLuaSprite('lights_back', false); 
	addAnimationByPrefix('lights_back', 'idle', 'lights back', 24, true);
	addLuaSprite('DesksFestival', false);
	addLuaSprite('lights_front', false); 
	addAnimationByPrefix('lights_front', 'idle', 'Lights front', 24, true);
end

function onBeatHit()
	if curBeat == 176 then
		setProperty('MainBG.alpha', 0)
		setProperty('FestivalBanner.alpha', 0)
		setProperty('lights_back.alpha', 0)
		setProperty('DesksFestival.alpha', 0)
		setProperty('lights_front.alpha', 0)
	end
	if curBeat == 212 then
		setProperty('MainBG.alpha', 1)
		setProperty('FestivalBanner.alpha', 1)
		setProperty('lights_back.alpha', 1)
		setProperty('DesksFestival.alpha', 1)
		setProperty('lights_front.alpha', 1)
		doTweenAngle('boyfriendTweenAngleEvent', 'dad', 25, 0.1, 'linear');
		doTweenAngle('dadTweenAngleEvent', 'boyfriend', 320, 0.1, 'linear');
	end
end
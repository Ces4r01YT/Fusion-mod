﻿function onCreate()
	-- background shit
	makeLuaSprite('gotoubun-5_stage', 'quintuplets/gotoubun-5_stage', -700, -400);
	setScrollFactor('gotoubun-5_stage', 0.9, 0.9);

	addLuaSprite('gotoubun-5_stage', false)


	makeLuaSprite('fg', '', -400, -250)
    makeGraphic('fg', 2100, 1200, '8CC9FF')
    addLuaSprite('fg', true)
    setProperty('fg.alpha', 0)
--setObjectCamera('fg', 'other')

	makeLuaSprite('tv', 'quintuplets/Tv-gaming', -700, -500);
	--setScrollFactor('tv', 0.9, 0.9);
    --setObjectCamera('tv', 'camHUD')
	--setObjectOrder('tv', 20)
	setProperty('tv.antialiasing', false)
	scaleObject('tv', 5, 5)
	addLuaSprite('tv', true)



	makeLuaSprite('glowy', 'quintuplets/Glow-gaming', 0, 0);
	setBlendMode('glowy', 'add')
	scaleObject('glowy', 4, 2)
	setObjectCamera('glowy', 'other')
	addLuaSprite('glowy', true)
	setProperty('glowy.alpha', 0)



	makeLuaText('ts1', "'Shed' but the FEFN cast sings it", 0, -1245, 250);  --245
	setTextSize('ts1', 70);
	setTextFont('ts1', 'Quintessential-Regular.ttf')
	setObjectCamera('ts1', 'other');
	setTextColor('ts1', 'A4D76B')
	screenCenter('ts1', 'y')
	addLuaText('ts1');

	setProperty('camZoomingMult', 0)


	

end




function onCountdownTick(counter)
	if counter == 0 then
		doTweenX('ti1', 'ts1', 200, 1.15, 'backOut')
	elseif counter == 4 then
		doTweenAlpha('fadetittle', 'ts1', 0, 1, 'quarterIn')
	end
end


local zoomingCamsHUD = 0.75
local zoomingCams = 0.5   --0.5

function onBeatHit()


 if curBeat == 144 then
 --doTweenZoom('endingcam', 'camGame', zoomingCams, 1, 'sineInOut')
 --doTweenZoom('endingcam2', 'camHUD', zoomingCamsHUD, 1, 'sineInOut')
 doTweenAlpha('glowingIn', 'glowy', 0.5, 1, 'sineInOut')
 doTweenAlpha('screenThing', 'fg', 0.5, 1, 'sineInOut')

 doTweenColor('icons01', 'iconP1', '8CC9FF', 1, 'sineInOut')
 doTweenColor('icons02', 'iconP2', '8CC9FF', 1, 'sineInOut')
 doTweenColor('hb1', 'healthBar', '8CC9FF', 1, 'sineInOut')
 doTweenColor('hb2', 'healthBarBG', '8CC9FF', 1, 'sineInOut')
 doTweenColor('timecolor', 'timeBar', '8CC9FF', 1, 'sineInOut')
 doTweenColor('dajudgement', 'scoreTxt', '8CC9FF', 1, 'sineInOut')
 doTweenColor('timetextlmao', 'timeTxt', '8CC9FF', 1, 'sineInOut')

 runHaxeCode([[
	FlxTween.tween(game.camGame, {zoom:0.5}, 1, {ease: FlxEase.sineInOut});
    FlxTween.tween(game.camHUD, {zoom:0.75}, 1, {ease: FlxEase.sineInOut});
    ]])
 end
end



function onUpdate()
	if curBeat == 144 then
--runHaxeCode([[game.camHUD.color = 0000FF]])
	end
	--CameraHUDzoom=getProperty('HudTween.x')
if curBeat == 146 then
	--setProperty('camHUD.zoom', zoomingCamsHUD)
	--setProperty('camGame.zoom', zoomingCams)
	runHaxeCode([[
		game.camGame.zoom = 0.5;
		game.camHUD.zoom = 0.75;
	]])
end

end
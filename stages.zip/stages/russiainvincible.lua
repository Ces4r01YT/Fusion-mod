function onCreate()
	-- background shit

	setProperty("skipCountdown", true)

	makeLuaSprite('stageback', 'russia/motherBG', -700, -800);
	setLuaSpriteScrollFactor('stageback', 0.9, 0.9);
	scaleObject('stageback', 1.1, 1.1);

	makeLuaSprite('stagefront', 'russia/motherFG', -650, -800);
	setLuaSpriteScrollFactor('stagefront', 0.9, 0.9);
	scaleObject('stagefront', 1.1, 1.1);

	makeLuaSprite('plants', 'russia/plants', -1000, -1200);

	scaleObject('plants', 1.4, 1.4);

	makeLuaSprite('Screen', 'empty', -700, -300);
	makeGraphic('Screen', 12800, 1200, '000000');
	setObjectCamera('Screen', 'hud');
	addLuaSprite('Screen', false);


	addLuaSprite('stageback', false)
	addLuaSprite('stagefront', false)
	addLuaSprite('plants',true)

end

function onBeatHit()
	if curBeat == 28 then
	    doTweenAlpha('stageFadeEventTween', 'Screen', 0, 1, 'linear');
	end
	if curBeat == 290 then
	    setProperty('stageback.alpha', 0)
		setProperty('stagefront.alpha', 0)
		setProperty('plants.alpha', 0)
	end
	if curBeat == 322 then
	    setProperty('stageback.alpha', 1)
		setProperty('stagefront.alpha', 1)
		setProperty('plants.alpha', 1)
	end
	if curBeat == 362 then
	    setProperty('stageback.alpha', 0)
		setProperty('stagefront.alpha', 0)
		setProperty('plants.alpha', 0)
		setProperty('dad.alpha', 0)
		setProperty('boyfriend.alpha', 0)
	end
	if curBeat == 369 then
		doTweenAlpha('dadFadeEventTween', 'dad', 1, 1.2, 'linear');
	end
	if curBeat == 372 then
	    setProperty('stageback.alpha', 1)
		setProperty('stagefront.alpha', 1)
		setProperty('plants.alpha', 1)
		setProperty('boyfriend.alpha', 1)
	end
end

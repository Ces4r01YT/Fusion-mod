function onCreate()
	-- background shit
	makeLuaSprite('stageback', 'bigmonika/BG', -370, 110);   --  -500    -300
	setLuaSpriteScrollFactor('stageback', 1, 0.9);
	scaleObject('stageback', 1.4, 1.4);

	makeLuaSprite('stagefront', 'bigmonika/FG', -100, 110);    --   -500   -300
	setLuaSpriteScrollFactor('stagefront', 1, 0.9);
	scaleObject('stagefront', 1.2, 1.2);

	makeLuaSprite('stagebackday', 'bigmonika/BG_day', -370, 110);   --  -500    -300
	setLuaSpriteScrollFactor('stagebackday', 1, 0.9);
	scaleObject('stagebackday', 1.4, 1.4);


	--if not lowQuality then
	makeLuaSprite('Sky', 'bigmonika/Sky', -350, 110);
	setLuaSpriteScrollFactor('Sky', 1, 0.9);
	scaleObject('Sky', 1.4, 1.4);
	--end

	makeLuaSprite('Skyday', 'bigmonika/Sky_day', -350, 110);
	setLuaSpriteScrollFactor('Skyday', 1, 0.9);
	scaleObject('Skyday', 1.4, 1.4);

	makeLuaSprite('calendar', 'bigmonika/calendar_button_normal', 250, 650)
	setProperty('calendar.antialiasing', false)
	scaleObject('calendar', 2.7, 2.7);
	
	
	
    addLuaSprite('Sky', false);
	addLuaSprite('Skyday', false);
	addLuaSprite('stageback', false);
	addLuaSprite('stagebackday', false);
	addLuaSprite('calendar', false)
	addLuaSprite('stagefront', false);
	
	setProperty('Skyday.alpha', 0)
	setProperty('stagebackday.alpha', 0)
	setProperty('calendar.alpha', 0)

	addLuaScript('extra_scripts/moni-chibi', true)
	addLuaScript('extra_scripts/Big-Monika_chr', false)
	addLuaScript('extra_scripts/countdown-DDTO', false)

end

function onStartCountdown()
setProperty('dad.alpha', 0)
--setProperty('big-monika.alpha', 1)
setProperty('dad.color', getColorFromHex('ADB5BA'))
end


function onUpdate()
cameraSetTarget('dad')
setProperty('stagefront.origin.y', 0)
end

function onBeatHit()
	if curBeat == 18 then
    doTweenAlpha('entermonikali', 'dad', 1, 1.15, 'cubeOut')
	doTweenAlpha('fademonika', 'big-monika', 0.5, 1.15, 'cubeOut')
	end
	if curBeat == 20 then
		doTweenX('monikagoesaccp', 'big-monika', 0, 1, 'backInOut')
	end
	if curBeat == 32 then
		doTweenAlpha('monikafadingout1', 'big-monika', 0, 1, 'cubeOut')

		doTweenColor('kaliday', 'dad', 'FFFFFF', 1, 'cubeOut')

		doTweenAlpha('stageday1', 'stagebackday', 1, 1, 'cubeOut')
		doTweenAlpha('calendarday1', 'calendar', 1, 1, 'cubeOut')
		doTweenAlpha('skyday1', 'Skyday', 1, 1, 'cubeOut')
		doTweenAlpha('stagenight1', 'stageback', 0, 1, 'cubeOut')
		doTweenAlpha('skynight1', 'Sky', 0, 1, 'cubeOut')
	end
	if curBeat == 205 then
		doTweenX('moninkagoesback', 'big-monika', 277, 1, 'cubeOut')
	end
	if curBeat == 207 then
		doTweenAlpha('monikafadingin1', 'big-monika', 1, 1, 'cubeOut')
		doTweenAlpha('monikalifading', 'dad', 0, 1, 'cubeOut')

		doTweenAlpha('stageday1', 'stagebackday', 0, 1, 'cubeOut')
		doTweenAlpha('calendarday1', 'calendar', 0, 1, 'cubeOut')
		doTweenAlpha('skyday1', 'Skyday', 0, 1, 'cubeOut')
		doTweenAlpha('stagenight1', 'stageback', 1, 1, 'cubeOut')
		doTweenAlpha('skynight1', 'Sky', 1, 1, 'cubeOut')
	end
	if curBeat == 265 then
		doTweenAlpha('fadingagain', 'big-monika', 0.3, 1, 'cubeOut')
		doTweenX('monikagoesaccp', 'big-monika', 0, 1, 'backInOut')
		doTweenAlpha('entermonikali', 'dad', 1, 1, 'cubeOut')

		doTweenColor('kalinight', 'dad', 'ADB5BA', 1, 'cubeOut')
	end
	if curBeat == 272 then
		noteTweenAlpha('notemonk0', 0, 0, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk1', 1, 0, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk2', 2, 0, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk3', 3, 0, 0.7, 'sineInOut')
	end
	if curBeat == 392 then
		doTweenAlpha('byemonikaaa', 'big-monika', 0, 1, 'cubeOut')

		noteTweenAlpha('notemonk0', 0, 1, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk1', 1, 1, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk2', 2, 1, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk3', 3, 1, 0.7, 'sineInOut')
	end
	if curBeat == 416 then
		setProperty('dad.color', getColorFromHex('FFFFFF'))
		setProperty('stagebackday.alpha', 1)
		setProperty('calendar.alpha', 1)
		setProperty('Skyday.alpha', 1)
		setProperty('stageback.alpha', 0)
		setProperty('Sky.alpha', 0)
	end
	if curBeat == 544 then
		doTweenAlpha('monikaappears', 'big-monika', 1, 1, 'cubeOut')
		doTweenX('monikarevenge', 'big-monika', 277, 0.7, 'backInOut')
		doTweenAlpha('byemonikali', 'dad', 0, 1, 'cubeOut')

		
		doTweenAlpha('stageday1', 'stagebackday', 0, 1, 'cubeOut')
		doTweenAlpha('calendarday1', 'calendar', 0, 1, 'cubeOut')
		doTweenAlpha('skyday1', 'Skyday', 0, 1, 'cubeOut')
		doTweenAlpha('stagenight1', 'stageback', 1, 1, 'cubeOut')
		doTweenAlpha('skynight1', 'Sky', 1, 1, 'cubeOut')
		
		doTweenAlpha('byehud1', 'healthBarBG', 0, 0.7, 'sineInOut')
		doTweenAlpha('byehud2', 'healthBar', 0, 0.7, 'sineInOut')
		doTweenAlpha('byehud3', 'timeBar', 0, 0.7, 'sineInOut')
		doTweenAlpha('byehud4', 'timeBarBG', 0, 0.7, 'sineInOut')
		doTweenAlpha('byehud5', 'iconP1', 0, 0.7, 'sineInOut')
		doTweenAlpha('byehud6', 'iconP2', 0, 0.7, 'sineInOut')
        doTweenAlpha('byehud7', 'winningIconBf', 0, 0.7, 'sineInOut')
		doTweenAlpha('byehud8', 'winningIconDad', 0, 0.7, 'sineInOut')

		noteTweenAlpha('notemonk0', 0, 0, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk1', 1, 0, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk2', 2, 0, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk3', 3, 0, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk4', 4, 0, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk5', 5, 0, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk6', 6, 0, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk7', 7, 0, 0.7, 'sineInOut')
	end
	if curBeat == 558 then
		doTweenAlpha('comehud1', 'healthBarBG', 1, 0.7, 'sineInOut')
		doTweenAlpha('comehud2', 'healthBar', 1, 0.7, 'sineInOut')
		doTweenAlpha('comehud3', 'timeBar', 1, 0.7, 'sineInOut')
		doTweenAlpha('comehud4', 'timeBarBG', 1, 0.7, 'sineInOut')
		doTweenAlpha('comehud5', 'iconP1', 1, 0.7, 'sineInOut')
		doTweenAlpha('comehud6', 'iconP2', 1, 0.7, 'sineInOut')
        doTweenAlpha('comehud7', 'winningIconBf', 1, 0.7, 'sineInOut')
		doTweenAlpha('comehud8', 'winningIconDad', 1, 0.7, 'sineInOut')

		noteTweenAlpha('notemonk0', 0, 1, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk1', 1, 1, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk2', 2, 1, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk3', 3, 1, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk4', 4, 1, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk5', 5, 1, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk6', 6, 1, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk7', 7, 1, 0.7, 'sineInOut')
	end
	if curBeat == 607 then
		doTweenAlpha('fadingagain', 'big-monika', 0.3, 1, 'cubeOut')
		doTweenX('monikagoesaccp', 'big-monika', 0, 1, 'backInOut')
		doTweenAlpha('entermonikali', 'dad', 1, 1, 'cubeOut')
		doTweenColor('kalinight', 'dad', 'ADB5BA', 1, 'cubeOut')

	end
	if curBeat == 608 then
		noteTweenAlpha('notemonk0', 0, 0, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk1', 1, 0, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk2', 2, 0, 0.7, 'sineInOut')
		noteTweenAlpha('notemonk3', 3, 0, 0.7, 'sineInOut')
	end
	if curBeat == 703 then
		doTweenAlpha('fademonika', 'big-monika', 0, 0.5, 'cubeIn')
		doTweenX('monikaoff', 'big-monika', -700, 1, 'backInOut')
		doTweenColor('kaliday', 'dad', 'FFFFFF', 1, 'cubeOut')
		doTweenAlpha('stageday1', 'stagebackday', 1, 1, 'cubeOut')
		doTweenAlpha('calendarday1', 'calendar', 1, 1, 'cubeOut')
		doTweenAlpha('skyday1', 'Skyday', 1, 1, 'cubeOut')
		doTweenAlpha('stagenight1', 'stageback', 0, 1, 'cubeOut')
		doTweenAlpha('skynight1', 'Sky', 0, 1, 'cubeOut')
	end
	if curBeat == 704 then
		--doTweenAlpha('finalhud', 'camHUD', 0, 0.5, 'quarterOut')

		doTweenY('gamegone', 'camGame', 1200, 2.5, 'backInOut')
		doTweenY('hudgone', 'camHUD', 920, 2.15, 'backInOut')
		doTweenY('othergone', 'other', 920, 2.3, 'backInOut')

		doTweenAngle('gameanglegone', 'camGame', 45, 2.7, 'sineOut')
		doTweenAngle('hudanglegone', 'camHUD', -25, 3, 'cubeOut')
		doTweenAngle('otheranglegone', 'other', -90, 4, 'linear')
	end
end

function opponentNoteHit()
    health = getProperty('health')
    if getProperty('big-monika.alpha') == 1 then
    	if getProperty('health') > 0.25 then
        	setProperty('health', health- 0.03);
    	end
	end
	if getProperty('big-monika.alpha') < 1 and getProperty('big-monika.alpha') > 0 then
		if getProperty('health') > 0.25 then
        	setProperty('health', health- 0.01);
    	end
    end
end
function onCreate()
	makeLuaSprite('Scene', 'empty', -140, -10)
	makeGraphic('Scene', 12800, 1200, '000000')
	setObjectCamera('Scene', 'hud')
	addLuaSprite('Scene', false)
	setProperty('Scene.alpha', 0)

	makeLuaSprite('gotoubun', 'quintuplets/gotoubun-5_stage_sunset', -400, -400);
	setScrollFactor('gotoubun', 0.9, 0.9);

	addLuaSprite('gotoubun', false);

	makeLuaSprite('MainBG', 'stage ddlc/DDLCbg', -700, -490);
	setLuaSpriteScrollFactor('MainBG', 1, 0.9);
    scaleObject('MainBG', 1.6, 1.6);
	addLuaSprite('MainBG', false);

    makeLuaSprite('DesksFestival', 'stage ddlc/DesksFront', -700, -500);
	setLuaSpriteScrollFactor('DesksFestival', 1, 0.9);
	scaleObject('DesksFestival', 1.6, 1.6);
	addLuaSprite('DesksFestival', true);

	setProperty('MainBG.alpha', 0)
	setProperty('DesksFestival.alpha', 0)
end


function onBeatHit()
	if curBeat == 412 then
       doTweenAlpha('fckDaNig', 'Scene', 1, 0.7)
	end
	if curBeat == 456 then
		removeLuaSprite('Scene')
	end
	if curBeat == 488 then
		setProperty('MainBG.alpha', 1)
		setProperty('DesksFestival.alpha', 1)
		removeLuaSprite('gotoubun')
	end
end

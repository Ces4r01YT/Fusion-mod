function onCreate()
	makeLuaSprite('wall', 'virtual/Wall bg', -1200, -750);
	setLuaSpriteScrollFactor('wall', 0.6, 0.6);

	makeLuaSprite('floorbg', 'virtual/Back Platform', -1200, -750);
	setLuaSpriteScrollFactor('floorbg', 0.75, 0.75);


	makeLuaSprite('bpipes', 'virtual/Back Pipes', -1200, -750);
	setLuaSpriteScrollFactor('bpipes', 0.75, 0.75);

	makeLuaSprite('floor', 'virtual/Main Platform', -1200, -750);
	setLuaSpriteScrollFactor('floor', 1, 1);

	makeLuaSprite('fpipes', 'virtual/Front Pipes', -1200, -750);
	setLuaSpriteScrollFactor('fpipes', 1, 1);


	makeLuaSprite('floating', 'virtual/Corner top Left Pipes', -1400, -600);
	setLuaSpriteScrollFactor('floating', 0.75, 0.75);


    addLuaSprite('wall', false)
	addLuaSprite('floorbg', false)
	addLuaSprite('bpipes', false)
	addLuaSprite('floor', false)
	addLuaSprite('fpipes', false)
	addLuaSprite('floating', false)
end
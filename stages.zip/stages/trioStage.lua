function onCreate()
	-- background shit
	makeLuaSprite('Glitch', 'stage trio/Glitch', -621.1, -395.65);
	setLuaSpriteScrollFactor('Glitch', 0.9, 1);
	scaleObject('Glitch', 1.2, 1.2);
	
	makeAnimatedLuaSprite('NewTitleMenuBG', 'stage trio/NewTitleMenuBG', -70, -70);
	setLuaSpriteScrollFactor('NewTitleMenuBG', 0.9, 1);
	scaleObject('NewTitleMenuBG', 4.5, 4.5);
	
	makeLuaSprite('stagefront2', 'stage trio/Trees2', -623.5, -450.4);
	setLuaSpriteScrollFactor('stagefront2', 1, 1);
	scaleObject('stagefront2', 1.2, 1.2);

	makeLuaSprite('Grass', 'stage trio/Grass', -630.4, -410);
	setLuaSpriteScrollFactor('Grass', 1.1, 1);
	scaleObject('Grass', 1.2, 1.2);
	

	addLuaSprite('Glitch', false);
	addLuaSprite('NewTitleMenuBG', false);
	addAnimationByPrefix('NewTitleMenuBG', 'idle', 'TitleMenuSSBG instance ', 24, true);
	setProperty('NewTitleMenuBG.visible', false);
	addLuaSprite('stagefront2', false);
	addLuaSprite('Grass', false);

	
end
function onEvent(name,value1,value2)
	if name == 'Play Animation' then 
		
		if value1 == '2' then
			setProperty('Glitch.visible', false);
			setProperty('NewTitleMenuBG.visible', true);
		
		end
		
		if value1 == '1' then
				setProperty('Glitch.visible', true);
			setProperty('NewTitleMenuBG.visible', false);
		end
	end
end
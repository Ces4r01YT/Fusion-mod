function onCreate()
    makeLuaSprite('pirateria','piracy/bg', -400,-300 )
    addLuaSprite('pirateria', false)

    makeLuaSprite('piracy','piracy/piracy', 0,0 )
    addLuaSprite('piracy', false)

    makeLuaSprite('is','piracy/is', 0,0 )
    addLuaSprite('is', false)

    makeLuaSprite('a','piracy/a', 0,0 )
    addLuaSprite('a', false)

    makeLuaSprite('crime','piracy/crime', 0,0 )
    addLuaSprite('crime', false)

    setObjectCamera('piracy', 'other')
    setObjectCamera('is', 'other')
    setObjectCamera('a', 'other')
    setObjectCamera('crime', 'other')

    setProperty('skipCountdown', true)





    makeLuaSprite('hologym', 'holostage/stagefull_new', -300, -200);
	setLuaSpriteScrollFactor('hologym', 0.8, 0.8);
	scaleObject('hologym', 1.5, 1.5)
	

    makeLuaSprite('flstage', 'FL_overlay', -400, 250);
    

    makeAnimatedLuaSprite('flbg', 'FL_backtrain', -2500, -300);
    addAnimationByPrefix("flbg", "idle", "BG limo", 24, true)

    makeAnimatedLuaSprite('fltrain', 'FL_train', -700, 670);
    addAnimationByPrefix("fltrain", "idle", "Limo stage", 24, true)

   

    makeLuaSprite('Lugunica', 'reFunkin/Lugunica', -656, -90);
    setScrollFactor('Lugunica', 1.0, 1.0);




    makeLuaSprite('wallpaper', 'horudavt/xp_bg', -280, -100);
--setScrollFactor('wallpaper', 0.6, 0.6);
--scaleObject('wallpaper', 1.1, 1.1);

makeLuaSprite('window', 'horudavt/VIDEO', 285, -100);
--setScrollFactor('window', 0.7, 0.7);
scaleObject('window', 3.5, 3.5);



makeLuaSprite('vampire_over', 'Ryuu_Overlay/Vtuber_Just_Chatting_2', -150, 0)



    makeLuaSprite('DarkCloset', 'stages1/ClosetBG', -210, 50);
    scaleLuaSprite('DarkCloset', 1.6, 1.6);
    setLuaSpriteScrollFactor('DarkCloset', 1.0, 1.0);
    

    makeLuaSprite('citymako', 'City_night_bg', 0, 170);
	scaleObject('citymako', 3.25, 3.25)




    makeLuaSprite('holomallback', 'stage new/bgWalls', -1100, -600);
	scaleObject('holomallback', 1.2, 1.2);
	
	makeLuaSprite('christmasTree', 'stage new/christmasTree', 410, 50);

	makeLuaSprite('holomallfront', 'stage new/bgEscalator', -1100, -600);
	scaleObject('holomallfront', 1.2, 1.2);

	makeAnimatedLuaSprite('upper_bop_LEFT', 'stage new/upper_bop_LEFT', -580, 130) 
	scaleObject('upper_bop_LEFT', 1.2, 1.2);
	makeAnimatedLuaSprite('upper_bop_RIGHT', 'stage new/upper_bop_RIGHT', 880, 130) 
	scaleObject('upper_bop_RIGHT', 1.2, 1.2);
	
	makeAnimatedLuaSprite('santa', 'stage new/santa', -800, 460) 
	setLuaSpriteScrollFactor('santa', 1, 1);
	scaleObject('santa', 1.1, 1.1);
	
	makeAnimatedLuaSprite('marineAquaSuisei', 'stage new/marineAquaSuisei', 900, 130) 
	scaleObject('marineAquaSuisei', 1, 1);
	makeAnimatedLuaSprite('noel', 'stage new/noel', 490, 430) 
	scaleObject('noel', 1, 1);
		makeAnimatedLuaSprite('irys', 'stage new/irys', 280, 430) 
	scaleObject('irys', 1, 1);
		makeAnimatedLuaSprite('flare', 'stage new/flare', -280, 430) 
	scaleObject('flare', 1, 1);

	
	addAnimationByPrefix('upper_bop_LEFT', 'Move', 'Upper Crowd Bob LEFT', 30, true);
	
	addAnimationByPrefix('upper_bop_RIGHT', 'Move', 'Upper Crowd Bob RIGHT', 30, true);
	
	addAnimationByPrefix('santa', 'Move', 'santa idle in fear', 30, true);
   
	addAnimationByPrefix('marineAquaSuisei', 'Move', 'Bottom Level Boppers', 30, true);
	
	addAnimationByPrefix('noel', 'Move', 'noel', 30, true);
	
	addAnimationByPrefix('irys', 'Move', 'irys', 30, true);

	addAnimationByPrefix('flare', 'Move', 'flare', 30, true);




makeLuaSprite('sky-ok', 'onigiri/evening/sky', -400, -400);
setScrollFactor("sky-ok", 0.1, 0.1)

makeLuaSprite('school', 'onigiri/evening/school', -220, -130);
scaleObject("school", 0.9, 0.9)
setScrollFactor("school", 0.9, 0.95)
makeLuaSprite('gate', 'onigiri/evening/gate', -380, 320);
setScrollFactor("gate", 0.95, 0.95)
makeLuaSprite('street', 'onigiri/evening/street', -370, 570);
makeLuaSprite('lightleft', 'onigiri/evening/greenlight', -270, 470);
setBlendMode("lightleft", "add")
makeLuaSprite('lightright', 'onigiri/evening/greenlight', 1320, 470);
setBlendMode("lightright", "add")
makeLuaSprite('treeleft', 'onigiri/evening/treeleft', -340, -140);
makeLuaSprite('treeright', 'onigiri/evening/treeright', 1190, -170);
makeLuaSprite('bushesleft', 'onigiri/evening/bushesleft', -385, 475);
makeLuaSprite('bushesright', 'onigiri/evening/bushesright', 1490, 475);


makeLuaSprite('bgdark', 'bg/sonic', -250, -180)

makeLuaSprite('ninom1', 'quintuplets/nino_scene', -250, -150)
makeLuaSprite('ninom2', 'quintuplets/nino_scene_manga', -250, -150)

makeLuaSprite('go-school', 'quintuplets/HallLightoff', -250, -150)
scaleObject('go-school', 0.75, 0.75)

makeLuaSprite('bghell', 'stages/torrid/hellbg', -450, -550)	
scaleObject('bghell', 2, 1.8)

makeLuaSprite('fghell', 'stages/torrid/hellground', -510, -169)	
	scaleObject('fghell', 0.65, 0.65)


    makeLuaSprite('azulabg', 'streaming/BG_Azula', -450, 50)
	scaleObject('azulabg', 2, 2)


    makeLuaSprite('tw', 'streaming/TwitchFrameAzula', -685, 20)
	scaleObject('tw', 1.35, 1.35)



    makeLuaSprite('gotoubun', 'quintuplets/gotoubun-5_stage_sunset', -400, -400);
	setScrollFactor('gotoubun', 0.9, 0.9);







    addCharacterToList('fl-chan', 'dad')
    addCharacterToList('PiracySonic', 'dad')
    addCharacterToList('takamori-christmas', 'dad')
    addCharacterToList('ruka', 'dad')
    addCharacterToList('mio-rival', 'dad')
    addCharacterToList('ryuuhiko-closeup', 'dad')
    addCharacterToList('lucifer-helltaker', 'dad')
    addCharacterToList('justice-helltaker', 'dad')

end


function onBeatHit()
    if curBeat == 35 then
    makeLuaSprite('videoSprite','', -1500, 0)
      
    setObjectCamera('videoSprite', 'camHUD')
    --scaleObject('videoSprite', 1.15, 1.15)
    addLuaSprite('videoSprite', false)
    
    --setObjectOrder('videoSprite', 999999)

    addHaxeLibrary('MP4Handler','vlc')
    addHaxeLibrary('Event','openfl.events')
    

    runHaxeCode([[
        var filepath = Paths.video('Miosha-piracy-scene');		
        var video = new MP4Handler();
        video.playVideo(filepath);
        video.visible = false;
        setVar('video',video);
        FlxG.stage.removeEventListener('enterFrame', video.update); 
    ]])
    end
    if curBeat == 37 then
    doTweenX('miosha-transition', 'videoSprite', 0, 1, 'backInOut')
    end
    if curBeat == 40 then
    removeLuaSprite('videoSprite')
    removeLuaSprite('pirateria')
    addLuaSprite('hologym', false);
    end
    if curBeat == 72 then
    removeLuaSprite('hologym')
    addLuaSprite('flstage', false);
    addLuaSprite('flbg', false);
    addLuaSprite('fltrain', false);
    end
    if curBeat == 88 then
    removeLuaSprite('flstage');
    removeLuaSprite('flbg');
    removeLuaSprite('fltrain');
    addLuaSprite('Lugunica', false)
    end
    if curBeat == 108 then
    removeLuaSprite('Lugunica')
    addLuaSprite('wallpaper', false)
    addLuaSprite('window', false)
    addLuaSprite('vampire_over', false)
    end
    if curBeat == 124 then
    addLuaSprite('DarkCloset', false);
    removeLuaSprite('wallpaper')
    removeLuaSprite('window')
    removeLuaSprite('vampire_over')
    end
    if curBeat == 140 then
    removeLuaSprite('DarkCloset')
    addLuaSprite('citymako', false)
    end
    if curBeat == 156 then
    removeLuaSprite('citymako')
    addLuaSprite('holomallback', false);
	addLuaSprite('upper_bop_LEFT', false);
    addLuaSprite('upper_bop_RIGHT', false);
    addLuaSprite('solomallfront', false);
	addLuaSprite('christmasTree', false);
	addLuaSprite('santa', false);
    addLuaSprite('marineAquaSuisei', false);
    addLuaSprite('noel', false);
    addLuaSprite('irys', false);
    addLuaSprite('flare', false);

    addLuaSprite('sky-ok', false);
    addLuaSprite('school', false);
    addLuaSprite('gate', false);
    addLuaSprite('street', false);
    addLuaSprite('lightleft', false);
    addLuaSprite('lightright', false);
    addLuaSprite('treeleft', false);
    addLuaSprite('treeright', false);
    addLuaSprite('bushesleft', false);
    addLuaSprite('bushesright', false);
    end
    if curBeat == 172 then
        addLuaSprite('bgdark', false)
        removeLuaSprite('holomallback')
        removeLuaSprite('upper_bop_LEFT')
        removeLuaSprite('upper_bop_RIGHT')
        removeLuaSprite('holomallfront')
        removeLuaSprite('christmasTree')
        removeLuaSprite('santa')
        removeLuaSprite('marineAquaSuisei')
        removeLuaSprite('noel')
        removeLuaSprite('irys')
        removeLuaSprite('flare')
        removeLuaSprite('sky-ok')
        removeLuaSprite('school')
        removeLuaSprite('gate')
        removeLuaSprite('street')
        removeLuaSprite('lightleft')
        removeLuaSprite('lightright')
        removeLuaSprite('treeleft')
        removeLuaSprite('treeright')
        removeLuaSprite('bushesleft')
        removeLuaSprite('bushesright')
    end
    if curBeat == 204 then
        removeLuaSprite('bgdark')
        addLuaSprite('go-school', false)
    end
    if curBeat == 236 then
        removeLuaSprite('go-school')
        addLuaSprite('bghell', false)
        addLuaSprite('fghell', false)
    end
    if curBeat == 268 then
        removeLuaSprite('bghell')
        removeLuaSprite('fghell')
        addLuaSprite('azulabg', false)
        addLuaSprite('tw', false)
    end
    if curBeat == 338 then
    --stage miku night
    end
    if curBeat == 368 then
    addLuaSprite('gotoubun', false)
    end
end




function onCreatePost()
    --setProperty('gf.visible', false)

    --setProperty('showComboNum', false);
    --setProperty('showRating', false);
    --setProperty('scoreTxt.visible', false);
    --setProperty('timeBar.visible', false);
    --setProperty('timeBarBG.visible', false);
    setProperty('timeTxt.visible', false)
    --setProperty('iconP1.visible', false);
    --setProperty('iconP2.visible', false);
    --setProperty('healthBar.visible', false);
    --setProperty('healthBarBG.visible', false);
    --setTextString("botplayTxt", "You're supposed to play the game,\n why else would you download it?")


    setProperty('piracy.alpha', 0)
    setProperty('is.alpha', 0)
    setProperty('a.alpha', 0)
    setProperty('crime.alpha', 0)

end



function onUpdate()
if dadName == 'PiracySonic' then
    if getProperty('dad.animation.curAnim.name') == 'singLEFT' then
    setProperty('boyfriend.angle', 14)
    setProperty('boyfriend.x', 870)
    setProperty('boyfriend.y', 572)
    end
    if getProperty('dad.animation.curAnim.name') == 'singDOWN' then
    setProperty('boyfriend.angle', 50)
    setProperty('boyfriend.x', 977)
    setProperty('boyfriend.y', 594)
    end
    if getProperty('dad.animation.curAnim.name') == 'singUP' then
    setProperty('boyfriend.x', 970)
    setProperty('boyfriend.y', 552)
    setProperty('boyfriend.angle', 50)
    end
    if getProperty('dad.animation.curAnim.name') == 'idle' then
    setProperty('boyfriend.angle', 0)
    setProperty('boyfriend.x', 946)
    setProperty('boyfriend.y', 576)
    end
    if getProperty('dad.animation.curAnim.name') == 'singRIGHT' then
    setProperty('boyfriend.angle', 0)
    setProperty('boyfriend.x', 1027)
    setProperty('boyfriend.y', 547)
    end
end
end


function onStepHit()
    if curStep == 1 then
        doTweenAlpha('piracy','piracy', 1, 0.25, 'expoInOut')

        --setProperty('camGame.angle', 180)
        setProperty('camGame.alpha', 0)
        setProperty('camHUD.alpha', 0)

        for i = 0, 3 do
            setPropertyFromGroup("strumLineNotes", i, 'alpha', 0)
        end
    end
    if curStep == 9 then
        doTweenAlpha('is','is', 1, 0.25, 'expoInOut')
    end
    if curStep == 10 then
        doTweenAlpha('a','a', 1, 0.25, 'expoInOut')
    end
    if curStep == 12 then
        doTweenAlpha('crime','crime', 1, 0.25, 'expoInOut')
    end
    if curStep == 28 then
        doTweenAlpha('piracy','piracy', 0, 0.5, 'expoInOut')
        doTweenAlpha('is','is', 0, 0.5, 'expoInOut')
        doTweenAlpha('a','a', 0, 0.5, 'expoInOut')
        doTweenAlpha('crime','crime', 0, 0.5, 'expoInOut')
    end
    if curStep == 31 then
        --doTweenAngle('ttrn', 'camGame', 1440, 1.2, 'expoOut')
    end
    if curStep == 32 then
        --cameraFlash('game', '000000', 1, 1)
        doTweenAlpha('daintro', 'camGame', 1, 1, 'expoInOut')
        doTweenAlpha('alpha', 'camHUD', 1, 3, 'expoInOut')
        removeLuaSprite('piracy')
        removeLuaSprite('is')
        removeLuaSprite('a')
        removeLuaSprite('crime')
    end
    
end



function onUpdatePost()
    
    runHaxeCode([[
        var video = getVar('video');
        game.getLuaObject('videoSprite').loadGraphic(video.bitmapData);
        video.volume = FlxG.sound.volume + 100;	
        if(game.paused)video.pause();
    ]])
end


function onResume()
    runHaxeCode([[
        var video = getVar('video');
        video.resume();
    ]])
end


function goodNoteHit(id, direction, noteType, isSustainNote)
	if noteType == "HellPenta" then
		playSound("sonido de disparo", 0.8)
        characterPlayAnim('boyfriend','shoot',true)
        health = getProperty('health')
        setProperty('health', health+ 0.55);
	end
end

function opponentNoteHit(id, direction, noteType, isSustainNote)
	if noteType == "azula-closeup" then
        health = getProperty('health')
        setProperty('health', health- 0.02);
	end
end
function onCreate()
	-- background shit
	makeLuaSprite('weebSky','poems n thorns/weebSky',-150, -20);
	setLuaSpriteScrollFactor('weebSky', 0.6,0.90);
	scaleObject('weebSky', 9, 6);
	makeLuaSprite('weebSchool', 'poems n thorns/weebSchool', -200, 0);
	setLuaSpriteScrollFactor('weebSchool', 0.6,0.90);
	scaleObject('weebSchool',6, 7);
	makeLuaSprite('weebStreet', 'poems n thorns/weebStreet',-200, 0);
	setLuaSpriteScrollFactor('weebStreet',  0.95, 0.95);
	scaleObject('weebStreet', 7, 7);
    
	-- sprites that only load if Low Quality is turned off
	if not lowQuality then
	makeLuaSprite('weebTreesBack','poems n thorns/weebTreesBack',-200, -20)
	setLuaSpriteScrollFactor('weebTreesBack', 0.85, 0.85);
	scaleObject('weebTreesBack', 6, 7);
	makeAnimatedLuaSprite('weebTrees', 'poems n thorns/weebTrees',-190, -20);
    setLuaSpriteScrollFactor('weebTrees', 0.85, 0.85);		
	scaleObject('weebTrees',6, 7)
	setProperty('weebSky.antialiasing', false);
	setProperty('weebSchool.antialiasing', false);
	setProperty('weebTreesBack.antialiasing', false);
    setProperty('weebStreet.antialiasing', false);

	end

	addLuaSprite('weebSky', false);
	addLuaSprite('weebSchool', false);
	addLuaSprite('weebStreet', false);
	addLuaSprite('weebTreesBack', false);
	addLuaSprite('weebTrees', false);
	addAnimationByPrefix('weebTrees','idle', 'weebTrees idle',12,true);

	makeLuaSprite('Screen', 'empty', -140, -10)
	makeGraphic('Screen', 12800, 1200, '000000')
	setObjectCamera('Screen', 'hud')
	addLuaSprite('Screen', false)
	
end

function onBeatHit()
    if curBeat == 3 then
	    doTweenAlpha('stageFadeEventTween', 'Screen', 0, 0.5, 'linear');
	end
end
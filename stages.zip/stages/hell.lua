function onCreatePost()
	initLuaShader('fire')
	makeLuaSprite('bg', 'torrid/hellbg', -450, -550)	
	scaleObject('bg', 2, 1.8)
	addLuaSprite('bg', false)
	makeLuaSprite('fireSprite', null, -600, 1000)
	--makeLuaSprite('fireSprite', null, -350, -380)
	makeGraphic('fireSprite', screenWidth + 600, screenHeight + 1000, FFFFFF)
	setSpriteShader('fireSprite', 'fire')
	addLuaSprite('fireSprite')
	setBlendMode('fireSprite', 'screen')
	setProperty('fireSprite.angle', 180)
	setProperty('fireSprite.flipX', true)
	--setProperty('fireSprite.alpha', 0)
	scaleObject('fireSprite', 1.55, 1.55)
	makeLuaSprite('fg', 'torrid/hellground', -510, -169)	
	scaleObject('fg', 0.65, 0.65)
	addLuaSprite('fg', false)
	setProperty('dadGroup.x', getProperty('dadGroup.x') - 100)
end

function onUpdatePost()
	setShaderFloat('fireSprite', 'iTime', os.clock())
end

function onEvent(n, a, b)
	if n == 'sexy part' then
		doTweenY('funny2', 'fireSprite', -1950, 3.5, 'circOut')
		if a == 'UNDO IT' then
			doTweenY('funny2', 'fireSprite', 1000, 3.5, 'circOut')
		end
	end
end
function onCreate()
   makeLuaSprite('thetabistage','tabi_stage',-500,-300)
   addLuaSprite('thetabistage',false)
   setLuaSpritesScrollFactor('thetabistage',0.5,0.5)
   close(true)
end
function onCreate()
	-- background shit
		makeLuaSprite('evilBG', 'stage holofunk red/evilBG', -400, -420);
   
	 scaleObject('evilBG', 0.9, 0.9);
	makeLuaSprite('stagefront', 'stage holofunk red/evilTreeUncensored', 400, -400);

		makeAnimatedLuaSprite('fireGoBrr', 'stage holofunk red/fireGoBrr',1020, -215);
      
    makeLuaSprite('fireGlow', 'stage holofunk red/fireGlow', 600, 100);
    scaleObject('fireGlow', 0.3, 0.3);

	makeLuaSprite('sky','mashup/botanStage', -100, 00);
		setLuaSpriteScrollFactor('sky', 0.1, 0.1);

		makeLuaSprite('MainBG', 'mashup/festival', -700, -490);
	setLuaSpriteScrollFactor('MainBG', 1, 0.9);
    scaleObject('MainBG', 1.6, 1.6);

	makeLuaSprite('school', 'mashup/animeSchool', -400, -420);

	makeLuaSprite('skyBG', 'mashup/flTrain', -1220, -550)
	scaleObject('skyBG', 1.2, 1.2)
	setScrollFactor('skyBG', 0.1, 0.1)

	makeLuaSprite('church', 'selChurch', -400, -420);

	addLuaSprite('evilBG', false);
	addLuaSprite('stagefront', false);
	addLuaSprite('fireGlow', false);
	addLuaSprite('fireGoBrr', false); 
	addAnimationByPrefix('fireGoBrr', 'idle', 'Fire', 24, true);
	addLuaSprite('sky', false);
	addLuaSprite('MainBG', false);
	addLuaSprite('school', false);
	addLuaSprite('skyBG', false);
	addLuaSprite('church', false);

	setProperty('sky.visible', false)
	setProperty('MainBG.visible', false)
	setProperty('school.visible', false)
	setProperty('skyBG.visible', false)
	setProperty('church.visible', false)

end

function onEvent(name,value1,value2)
	if name == 'Play Animation' then 
		
		if value1 == 'philly' then
			setProperty('evilBG.visible', false);
			setProperty('stagefront.visible', false);
			setProperty('fireGlow.visible', false);
			setProperty('fireGoBrr.visible', false);
	        setProperty('sky.visible', true);
			setProperty('MainBG.visible', false);
			setProperty('school.visible', false);
			setProperty('skyBG.visible', false);
			setProperty('church.visible', false);
		end
		if value1 == 'festival' then
			setProperty('evilBG.visible', false);
			setProperty('stagefront.visible', false);
			setProperty('fireGlow.visible', false);
			setProperty('fireGoBrr.visible', false);
	        setProperty('sky.visible', false);
			setProperty('MainBG.visible', true);
			setProperty('school.visible', false);
			setProperty('skyBG.visible', false);
			setProperty('church.visible', false);
		end
		if value1 == 'nagatoro' then
			setProperty('evilBG.visible', false);
			setProperty('stagefront.visible', false);
			setProperty('fireGlow.visible', false);
			setProperty('fireGoBrr.visible', false);
	        setProperty('sky.visible', false);
			setProperty('MainBG.visible', false);
			setProperty('school.visible', true);
			setProperty('skyBG.visible', false);
			setProperty('church.visible', false);
		end
		if value1 == 'flstudio' then
		    setProperty('evilBG.visible', false);
			setProperty('stagefront.visible', false);
			setProperty('fireGlow.visible', false);
			setProperty('fireGoBrr.visible', false);
	        setProperty('sky.visible', false);
			setProperty('MainBG.visible', false);
			setProperty('school.visible', false);
			setProperty('skyBG.visible', true);
			setProperty('church.visible', false);
		end
		if value1 == 'sel' then
		    setProperty('evilBG.visible', false);
			setProperty('stagefront.visible', false);
			setProperty('fireGlow.visible', false);
			setProperty('fireGoBrr.visible', false);
	        setProperty('sky.visible', false);
			setProperty('MainBG.visible', false);
			setProperty('school.visible', false);
			setProperty('skyBG.visible', false);
			setProperty('church.visible', true);
		end
	end
end
--made with Super_Hugo's Stage Editor

function onCreate()

	makeLuaSprite('obj1', 'stage ddlc/DDLCbg', -359, -195)

	setObjectOrder('obj1', 0)
	scaleObject('obj1', 1.2, 1.2)

	addLuaSprite('obj1', true)


	makeLuaSprite('obj2', 'badEnding/ClosetBG', -361, -201)

	setObjectOrder('obj2', 1)
	scaleObject('obj2', 1.2, 1.2)

	addLuaSprite('obj2', true)


	makeLuaSprite('obj3', 'philly2/sky', -453, -239)

	setObjectOrder('obj3', 2)
	scaleObject('obj3', 1.3, 1.3)

	addLuaSprite('obj3', true)


	makeLuaSprite('obj4', 'philly/city', -418, -291)

	setObjectOrder('obj4', 3)
	scaleObject('obj4', 1.3, 1.3)

	addLuaSprite('obj4', true)


	makeLuaSprite('obj5', 'philly/windowNO', -421, -291)

	setObjectOrder('obj5', 5)
	scaleObject('obj5', 1.3, 1.3)

	addLuaSprite('obj5', true)


	makeLuaSprite('obj6', 'philly/street', -391, -239)

	setObjectOrder('obj6', 4)
	scaleObject('obj6', 1.3, 1.3)

	addLuaSprite('obj6', true)


	makeLuaSprite('obj7', 'quintuplets/gotoubun-5_stage_sunset', -459, -290)

	setObjectOrder('obj7', 6)
	scaleObject('obj7', 0.9, 0.9)

	addLuaSprite('obj7', true)


	makeLuaSprite('obj8', 'mind/TormentorBG', -703, -458)

	setObjectOrder('obj8', 7)
	scaleObject('obj8', 1.1, 1.1)

	addLuaSprite('obj8', true)


	makeLuaSprite('obj9', 'missa/stageback', -535, -270)

	setObjectOrder('obj9', 8)

	addLuaSprite('obj9', true)


	makeLuaSprite('obj10', 'Week1D/stage_auditions_sus', -435, -378)

	setObjectOrder('obj10', 9)
	scaleObject('obj10', 2.1, 2.1)

	addLuaSprite('obj10', true)


	makeLuaSprite('obj11', 'streaming/BG_Azuri', -499, -342)

	setObjectOrder('obj11', 10)
	scaleObject('obj11', 1.2, 1.2)

	addLuaSprite('obj11', true)


	makeLuaSprite('obj12', 'mashup/botanRushia', -495, -426)

	setObjectOrder('obj12', 11)
	scaleObject('obj12', 0.9, 0.9)

	addLuaSprite('obj12', true)


	makeLuaSprite('obj13', 'holostage/stagefull', -491, -254)

	setObjectOrder('obj13', 12)
	scaleObject('obj13', 0.9, 0.9)

	addLuaSprite('obj13', true)


	makeLuaSprite('obj14', 'streaming/KizunaBG', -448, -425)

	setObjectOrder('obj14', 13)
	scaleObject('obj14', 1.6, 1.6)
	setScrollFactor('obj14', 0.8, 0.8)

	addLuaSprite('obj14', true)


	makeLuaSprite('obj15', 'whitty/thawal', -1155, -419)

	setObjectOrder('obj15', 14)
	setScrollFactor('obj15', 0.8, 0.8)

	addLuaSprite('obj15', true)


	makeLuaSprite('obj16', 'whitty/thagroun', -975, -523)

	setObjectOrder('obj16', 15)
	setScrollFactor('obj16', 0.8, 0.8)

	addLuaSprite('obj16', true)


	makeLuaSprite('obj17', 'sink/SinkBgFull', -1006, -705)

	setObjectOrder('obj17', 16)
	scaleObject('obj17', 1.6, 1.6)
	setScrollFactor('obj17', 0.8, 0.8)

	addLuaSprite('obj17', true)


	makeLuaSprite('obj18', 'smg4/stageTariCity', -991, -515)

	setObjectOrder('obj18', 17)
	scaleObject('obj18', 1.5, 1.5)
	setScrollFactor('obj18', 0.8, 0.8)

	addLuaSprite('obj18', true)

end
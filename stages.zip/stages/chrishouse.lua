function onCreate()
	setProperty('gfGroup.visible', false)
	-- background shit
	makeLuaSprite('chrisbg', 'chrisbg', -600, -300);
	setProperty('chrisbg.origin.x', getProperty('chrisbg.width') / 2)
	
	makeAnimatedLuaSprite('line', 'line', getProperty('chrisbg.width') / 5.5, getProperty('chrisbg.y'));
	addAnimationByPrefix('line', 'line', 'line', 24, true)

	addLuaSprite('chrisbg', false);
	addLuaSprite('line', false);
	
	close(true); --For performance reasons, close this script once the stage is fully loaded, as this script won't be used anymore after loading the stage
end
--made with Super_Hugo's Stage Editor

function onCreate()
	precacheImage('new');
	precacheImage('NOTE_assets_BW');
	precacheImage('NOTE_assets_ddlc');
	precacheImage('NOTE_assets_holo');
	precacheImage('NOTE_assets_quinti');
	precacheImage('NOTE_assets');
	precacheImage('noteSplashes_Doki');
	precacheImage('noteSplashesBW');
	precacheImage('noteSplashesHololive');
    addCharacterToList('yuri-gore', 'dad');
	addCharacterToList('monika', 'dad');
	addCharacterToList('polka', 'dad');
	addCharacterToList('yotninomiku', 'dad');

	makeLuaSprite('obj1', 'backgrounds/destruido', -616, -343)

	addLuaSprite('obj1', false)


	makeLuaSprite('obj2', 'quintuplets/gotoubun-5_stage_night', -596, -537)
	scaleObject('obj2', 1.1, 1.1)

	addLuaSprite('obj2', false)


	makeLuaSprite('obj3', 'holostage/stagefull', -733, -275)

	scaleObject('obj3', 1.1, 1.1)

	addLuaSprite('obj3', false)


	makeLuaSprite('obj4', 'streaming/BG_Azuri', -858, -525)
	scaleObject('obj4', 1.7, 1.7)

	addLuaSprite('obj4', false)


	makeLuaSprite('obj5', 'russia/motherBG', -853, -650)

	scaleObject('obj5', 1.2, 1.2)

	addLuaSprite('obj5', false)


	makeLuaSprite('obj6', 'russia/motherFG', -853, -850)

	scaleObject('obj6', 1.2, 1.2)

	addLuaSprite('obj6', false)


	makeLuaSprite('obj7', 'stage holofunk red/evilBG', -843, -655)

	scaleObject('obj7', 1.1, 1.1)

	addLuaSprite('obj7', false)


	makeLuaSprite('obj8', 'stage ddlc/DDLCbg', -873, -575)

	scaleObject('obj8', 1.8, 1.8)

	addLuaSprite('obj8', false)


	makeLuaSprite('obj9', 'CJ/bgnight', -848, -505)

	scaleObject('obj9', 1.2, 1.2)

	addLuaSprite('obj9', false)


	makeLuaSprite('obj10', 'CJ/stage', -818, -520)

	scaleObject('obj10', 1.2, 1.2)

	addLuaSprite('obj10', false)


	makeLuaSprite('obj11', 'CJ/light5', -818, -515)

	scaleObject('obj11', 1.2, 1.2)

	addLuaSprite('obj11', false)


	makeLuaSprite('obj12', 'streaming/KizunaBG', -903, -810)

	scaleObject('obj12', 2.3, 2.3)

	addLuaSprite('obj12', false)

	makeLuaSprite('lamy', 'lamyBW', 903, 200)
	setObjectOrder('lamy', 13)
	addLuaSprite('lamy', true)
	setObjectCamera('lamy', 'other')
	scaleObject('lamy', 1.2, 1.2)

	makeLuaSprite('Screen', 'empty', -140, -10)
	makeGraphic('Screen', 12800, 1200, '000000')
	setObjectCamera('Screen', 'hud')
	addLuaSprite('Screen', false)


	setProperty('obj2.visible', false)
	setProperty('obj3.visible', false)
	setProperty('obj4.visible', false)
	setProperty('obj5.visible', false)
	setProperty('obj6.visible', false)
	setProperty('obj7.visible', false)
	setProperty('obj8.visible', false)
	setProperty('obj9.visible', false)
	setProperty('obj10.visible', false)
	setProperty('obj11.visible', false)
	setProperty('obj12.visible', false)
	setProperty('lamy.alpha', 0)
	setProperty('Screen.alpha', 0)

	precacheImage('readyMickey')
	precacheImage('setMickey')
	precacheImage('goMickey')
	makeLuaSprite('two', 'readyMickey', 0, 0)
	screenCenter('two', 'xy')
	setObjectCamera('two', 'other')
	makeLuaSprite('one', 'setMickey', 0, 0)
	screenCenter('one', 'xy')
	setObjectCamera('one', 'other')
	makeLuaSprite('go', 'goMickey', 0, 0)
	screenCenter('go', 'xy')
	setObjectCamera('go', 'other')
	setProperty('countdownReady.visible', false)
	setProperty('countdownSet.visible', false)
	setProperty('countdownGo.visible', false)
	setProperty('introSoundsSuffix', '-NADALAVERGAEXACTO')
end

function onBeatHit()
	if curBeat == 52 then
		doTweenAlpha('stageFadeEventTween', 'Screen', 1, 1.1, 'linear')
	end
	if curBeat == 64 then
		doTweenAlpha('stageFadeEventTween', 'Screen', 0, 0.05, 'linear')
	end
    if curBeat == 80 then
		setProperty('obj1.visible', false)
		setProperty('obj2.visible', true)
	end
	if curBeat == 128 then
		setProperty('obj2.visible', false)
		setProperty('obj3.visible', true)
	end
	if curBeat == 160 then
		setProperty('obj3.visible', false)
		setProperty('obj4.visible', true)
	end
	if curBeat == 194 then
		setProperty('obj4.visible', false)
		setProperty('obj5.visible', true)
		setProperty('obj6.visible', true)
	end
	if curBeat == 210 then
		setProperty('obj5.visible', false)
		setProperty('obj6.visible', false)
		setProperty('obj7.visible', true)
	end
	if curBeat == 242 then
		setProperty('obj7.visible', false)
		setProperty('obj8.visible', true)
	end
	if curBeat == 306 then
		setProperty('obj8.visible', false)
		setProperty('obj9.visible', true)
		setProperty('obj10.visible', true)
		setProperty('obj11.visible', true)
	end
	if curBeat == 370 then
		setProperty('obj9.visible', false)
		setProperty('obj10.visible', false)
		setProperty('obj11.visible', false)
		setProperty('obj12.visible', true)
	end
	if curBeat == 404 then
		doTweenAlpha('dadFadeEventTween', 'lamy', 0.70, 4.1, 'linear')
		doTweenX('dadTweenX', 'lamy', -310, 12.7, 'linear')
	end
	if curBeat == 428 then
		doTweenAlpha('dadFadeEventTween', 'lamy', 0, 1.3, 'linear')
	end
	if curBeat == 436 then
		setProperty('obj12.visible', false)
		setProperty('obj1.visible', true)
	end
end

function onCreatePost()

	setProperty('timeBar.color', getColorFromHex('808080'))
	
end

function onCountdownTick(counter)
	if counter == 0 then
		playSound('mickey3')
	elseif counter == 1 then
		addLuaSprite('two')
		playSound('mickey2')
		setProperty('countdownReady.visible', false)		
	elseif counter == 2 then
		removeLuaSprite('two', false)
		addLuaSprite('one')
		playSound('mickey1')
		setProperty('countdownSet.visible', false)
	elseif counter == 3 then
		removeLuaSprite('one', false)
		addLuaSprite('go')
		playSound('mickeyGo')
		setProperty('countdownGo.visible', false)
	elseif counter == 4 then
		removeLuaSprite('go')
	end
end
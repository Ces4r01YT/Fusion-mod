function onCreate()
	
	makeLuaSprite('back','match/stagebacknormal',-200,-170)
	addLuaSprite('back',false)

	makeLuaSprite('front','match/stagefrontnormal', -200,650)
	addLuaSprite('front',false)

	makeLuaSprite('stageback','match/holostageback',-200,-170)
	addLuaSprite('stageback',false)

	makeLuaSprite('stagefront','match/holostagefront', -200,650)
	addLuaSprite('stagefront',false)

	makeAnimatedLuaSprite('lamy', 'match/Lamy_Idle_Worried',-10, 220)
	addLuaSprite('lamy', false)
	addAnimationByPrefix('lamy', 'idle', 'Idle', 24, true)

	makeAnimatedLuaSprite('kanata', 'match/KanataMatch',1800, 200)
	addLuaSprite('kanata', false)
	addAnimationByPrefix('kanata', 'idle', 'kanata bar boppin', 24, true)
	
	setProperty('stageback.visible', false)
	setProperty('stagefront.visible', false)
	setProperty('lamy.visible', false)
	setProperty('kanata.visible', false)

end

function onEvent(name,value1,value2)
	if name == 'Play Animation' then 
		
		if value1 == 'changebg1' then
			setProperty('back.visible', false);
			setProperty('front.visible', false);
			setProperty('stageback.visible', true);
			setProperty('stagefront.visible', true);
			setProperty('lamy.visible', true);
			setProperty('kanata.visible', true);
		end
    end
end
function onCreate()

    makeLuaSprite('slow', 'slow', -750, -400);
 
	addLuaSprite('slow', false);

    makeLuaSprite('BgHaato', 'stage holofunk red/evilBG', -400, -420);
   
	scaleObject('BgHaato', 0.9, 0.9);
	makeLuaSprite('Tree', 'stage holofunk red/evilTreeUncensored', 400, -410);

    addLuaSprite('BgHaato', false);
	addLuaSprite('Tree', false);

    makeLuaSprite('mindBG', 'mind/TormentorBG', -650, -400)
    addLuaSprite('mindBG', false)

    makeLuaSprite('overlayMind', 'mind/Overlay3', -550, -300)
    addLuaSprite('overlayMind', true)
    scaleObject('overlayMind', 1.3, 1.3)

    makeAnimatedLuaSprite('OverlayingSpikes', 'mind/OverlayingSpikes', -50, 0)
    luaSpriteAddAnimationByPrefix('OverlayingSpikes', 'OverlayingSpikes', 'Spikes', 24, true);
    addLuaSprite('OverlayingSpikes', true)
    scaleObject('OverlayingSpikes', 0.8, 0.8)
    setObjectCamera('OverlayingSpikes', 'hud')

    makeLuaSprite('stagebackHolo', 'holoweek1/stageback', -500, -300);
	setLuaSpriteScrollFactor('stagebackHolo', 0.9, 0.9);
	
	makeLuaSprite('stagefrontHolo', 'holoweek1/stagefront', -650, 600);
	setLuaSpriteScrollFactor('stagefrontHolo', 0.9, 0.9);
	scaleObject('stagefrontHolo', 1.1, 1.1);

    addLuaSprite('stagebackHolo', false);
	addLuaSprite('stagefrontHolo', false);

    makeLuaSprite('gotoubun', 'quintuplets/gotoubun-5_stage', -400, -400);
	setScrollFactor('gotoubun', 0.9, 0.9);

	addLuaSprite('gotoubun', false);

    makeLuaSprite('dokiSlow', 'YCR/BGSkyDDLCexe',-550, -400);
 
	addLuaSprite('dokiSlow', false);

    makeLuaSprite('council', 'mashup/BG_call_council',-500, -400);
 
	addLuaSprite('council', false);

	setProperty('slow.visible', true);
	setProperty('BgHaato.alpha', 0);
	setProperty('Tree.alpha', 0);
	setProperty('mindBG.alpha', 0);
	setProperty('overlayMind.alpha', 0);
	setProperty('OverlayingSpikes.alpha', 0);
    setProperty('stagebackHolo.alpha', 0);
    setProperty('stagefrontHolo.alpha', 0);
	setProperty('gotoubun.alpha', 0);
	setProperty('dokiSlow.alpha', 0);
    setProperty('council.alpha', 0);
end

function onBeatHit()
        if curBeat == 100 then
        setProperty('BgHaato.alpha', 1);
	    setProperty('Tree.alpha', 1);
	end
        if curBeat == 136 then
		setProperty('BgHaato.alpha', 0);
	    setProperty('Tree.alpha', 0);
        setProperty('mindBG.alpha', 1);
	    setProperty('overlayMind.alpha', 1);
	    setProperty('OverlayingSpikes.alpha', 1);
	end
        if curBeat == 168 then
		setProperty('mindBG.alpha', 0)
	    setProperty('overlayMind.alpha', 0)
	    setProperty('OverlayingSpikes.alpha', 0)
        setProperty('stagebackHolo.alpha', 1)
        setProperty('stagefrontHolo.alpha', 1)
	end
        if curBeat == 200 then
		setProperty('stagebackHolo.alpha', 0)
        setProperty('stagefrontHolo.alpha', 0)
	    setProperty('gotoubun.alpha', 1)
	end
        if curBeat == 254 then
		setProperty('gotoubun.alpha', 0)
	    setProperty('dokiSlow.alpha', 1)
	end
        if curBeat == 296 then
		setProperty('dokiSlow.alpha', 0)
        setProperty('council.alpha', 1)
	end
end
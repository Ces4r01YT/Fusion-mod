﻿function onCreate()

	scaleGeneral = 7

	makeLuaSprite('gotoubun-5_stage', 'quintuplets/gotoubun-5_stage', -400, -400);
	setScrollFactor('gotoubun-5_stage', 0.9, 0.9);
	addLuaSprite('gotoubun-5_stage', false);


	makeLuaSprite('cutsceneBG', '')
	makeGraphic('cutsceneBG', screenWidth, screenHeight, 'FFFFFF')
	setObjectCamera('cutsceneBG', 'camHUD')
	addLuaSprite('cutsceneBG', true)
	setProperty('cutsceneBG.alpha', 0)



	makeLuaSprite('pxruka1', 'pixel-waifus/Ruka_Pixel_Cutscene', 400, 200);
	setObjectCamera('pxruka1', 'other');
	scaleObject('pxruka1', scaleGeneral, scaleGeneral)
	setProperty('pxruka1.antialiasing', false)
	addLuaSprite('pxruka1', false);
	setProperty('pxruka1.alpha', 0)

	makeLuaSprite('pxruka2', 'pixel-waifus/Ruka_Pixel_Cutscene2', 400, 200);
	setObjectCamera('pxruka2', 'other');
	scaleObject('pxruka2', scaleGeneral, scaleGeneral)
	setProperty('pxruka2.antialiasing', false)
	addLuaSprite('pxruka2', false);
	setProperty('pxruka2.alpha', 0)

	makeLuaSprite('pxyot1', 'pixel-waifus/428_Pixel_Cutscene', 700, 185);
	setObjectCamera('pxyot1', 'other');
	scaleObject('pxyot1', scaleGeneral, scaleGeneral)
	setProperty('pxyot1.antialiasing', false)
	addLuaSprite('pxyot1', false);
	setProperty('pxyot1.alpha', 0)

	makeLuaSprite('pxyot-alt', 'pixel-waifus/428_Pixel_Cutscene-alt', 700, 185);
	setObjectCamera('pxyot-alt', 'other');
	scaleObject('pxyot-alt', scaleGeneral, scaleGeneral)
	setProperty('pxyot-alt.antialiasing', false)
	addLuaSprite('pxyot-alt', false);
	setProperty('pxyot-alt.alpha', 0)

	makeLuaSprite('pxyot2', 'pixel-waifus/428_Pixel_Cutscene2-alt', 700, 165);
	setObjectCamera('pxyot2', 'other');
	scaleObject('pxyot2', scaleGeneral, scaleGeneral)
	setProperty('pxyot2.antialiasing', false)
	addLuaSprite('pxyot2', false);
	setProperty('pxyot2.alpha', 0)

end

function onBeatHit()
if curBeat == 108 then
	setProperty('cutsceneBG.alpha', 1)
	setProperty('pxruka1.alpha', 1)
	setProperty('pxyot1.alpha', 1)
end
if curBeat == 110 then
	setProperty('pxruka1.alpha', 0)
	setProperty('pxyot1.alpha', 0)

	setProperty('pxruka2.alpha', 1)
	setProperty('pxyot-alt.alpha', 1)
end
if curBeat == 111 then
	setProperty('pxyot-alt.alpha', 0)

	setProperty('pxyot2.alpha', 1)
end
if curBeat == 112 then
	setProperty('pxruka2.alpha', 0)
	setProperty('cutsceneBG.alpha', 0)
	setProperty('pxyot2.alpha', 0)
end


end

function onCreate()
	
	makeLuaSprite('stageback','holostage/stageback_Holofunk',-200,-170)
	addLuaSprite('stageback',false)

	makeLuaSprite('stagefront','holostage/stagefront_Holofunk', -200,650)
	addLuaSprite('stagefront',false)
	
	close(true)
end

function onCreate()

	makeLuaSprite('holo', 'sinner-stage', 600, 150);
	addLuaSprite('holo', false);


	makeLuaSprite('hologym', 'holostage/stagefull_new', -285, -175);
	setLuaSpriteScrollFactor('hologym', 0.8, 0.8);
	scaleObject('hologym', 1.5, 1.5)
	addLuaSprite('hologym', false);
	
	

	makeLuaSprite('filter', '', -350, -100)
	makeGraphic('filter', 5000, 5000, '777777')
	setBlendMode('filter', 'multiply')
	addLuaSprite('filter', true)

	makeLuaSprite('light1', 'spotlight', 300, -70);
	setBlendMode('light1', 'add')
	setProperty('light1.alpha', 0)
	addLuaSprite('light1', true)
	
	makeLuaSprite('light2', 'spotlight', 1100, -70);
	setBlendMode('light2', 'add')
	setProperty('light2.alpha', 0)
	addLuaSprite('light2', true)


	
	makeLuaSprite('room', 'doog/room_TvEffect', -500, -250);
	setScrollFactor('room', 1, 1);
	scaleObject('room', 0.7, 0.7);
	

	makeLuaSprite('off', '', -350, -100)
	makeGraphic('off', 5000, 5000, '000000')
    setObjectCamera('off', 'camHUD')
	addLuaSprite('off', false)
	setProperty('off.alpha', 0)

	makeLuaSprite('offbg', '', -350, -100)
	makeGraphic('offbg', 5000, 5000, '000000')

	makeLuaSprite('circlething', 'Hole_tran', 125, -100)
	--setObjectCamera('circlething', 'other')

	makeLuaText('ts1', "'Made in 2002' but\nHololive Gamers sings it", 0, 200, 250);  --245
	setTextSize('ts1', 70);
	setTextFont('ts1', 'Krungthep.ttf')
	setObjectCamera('ts1', 'other');
	setTextColor('ts1', '216DFF')
	
	
	makeLuaText('ts2', "I'm sorry", 0, -1245, 250);  --245
	setTextSize('ts2', 70);
	setTextFont('ts2', 'Krungthep.ttf')
	setObjectCamera('ts2', 'other');
	setTextColor('ts2', 'FFFFFF')
	addLuaText('ts2');

	addLuaScript("extra_scripts/Holofunk-hud-nostrums", false)
	addLuaScript("extra_scripts/OKayu-sinner_chr", false)
	addLuaScript("extra_scripts/countdown-Holofunk", false)
end

function onSongStart()
	doTweenAlpha('kone', 'light1', 0.4, 1.5, 'cubeOut')

end

function onStartCountdown()
	setProperty('gf.visible', false)
	setProperty('ogallo.visible', false)
end
function onBeatHit()
	if curBeat == 16 then
		doTweenAlpha('miosha', 'light2', 0.4, 1.5, 'cubeOut')
	end
	if curBeat == 32 then
    doTweenAlpha('transition1', 'off', 1, 1, 'linear')
	end
	if curBeat == 33 then
		doTweenX('text1', 'ts2', 450, 0.85, 'cubeOut')
	end
	if curBeat == 35 then
		doTweenAlpha('textfadeagain', 'ts2', 0, 0.5, 'quarterIn')
	end
	if curBeat == 36 then
	setProperty('off.alpha', 0)
	setProperty('ogallo.visible', true)
	setProperty('filter.visible', false)
	setProperty('light1.visible', false)
	setProperty('light2.visible', false)
	setProperty('hologym.visible', false)
	setProperty('gf.visible', true)
	addLuaSprite('room', false);
	end
	if curBeat == 68 then
		addLuaText('ts1');
	end
	if curBeat == 73 then
		doTweenAlpha('fadetittle', 'ts1', 0, 1, 'quarterIn')
	end
	if curBeat == 100 then
		doTweenAlpha('blackie', 'off', 1, 1.2, 'quintIn')
	end
	--if curBeat == 103 then
	--	doTweenAlpha('firstfadehud', 'camHUD', 0, 0.75, 'cubeOut')
	--end
	if curBeat == 104 then
		setProperty('off.alpha', 0)
		addLuaSprite('offbg', false)
		setProperty('camHUD.alpha', 0)
		addLuaSprite('circlething', true)
		setProperty('circlething.origin.x', 270);
		setProperty('circlething.antialising', false)
	end
	if curBeat == 118 then
		doTweenX('bigcircle1', 'circlething.scale', 0.85, 0.75, 'cubeOut')
		doTweenY('bigcircle2', 'circlething.scale', 0.85, 0.75, 'cubeOut')
	end
	if curBeat == 119 then
		doTweenAlpha('comebackhud', 'camHUD', 1, 0.75, 'cubeOut')
		doTweenX('bigcircle3', 'circlething.scale', 20, 0.75, 'cubeOut')
		doTweenY('bigcircle4', 'circlething.scale', 20, 0.75, 'cubeOut')
	end
	if curBeat == 151 then
		doTweenAngle('okayuchange1', 'iconP2', 360, 0.75, 'backInOut')
	end
	if curBeat == 152 then
		runHaxeCode([[game.iconP2.changeIcon('okayu-sinner')]]);
		setProperty('offbg.alpha', 0)
		removeLuaSprite('circlething')
	end
    if curBeat == 216 then
		setProperty('offbg.alpha', 1)
		setProperty('gf.alpha', 0)
    end
	if curBeat == 247 then
		doTweenAngle('okayuchange1', 'iconP2', 360, 0.75, 'backInOut')
	end
	if curBeat == 248 then
		runHaxeCode([[game.iconP2.changeIcon('okayu-sinner')]]);
		removeLuaSprite('offbg')
		setProperty('gf.alpha', 1)
	end
end

function opponentNoteHit()
    health = getProperty('health')
    if getProperty('health') > 0.7 then
        setProperty('health', health- 0.02);
    end
end


function onStepHit()
timexd = 0.1
if curStep == 477 then
	--setProperty('playbackRate', 0.5)
end


	if curStep == 480 then
    doTweenX('moves1', 'camHUD', 100, timexd, 'cubeOut')
    end
	if curStep == 482 then
	doTweenX('moves2', 'camHUD', 0, timexd, 'cubeOut')
	doTweenY('moves3', 'camHUD', 50, timexd, 'cubeOut')
    end
	if curStep == 483 then
    doTweenX('moves4', 'camHUD', 100, timexd, 'cubeOut')
	doTweenY('moves4.1', 'camHUD', 0, timexd, 'cubeOut')
    end
	if curStep == 485 then
	doTweenX('moves5', 'camHUD', -100, timexd, 'cubeOut')
	doTweenY('moves6', 'camHUD', 0, timexd, 'cubeOut')
	end
	if curStep == 486 then
	doTweenX('moves7', 'camHUD', 0, timexd, 'cubeOut')
	doTweenY('moves8', 'camHUD', 50, timexd, 'cubeOut')
	end
	if curStep == 487 then
	doTweenY('moves9', 'camHUD', -50, timexd, 'cubeOut')
	end
	if curStep == 488 then
	doTweenY('moves10', 'camHUD', 0, timexd, 'cubeOut')
	end


	if curStep == 496 then
		doTweenX('moves1', 'camHUD', 100, timexd, 'cubeOut')
		end
		if curStep == 498 then
		doTweenX('moves2', 'camHUD', 0, timexd, 'cubeOut')
		doTweenY('moves3', 'camHUD', 50, timexd, 'cubeOut')
		end
		if curStep == 499 then
		doTweenX('moves4', 'camHUD', 100, timexd, 'cubeOut')
		doTweenY('moves4.1', 'camHUD', 0, timexd, 'cubeOut')
		end
		if curStep == 501 then
		doTweenX('moves5', 'camHUD', -100, timexd, 'cubeOut')
		doTweenY('moves6', 'camHUD', 0, timexd, 'cubeOut')
		end
		if curStep == 502 then
		doTweenX('moves7', 'camHUD', 0, timexd, 'cubeOut')
		doTweenY('moves8', 'camHUD', 50, timexd, 'cubeOut')
		end
		if curStep == 503 then
		doTweenY('moves9', 'camHUD', -50, timexd, 'cubeOut')
		end
		if curStep == 504 then
		doTweenY('moves10', 'camHUD', 0, timexd, 'cubeOut')
		end


		    if curStep == 512 then
			doTweenX('moves1', 'camHUD', -100, timexd, 'cubeOut')
			end
			if curStep == 514 then
			doTweenX('moves2', 'camHUD', 100, timexd, 'cubeOut')
			--doTweenY('moves3', 'camHUD', 50, timexd, 'cubeOut')
			end
			if curStep == 515 then
			doTweenX('moves4', 'camHUD', -99, timexd, 'cubeOut')
			--doTweenY('moves4.1', 'camHUD', 0, timexd, 'cubeOut')
			end
			--if curStep == 517 then
			--doTweenX('moves5', 'camHUD', -100, timexd, 'cubeOut')
			--doTweenY('moves6', 'camHUD', 0, timexd, 'cubeOut')
			--end
			if curStep == 517 then
			doTweenX('moves7', 'camHUD', 0, timexd, 'cubeOut')
			doTweenY('moves8', 'camHUD', 50, timexd, 'cubeOut')
			end
			if curStep == 518 then
			doTweenY('moves9', 'camHUD', -50, timexd, 'cubeOut')
			end
			if curStep == 519 then
			doTweenY('moves10', 'camHUD', 0, timexd, 'cubeOut')
			end





		if curStep == 528 then
			doTweenX('moves1', 'camHUD', 100, timexd, 'cubeOut')
			end
			if curStep == 530 then
			doTweenX('moves2', 'camHUD', 0, timexd, 'cubeOut')
			doTweenY('moves3', 'camHUD', 50, timexd, 'cubeOut')
			end
			if curStep == 531 then
			doTweenX('moves4', 'camHUD', 100, timexd, 'cubeOut')
			doTweenY('moves4.1', 'camHUD', 0, timexd, 'cubeOut')
			end
			if curStep == 533 then
			doTweenX('moves5', 'camHUD', -100, timexd, 'cubeOut')
			doTweenY('moves6', 'camHUD', 0, timexd, 'cubeOut')
			end
			if curStep == 534 then
			doTweenX('moves7', 'camHUD', 0, timexd, 'cubeOut')
			doTweenY('moves8', 'camHUD', 50, timexd, 'cubeOut')
			end
			if curStep == 535 then
			doTweenY('moves9', 'camHUD', -50, timexd, 'cubeOut')
			end
			if curStep == 536 then
			doTweenY('moves10', 'camHUD', 0, timexd, 'cubeOut')
			end


	    if curStep == 544 then
		doTweenX('moves1', 'camHUD', -100, timexd, 'cubeOut')
		end
		if curStep == 546 then
		doTweenX('moves2', 'camHUD', 100, timexd, 'cubeOut')
		--doTweenY('moves3', 'camHUD', 50, timexd, 'cubeOut')
		end
		if curStep == 547 then
		doTweenX('moves4', 'camHUD', -100, timexd, 'cubeOut')
		--doTweenY('moves4.1', 'camHUD', 0, timexd, 'cubeOut')
		end
		if curStep == 549 then
		doTweenX('moves5', 'camHUD', 100, timexd, 'cubeOut')
		--doTweenY('moves6', 'camHUD', 0, timexd, 'cubeOut')
		end
		if curStep == 550 then
		doTweenX('moves7', 'camHUD', 0, timexd, 'cubeOut')
		doTweenY('moves8', 'camHUD', -50, timexd, 'cubeOut')
		end
		if curStep == 551 then
		doTweenY('moves9', 'camHUD', 50, timexd, 'cubeOut')
		end
		if curStep == 552 then
		doTweenY('moves10', 'camHUD', 0, timexd, 'cubeOut')
		end


		if curStep == 560 then
		doTweenX('moves1', 'camHUD', -100, timexd, 'cubeOut')
		end
		if curStep == 562 then
		doTweenX('moves2', 'camHUD', 100, timexd, 'cubeOut')
		--doTweenY('moves3', 'camHUD', 50, timexd, 'cubeOut')
		end
		if curStep == 563 then
		doTweenX('moves4', 'camHUD', -100, timexd, 'cubeOut')
		--doTweenY('moves4.1', 'camHUD', 0, timexd, 'cubeOut')
		end
		if curStep == 565 then
		doTweenX('moves5', 'camHUD', 100, timexd, 'cubeOut')
		--doTweenY('moves6', 'camHUD', 0, timexd, 'cubeOut')
		end
		if curStep == 566 then
		doTweenX('moves7', 'camHUD', 0, timexd, 'cubeOut')
		doTweenY('moves8', 'camHUD', -50, timexd, 'cubeOut')
		end
		if curStep == 567 then
		doTweenY('moves9', 'camHUD', 50, timexd, 'cubeOut')
		end
		if curStep == 568 then
		doTweenY('moves10', 'camHUD', 0, timexd, 'cubeOut')
		end


		if curStep == 576 then
			doTweenX('moves1', 'camHUD', 100, timexd, 'cubeOut')
			end
			if curStep == 578 then
			doTweenX('moves2', 'camHUD', 0, timexd, 'cubeOut')
			doTweenY('moves3', 'camHUD', -50, timexd, 'cubeOut')
			end
			if curStep == 579 then
			doTweenX('moves4', 'camHUD', 100, timexd, 'cubeOut')
			doTweenY('moves4.1', 'camHUD', 0, timexd, 'cubeOut')
			end
			if curStep == 581 then
			doTweenX('moves5', 'camHUD', -100, timexd, 'cubeOut')
			--doTweenY('moves6', 'camHUD', 0, timexd, 'cubeOut')
			end
			if curStep == 582 then
			doTweenX('moves7', 'camHUD', 100, timexd, 'cubeOut')
			--doTweenY('moves8', 'camHUD', -50, timexd, 'cubeOut')
			end
			if curStep == 583 then
			doTweenX('moves8', 'camHUD', 0, timexd, 'cubeOut')
			doTweenY('moves9', 'camHUD', -50, timexd, 'cubeOut')
			end
			if curStep == 584 then
			doTweenY('moves10', 'camHUD', 0, timexd, 'cubeOut')
			end





		if curStep == 592 then
			doTweenX('moves1', 'camHUD', -100, timexd, 'cubeOut')
			end
			if curStep == 594 then
			doTweenX('moves2', 'camHUD', 100, timexd, 'cubeOut')
			--doTweenY('moves3', 'camHUD', 50, timexd, 'cubeOut')
			end
			if curStep == 595 then
			doTweenX('moves4', 'camHUD', -100, timexd, 'cubeOut')
			--doTweenY('moves4.1', 'camHUD', 0, timexd, 'cubeOut')
			end
			if curStep == 597 then
			doTweenX('moves5', 'camHUD', 100, timexd, 'cubeOut')
			--doTweenY('moves6', 'camHUD', 0, timexd, 'cubeOut')
			end
			if curStep == 598 then
			doTweenX('moves7', 'camHUD', 0, timexd, 'cubeOut')
			doTweenY('moves8', 'camHUD', -50, timexd, 'cubeOut')
			end
			if curStep == 599 then
			doTweenY('moves9', 'camHUD', 50, timexd, 'cubeOut')
			end
			if curStep == 600 then
			doTweenY('moves10', 'camHUD', 0, timexd, 'cubeOut')
			end
end

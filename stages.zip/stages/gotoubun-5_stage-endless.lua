﻿function onCreate()
	-- background shit
	makeLuaSprite('gotoubun-5_stage', 'quintuplets/gotoubun-5_stage_night', -400, -400);
	setScrollFactor('gotoubun-5_stage', 0.9, 0.9);

	addLuaSprite('gotoubun-5_stage', false);

	makeLuaSprite('Screen', 'empty', -400, -400)
	makeGraphic('Screen', 12800, 1200, '00229E')
	setObjectCamera('Screen', 'other')
	addLuaSprite('Screen', true)
	setProperty('Screen.alpha', 0.6)

end
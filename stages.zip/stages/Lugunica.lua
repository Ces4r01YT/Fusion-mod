﻿function onCreate()
	-- background shit
	makeLuaSprite('Lugunica', 'Lugunica', -256, -100);
	setScrollFactor('Lugunica', 1.0, 1.0);

	addLuaSprite('Lugunica', false);
	
end
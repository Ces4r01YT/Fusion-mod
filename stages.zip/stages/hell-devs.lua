function onCreatePost()

	makeLuaSprite('city', 'tomoe_city/city', -700, -260)
	setScrollFactor('city', 0.8, 0.7)

	makeLuaSprite('light1', 'tomoe_city/lightsOff', -200, -200)
	makeLuaSprite('light2', 'tomoe_city/lightsOff', 950, -200)

	makeLuaSprite('street', 'tomoe_city/street', -1200, 650)
	scaleObject('street', 0.6, 0.6)

	makeLuaSprite('street2', 'tomoe_city/street', 250, 650)
	scaleObject('street2', 0.6, 0.6)

	makeLuaSprite('limoSunset', 'tomoe_city/sky', -300, -250);
	scaleObject('limoSunset', 1.2, 1.2)
	setScrollFactor('limoSunset', 0.1, 0.1);

	makeLuaSprite('bgLimo', 'tomoe_city/limoBG', 50, 400)
	setScrollFactor('bgLimo', 1, 1);
        

	addLuaSprite('limoSunset', false)
	addLuaSprite('city', false)
	addLuaSprite('light1', false) 
	addLuaSprite('light2', false) 
	addLuaSprite('street', false)
	addLuaSprite('street2', false)
	addLuaSprite('bgLimo', false)

	addLuaScript('extra_scripts/third/strumlineTorridDevs.lua', false)
	addLuaScript('extra_scripts/smoothcam.lua', false)
	addLuaScript('extra_scripts/strumlineAnims.lua', false)
	addLuaScript('extra_scripts/strumlinescript.lua', false)
	addLuaScript('extra_scripts/charting/torrid/LoadSecondJson.lua', false)

	--characters
	--addLuaScript('extra_scripts/YotsubaNakano_chr.lua', false)
	--addLuaScript('extra_scripts/Azuri-Panda_chr.lua', false)
end

function onCreate()
	--background boi
	makeLuaSprite('stage', 'holostage/stageback', -500, -200)
	setLuaSpriteScrollFactor('stage', 0.6, 0.6)
	addLuaSprite('stage', false)

	makeLuaSprite('stagefront', 'holostage/stagefront', -500, 650)
	setLuaSpriteScrollFactor('stagefront', 0.6, 0.6)
	addLuaSprite('stagefront', false)

	makeLuaSprite('stage2', 'week7/tankSky', -700, -700)
	setLuaSpriteScrollFactor('stage2', 0.6, 0.6)
	addLuaSprite('stage2', false)

	makeAnimatedLuaSprite('smokeRight', 'week7/smokeRight', 700,-100);
		setLuaSpriteScrollFactor('smokeRight', 0.4, 0.4);
		
		makeAnimatedLuaSprite('smokeLeft', 'week7/smokeLeft', -200,-100);
		setLuaSpriteScrollFactor('smokeLeft', 0.4, 0.4);

	addLuaSprite('smokeRight', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('smokeRight', 'idle', 'SmokeRight', 24, true);
	addLuaSprite('smokeLeft', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('smokeLeft', 'idle', 'SmokeBlurLeft', 24, true);

	makeLuaSprite('stage2ground', 'week7/tankGround', -300,100);
	addLuaSprite('stage2ground', false)
	scaleObject('tankGround', 1.15, 1.15);

	setProperty('stage2.visible', false)
	setProperty('smokeRight.visible', false)
	setProperty('smokeLeft.visible', false)
	setProperty('stage2ground.visible', false)
	
end

function onEvent(name,value1,value2)
	if name == 'Play Animation' then 
		
		if value1 == 'changebg1' then
			setProperty('stage.visible', false);
			setProperty('stagefront.visible', false);
			setProperty('stage2.visible', true);
			setProperty('smokeRight.visible', true);
	        setProperty('smokeLeft.visible', true);
			setProperty('stage2ground.visible', true);
		end
		if value1 == 'changebg2' then
			setProperty('stage.visible', true);
			setProperty('stagefront.visible', true);
			setProperty('stage2.visible', false);
			setProperty('smokeRight.visible', false);
	        setProperty('smokeLeft.visible', false);
			setProperty('stage2ground.visible', false);
		end
	end
end
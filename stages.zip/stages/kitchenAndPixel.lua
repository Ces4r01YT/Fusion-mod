function onCreate()
	-- background shit
		makeLuaSprite('evilBG', 'stage holofunk red/evilBG', -400, -420);
   
	 scaleObject('evilBG', 0.9, 0.9);
	makeLuaSprite('stagefront', 'stage holofunk red/evilTreeUncensored', 400, -400);

		makeAnimatedLuaSprite('fireGoBrr', 'stage holofunk red/fireGoBrr',1020, -215);
      
 makeLuaSprite('fireGlow', 'stage holofunk red/fireGlow', 600, 100);
 scaleObject('fireGlow', 0.3, 0.3);

 makeLuaSprite('evilSchoolBG', 'Evilx/evilSchoolBG',-250, 70);
	setLuaSpriteScrollFactor('evilSchoolBG', 0.8, 0.9);
	scaleObject('evilSchoolBG', 6,6);
	 setProperty('evilSchoolBG.antialiasing', false);
	makeLuaSprite('evilSchoolFG', 'Evilx/evilSchoolFG', -125, 70);
	setLuaSpriteScrollFactor('evilSchoolFG', 0.8, 0.9);
	scaleObject('evilSchoolFG', 6,6);
          setProperty('evilSchool.antialiasing', false);

    addLuaSprite('evilSchoolBG', false);
	addLuaSprite('evilSchoolFG', false);
	addLuaSprite('evilBG', false);
	addLuaSprite('stagefront', false);
	addLuaSprite('fireGlow', false);
	addLuaSprite('fireGoBrr', false); 
	addAnimationByPrefix('fireGoBrr', 'idle', 'Fire', 24, true);

	setProperty('evilSchoolBG.visible', false)
	setProperty('evilSchoolFG.visible', false)

end

function onEvent(name,value1,value2)
	if name == 'Play Animation' then 
		
		if value1 == 'changebg1' then
			setProperty('evilBG.visible', false);
			setProperty('stagefront.visible', false);
			setProperty('fireGlow.visible', false);
			setProperty('fireGoBrr.visible', false);
	        setProperty('evilSchoolBG.visible', true);
			setProperty('evilSchoolFG.visible', true);
		end
		if value1 == 'changebg2' then
			setProperty('evilBG.visible', true);
			setProperty('stagefront.visible', true);
			setProperty('fireGlow.visible', true);
			setProperty('fireGoBrr.visible', true);
	        setProperty('evilSchoolBG.visible', false);
			setProperty('evilSchoolFG.visible', false);
		end
	end
end
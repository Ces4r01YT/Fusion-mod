function onCreate()
    setProperty('boyfriend.alpha', 0)
    setProperty('gf.alpha', 0)
    setProperty('skipCountdown', true)
     precacheImage('stages1/fadetransitionshit');

    makeAnimatedLuaSprite('PoemBG', 'stages1/PaperBG', -600, -400);
    addAnimationByPrefix('PoemBG', 'idle', 'PaperBG0', 24, true);
    objectPlayAnimation('PoemBG', 'idle', false);
    scaleLuaSprite('PoemBG', 1.5, 1.5);
    setLuaSpriteScrollFactor('PoemBG', 1.0, 1.0);
    addLuaSprite('PoemBG', false);
    setProperty('PoemBG.visible', false)
    
    makeLuaSprite('SpaceClassroomInside', 'stages1/BG2', -600, -400);
    scaleLuaSprite('SpaceClassroomInside', 1.5,1.5);
    setLuaSpriteScrollFactor('SpaceClassroomInside', 1.0, 1.0);
    addLuaSprite('SpaceClassroomInside', false);
    setProperty('SpaceClassroomInside.visible', false)

    makeLuaSprite('DarkCloset', 'stages1/ClosetBG', -210, 50);
    scaleLuaSprite('DarkCloset', 1.6, 1.6);
    setLuaSpriteScrollFactor('DarkCloset', 1.0, 1.0);
    addLuaSprite('DarkCloset', false);
    setProperty('DarkCloset.visible', true)

function onCreatePost()

	setProperty('timeBar.color', getColorFromHex('DC8CFF'))
	
	end

function onStepHit()
    if curStep == 256 then
        setProperty('DarkCloset.visible', false)
        setProperty('SpaceClassroomInside.visible', true)
    end
        
     if curStep == 448 then
        setProperty('defaultCamZoom', 1.2);
        setProperty('DarkCloset.visible', false)
        setProperty('SpaceClassroomInside.visible', true)
        end
     if curStep == 972 then
        makeLuaSprite('fade', 'stages1/fadetransitionshit', 0, 0)
        setObjectCamera('fade', 'other')
	    scaleLuaSprite('fade', 1.5, 1.5)
	    addLuaSprite('fade', false)
	end

     if curStep == 992 then
        removeLuaSprite('fade')
        setProperty('defaultCamZoom', 1);
        setProperty('DarkCloset.visible', false)
       setProperty('SpaceClassroomInside.visible', true)
       end
       if curStep == 992 then
        removeLuaSprite('fade')
        setProperty('defaultCamZoom', 1);
        setProperty('DarkCloset.visible', false)
       setProperty('SpaceClassroomInside.visible', true)
       end
       if curStep == 1104 then
        setProperty('DarkCloset.visible', true)
       setProperty('SpaceClassroomInside.visible', false)
       end
        
         if curStep == 1248 then
setProperty('defaultCamZoom', 1.1);
setProperty('DarkCloset.visible', false)
        setProperty('SpaceClassroomInside.visible', true)
end

     if curStep == 1504 then
setProperty('defaultCamZoom', 1.2);
        setProperty('DarkCloset.visible', false)
        makeLuaSprite('DaVignette', 'stages1/vignette', -300, 0)
        scaleLuaSprite('DaVignette', 1.5, 1.5)
        setObjectCamera('DaVignette', 'other')
        setLuaSpriteScrollFactor('DaVignette', 1.0, 1.0)
        addLuaSprite('DaVignette', true)
        makeLuaSprite('Transparent', 'stages1/transparent_cover', -300, 0)
        scaleLuaSprite('Transparent', 1.5, 1.5)
        setLuaSpriteScrollFactor('Transparent', 0, 0)
        addLuaSprite('Transparent', true)
      
        setProperty('SpaceClassroomInside.visible', true)
        end
         if curStep == 1632 then
setProperty('defaultCamZoom', 1);
end
     if curStep == 1760 then
        removeLuaSprite('Transparent')
        setProperty('defaultCamZoom', 1.3);
        end
    
     if curStep == 2592 then
        setProperty('defaultCamZoom', 1);
        removeLuaSprite('DaVignette')
        setProperty('DarkCloset.visible', false)
        setProperty('SpaceClassroomInside.visible', true)
        end
        
     if curStep == 2816 then
        makeLuaSprite('fade', 'stages1/fadetransitionshit', 0, 0)
        setObjectCamera('fade', 'hud')
	    scaleLuaSprite('fade', 1.5, 1.5)
	    addLuaSprite('fade', false)
	   setPropertyFromGroup('opponentStrums',0,'alpha',0);
       setPropertyFromGroup('opponentStrums',1,'alpha',0);
      setPropertyFromGroup('opponentStrums',2,'alpha',0);
       setPropertyFromGroup('opponentStrums',3,'alpha',0);
       end
     if curStep == 2832 then
        removeLuaSprite('fade');
        setProperty('DarkCloset.visible', false);
        setProperty('PoemBG.visible', true)
end
     if curStep == 2880 then
        makeLuaSprite('fade', 'stages1/fadetransitionshit', 0, 0)
        setObjectCamera('fade', 'other')
	    scaleLuaSprite('fade', 1.5, 1.5)
	    addLuaSprite('fade', false)
    end
    if curStep == 500 then
      makeAnimatedLuaSprite('MarkovBrowser', 'stages1/MarkovEyes', 500, 300)
      addAnimationByPrefix('MarkovBrowser', 'dance', 'MarkovWindow0', 24, false)
      objectPlayAnimation('MarkovBrowser', 'dance', true)
      scaleLuaSprite('MarkovBrowser', 1, 1)
      setObjectCamera('MarkovBrowser', 'other')
      setProperty('MarkovBrowser.alpha', 1)
      addLuaSprite('MarkovBrowser', true)
      
  elseif curStep == 650 then
      makeAnimatedLuaSprite('MarkovBrowser', 'stages1/MarkovEyes', 800, 100)
      addAnimationByPrefix('MarkovBrowser', 'dance', 'MarkovWindow0', 24, false)
      objectPlayAnimation('MarkovBrowser', 'dance', true)
      scaleLuaSprite('MarkovBrowser', 1, 1)
      setObjectCamera('MarkovBrowser', 'other')
      setProperty('MarkovBrowser.alpha', 1)
      addLuaSprite('MarkovBrowser', true)
  
  elseif curStep == 800 then
      makeAnimatedLuaSprite('MarkovBrowser', 'stages1/MarkovEyes', 300, 500)
      addAnimationByPrefix('MarkovBrowser', 'dance', 'MarkovWindow0', 24, false)
      objectPlayAnimation('MarkovBrowser', 'dance', true)
      scaleLuaSprite('MarkovBrowser', 1, 1)
      setObjectCamera('MarkovBrowser', 'other')
      setProperty('MarkovBrowser.alpha', 1)
      addLuaSprite('MarkovBrowser', true)
  
  elseif curStep == 1150 then
      makeAnimatedLuaSprite('MarkovBrowser', 'stages1/MarkovEyes', 600, 200)
      addAnimationByPrefix('MarkovBrowser', 'dance', 'MarkovWindow0', 24, false)
      objectPlayAnimation('MarkovBrowser', 'dance', true)
      scaleLuaSprite('MarkovBrowser', 1, 1)
      setObjectCamera('MarkovBrowser', 'other')
      setProperty('MarkovBrowser.alpha', 1)
      addLuaSprite('MarkovBrowser', true)
  
  elseif curStep == 1300 then
      makeAnimatedLuaSprite('MarkovBrowser', 'stages1/MarkovEyes', 400, 360)
      addAnimationByPrefix('MarkovBrowser', 'dance', 'MarkovWindow0', 24, false)
      objectPlayAnimation('MarkovBrowser', 'dance', true)
      scaleLuaSprite('MarkovBrowser', 1, 1)
      setObjectCamera('MarkovBrowser', 'other')
      setProperty('MarkovBrowser.alpha', 1)
      addLuaSprite('MarkovBrowser', true)
  
  elseif curStep == 1650 then
      makeAnimatedLuaSprite('MarkovBrowser', 'stages1/MarkovEyes', 900, 400)
      addAnimationByPrefix('MarkovBrowser', 'dance', 'MarkovWindow0', 24, false)
      objectPlayAnimation('MarkovBrowser', 'dance', true)
      scaleLuaSprite('MarkovBrowser', 1, 1)
      setObjectCamera('MarkovBrowser', 'other')
      setProperty('MarkovBrowser.alpha', 1)
      addLuaSprite('MarkovBrowser', true)

  elseif curStep == 1800 then
      makeAnimatedLuaSprite('MarkovBrowser', 'stages1/MarkovEyes', 550, 420)
      addAnimationByPrefix('MarkovBrowser', 'dance', 'MarkovWindow0', 24, false)
      objectPlayAnimation('MarkovBrowser', 'dance', true)
      scaleLuaSprite('MarkovBrowser', 1, 1)
      setObjectCamera('MarkovBrowser', 'other')
      setProperty('MarkovBrowser.alpha', 1)
      addLuaSprite('MarkovBrowser', true)
  
  elseif curStep == 1950 then
      makeAnimatedLuaSprite('MarkovBrowser', 'stages1/MarkovEyes', 200, 50)
      addAnimationByPrefix('MarkovBrowser', 'dance', 'MarkovWindow0', 24, false)
      objectPlayAnimation('MarkovBrowser', 'dance', true)
      scaleLuaSprite('MarkovBrowser', 1, 1)
      setObjectCamera('MarkovBrowser', 'other')
      setProperty('MarkovBrowser.alpha', 1)
      addLuaSprite('MarkovBrowser', true)
      
  elseif curStep == 2016 then
makeAnimatedLuaSprite('MarkovBrowser', 'stages1/MarkovEyes', 550, 420)
      addAnimationByPrefix('MarkovBrowser', 'dance', 'MarkovWindow0', 24, false)
      objectPlayAnimation('MarkovBrowser', 'dance', true)
      scaleLuaSprite('MarkovBrowser', 1, 1)
      setObjectCamera('MarkovBrowser', 'other')
      setProperty('MarkovBrowser.alpha', 1)
      addLuaSprite('MarkovBrowser', true)
      
elseif curStep == 2048 then
makeAnimatedLuaSprite('MarkovBrowser1', 'stages1/MarkovEyes', 400, 360)
      addAnimationByPrefix('MarkovBrowser1', 'dance', 'MarkovWindow0', 24, false)
      objectPlayAnimation('MarkovBrowser1', 'dance', true)
      scaleLuaSprite('MarkovBrowser1', 1, 1)
      setObjectCamera('MarkovBrowser1', 'other')
      setProperty('MarkovBrowser1.alpha', 1)
      addLuaSprite('MarkovBrowser1', true)
      
  elseif curStep == 2080 then
makeAnimatedLuaSprite('MarkovBrowser', 'stages1/MarkovEyes', 670, 360)
      addAnimationByPrefix('MarkovBrowser', 'dance', 'MarkovWindow0', 24, false)
      objectPlayAnimation('MarkovBrowser', 'dance', true)
      scaleLuaSprite('MarkovBrowser', 1, 1)
      setObjectCamera('MarkovBrowser', 'other')
      setProperty('MarkovBrowser.alpha', 1)
      addLuaSprite('MarkovBrowser', true)

  elseif curStep == 2112 then
      makeAnimatedLuaSprite('MarkovBrowser1', 'stages1/MarkovEyes', 100, 100)
      addAnimationByPrefix('MarkovBrowser1', 'dance', 'MarkovWindow0', 24, false)
      objectPlayAnimation('MarkovBrowser1', 'dance', true)
      scaleLuaSprite('MarkovBrowser1', 1, 1)
      setObjectCamera('MarkovBrowser1', 'other')
      setProperty('MarkovBrowser1.alpha', 1)
      addLuaSprite('MarkovBrowser1', true)
      
  elseif curStep == 2113 then
makeAnimatedLuaSprite('MarkovBrowser2', 'stages1/MarkovEyes', 960, 490)
      addAnimationByPrefix('MarkovBrowser2', 'dance', 'MarkovWindow0', 24, false)
      objectPlayAnimation('MarkovBrowser2', 'dance', true)
      scaleLuaSprite('MarkovBrowser2', 1, 1)
      setObjectCamera('MarkovBrowser2', 'other')
      setProperty('MarkovBrowser2.alpha', 1)
      addLuaSprite('MarkovBrowser2', true)

  elseif curStep == 2400 then
      makeAnimatedLuaSprite('MarkovBrowser', 'stages1/MarkovEyes', 670, 360)
      addAnimationByPrefix('MarkovBrowser', 'dance', 'MarkovWindow0', 24, false)
      objectPlayAnimation('MarkovBrowser', 'dance', true)
      scaleLuaSprite('MarkovBrowser', 1, 1)
      setObjectCamera('MarkovBrowser', 'other')
      setProperty('MarkovBrowser.alpha', 1)
      addLuaSprite('MarkovBrowser', true)
  
  elseif curStep == 2550 then
      makeAnimatedLuaSprite('MarkovBrowser1', 'stages1/MarkovEyes', 750, 500)
      addAnimationByPrefix('MarkovBrowser1', 'dance', 'MarkovWindow0', 24, false)
      objectPlayAnimation('MarkovBrowser1', 'dance', true)
      scaleLuaSprite('MarkovBrowser1', 1, 1)
      setObjectCamera('MarkovBrowser1', 'other')
      setProperty('MarkovBrowser1.alpha', 1)
      addLuaSprite('MarkovBrowser1', true)
  
  elseif curStep == 2700 then
      makeAnimatedLuaSprite('MarkovBrowser2', 'stages1/MarkovEyes', 960, 490)
      addAnimationByPrefix('MarkovBrowser2', 'dance', 'MarkovWindow0', 24, false)
      objectPlayAnimation('MarkovBrowser2', 'dance', true)
      scaleLuaSprite('MarkovBrowser2', 1, 1)
      setObjectCamera('MarkovBrowser2', 'other')
      setProperty('MarkovBrowser2.alpha', 1)
      addLuaSprite('MarkovBrowser2', true)
  end

end
﻿function onCreate()
	-- background shit
	makeLuaSprite('gotoubun-5_stage', 'quintuplets/kitchen5_Background', -400, -400);
	setScrollFactor('gotoubun-5_stage', 0.9, 0.9);

	addLuaSprite('gotoubun-5_stage', false);

    precacheImage('quintuplets/NinoMikuFightSceneFIXED')

	makeLuaSprite('Screen', 'empty', -140, -10)
	makeGraphic('Screen', 12800, 1200, '000000')
	addLuaSprite('Screen', true)
	setProperty('Screen.alpha', 0)


	precacheImage('The')
	precacheImage('Quintessential')
	precacheImage('Quintuplets1')
	precacheImage('Go-logo')
end

function onBeatHit()
	if curBeat == 224 then
		setProperty('Screen.alpha', 1)
		makeLuaSprite('Three', 'The', 0, 0)
		addLuaSprite('Three')
		screenCenter('Three', 'xy')
		setObjectCamera('Three', 'other')
	end
	if curBeat == 225 then
		makeLuaSprite('Two', 'Quintessential', 0, 0)
		addLuaSprite('Two')
		screenCenter('Two', 'xy')
		setObjectCamera('Two', 'other')
        setProperty('Three.alpha', 0)
	end
	if curBeat == 226 then
		makeLuaSprite('One', 'Quintuplets1', 0, 0)
		addLuaSprite('One')
		screenCenter('One', 'xy')
		setObjectCamera('One', 'other')
		setProperty('Two.alpha', 0)
	end
	if curBeat == 227 then
		setProperty('One.alpha', 0)
	end
	if curBeat == 228 then
		setProperty('Screen.alpha', 0)
	end
	if curBeat == 356 then
		makeAnimatedLuaSprite('fight','quintuplets/NinoMikuFightSceneFIXED', 0, 0)
		addAnimationByPrefix('fight','quintuplets/NinoMikuFightSceneFIXED','Intro', 24, true)
		addLuaSprite('fight', false);
		setObjectCamera('fight', 'HUD')
		scaleObject('fight', 1.5, 1.5)
		screenCenter('fight', 'xy')
	end
	if curBeat == 360 then
	   setProperty('fight.visible', false)
	end
end

-- Script by a dumbass you just watched from (HenrySMD)

local healthBarIsFlip = true
local stickThere = false
function onUpdate(elapsed)
	if healthBarIsFlip == true then -- if you want to flip the health bar or not (set to true to flip, set false will turn back to normal)
		setProperty('healthBar.flipX', true)

		if getProperty('health') < 2 then
			stickThere = false
		end

		if getProperty('health') >= 2 then
			stickThere = true
		end
	else
		setProperty('healthBar.flipX', false)
	end
end

function onUpdatePost()
	if healthBarIsFlip == true then
		setProperty('iconP1.flipX', true)
		setProperty('iconP2.flipX', true)

		if stickThere == false then
			if getProperty('health') > 0 then
				setProperty('iconP1.x', 216+getProperty('health')*296+getProperty('healthBar.x')-343.5)
				setProperty('iconP2.x', 317+getProperty('health')*297+getProperty('healthBar.x')-343.5)
			end

			if getProperty('health') <= 0 then
				setProperty('iconP1.x', 216+getProperty('healthBar.x')-343.5)
				setProperty('iconP2.x', 317+getProperty('healthBar.x')-343.5)
			end
		end

		if stickThere == true then
		   setProperty('iconP1.x', 808+getProperty('healthBar.x')-343.5)
		   setProperty('iconP2.x', 911+getProperty('healthBar.x')-343.5)
		end

		--setProperty('iconP1.y', getProperty('healthBar.y') -75) -- icons stick to health bar (y position), I added if you guys want
		--setProperty('iconP2.y', getProperty('healthBar.y') -75)
	else
		setProperty('iconP1.flipX', false)
		setProperty('iconP2.flipX', false)
	end
end

function onCreatePost()
	addCharacterToList('nino-guitar-alt', 'dad')
	addCharacterToList('miku-angry-player-flipped', 'boyfriend')
	if not middleScroll then
        setPropertyFromGroup('playerStrums', 0, 'x', defaultPlayerStrumX0 - 635);
        setPropertyFromGroup('playerStrums', 1, 'x', defaultPlayerStrumX1 - 635);
        setPropertyFromGroup('playerStrums', 2, 'x', defaultPlayerStrumX2 - 635);
        setPropertyFromGroup('playerStrums', 3, 'x', defaultPlayerStrumX3 - 635);

		setPropertyFromGroup('opponentStrums', 0, 'x', defaultOpponentStrumX0 - -635);
        setPropertyFromGroup('opponentStrums', 1, 'x', defaultOpponentStrumX1 - -635);
        setPropertyFromGroup('opponentStrums', 2, 'x', defaultOpponentStrumX2 - -635);
        setPropertyFromGroup('opponentStrums', 3, 'x', defaultOpponentStrumX3 - -635);
	end
end


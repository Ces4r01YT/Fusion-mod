function onCreate()
	
	makeLuaSprite('black', 'black', 0, 0);
	scaleObject('black', 20, 20);
	setProperty('black.visible', false);

	makeLuaSprite('black1', 'blackFlash', -720, -680);
	scaleObject('black1', 1, 1);
	setProperty('black1.visible', false);

	makeLuaSprite('bg', 'back1', -720, -680);
    scaleObject('bg', 2, 2);
	addLuaSprite('bg', false);

	makeLuaSprite('thefrickinbg', 'SonicP2/Youcantrunbg', -285, -55); --imagine being lazy lol

	scaleObject('thefrickinbg', 1.95, 1.95);
	setProperty('thefrickinbg.antialiasing', true);

	makeLuaSprite('thebg', 'SonicP2/greenhillsbiggggg', -285, -55); --imagine being lazy lol

	scaleObject('thebg', 1, 1);
	setProperty('thebg.visible', false);

	addLuaSprite('thefrickinbg', false);
	addLuaSprite('thebg', false);
	addLuaSprite('black1', true);

end

function onStepHit()

	if curBeat == 0 then
		
		if curStep == 1 then

			setProperty('betadciustatic.visible', true);
			luaSpritePlayAnimation('betadciustatic', 'betadciustatic', true);
		
		end

	end

	if curBeat == 4 then

		setProperty('betadciustatic.visible', false);

	end

	if curBeat == 36 then

		if curStep == 144 then

			setProperty('SharvJumpscare.visible', true);
			setProperty('black.visible', true);
		
		end

		if curStep == 145 then

			setProperty('SharvJumpscare.visible', false);
			setProperty('black.visible', false);

		end
	
		if curStep == 146 then

			setProperty('SharvJumpscare.visible', true);
			setProperty('black.visible', true);
		
		end

		if curStep == 147 then

			setProperty('SharvJumpscare.visible', false);
			setProperty('black.visible', false);

		end

	end

	if curBeat == 132 then
		
		if curStep == 1025 then

			setProperty('betadciustatic.visible', true);
			luaSpritePlayAnimation('betadciustatic', 'betadciustatic', true);

		end	

	end

	if curBeat == 132 then

		setProperty('thefrickinbg.visible', false);
		setProperty('thebg.visible', true);

	end

	if curBeat == 272 then

		if curStep == 1089 then

			setProperty('betadciustatic.visible', true);
			luaSpritePlayAnimation('betadciustatic', 'betadciustatic', true);

		end

	end

	if curBeat == 276 then

		setProperty('betadciustatic.visible', false);

	end

	if curBeat == 304 then

		if curStep == 1217 then

			setProperty('betadciustatic.visible', true);
			luaSpritePlayAnimation('betadciustatic', 'betadciustatic', true);

		end

	end

	if curBeat == 308 then

		setProperty('betadciustatic.visible', false);

	end

	if curBeat == 320 then

		if curStep == 1281 then

			setProperty('betadciustatic.visible', true);
			luaSpritePlayAnimation('betadciustatic', 'betadciustatic', true);

		end

	end

	if curBeat == 323 then

		if curStep == 1293 then

			setProperty('NeonightJumpscare.visible', true);
			setProperty('black.visible', true);

		end

		if curStep == 1294 then

			setProperty('NeonightJumpscare.visible', false);
			setProperty('black.visible', false);

		end

		if curStep == 1295 then

			setProperty('NeonightJumpscare.visible', true);
			setProperty('black.visible', true);

		end

		if curStep == 1296 then

			setProperty('NeonightJumpscare.visible', false);
			setProperty('black.visible', false);

		end
	
	end

	if curBeat == 196 then


		setProperty('thefrickinbg.visible', true);
		setProperty('thebg.visible', false);

	end

	if curBeat == 576 then

		if curStep == 2305 then

			setProperty('betadciustatic.visible', true);
			luaSpritePlayAnimation('betadciustatic', 'betadciustatic', true);

		end

	end

	if curBeat == 323 then

		setProperty('black1.visible', true);

	end

	if curBeat == 704 then

		if curStep == 2817 then

			setProperty('betadciustatic.visible', true);
			luaSpritePlayAnimation('betadciustatic', 'betadciustatic', true);

		end

	end

	if curBeat == 707 then

		if curStep == 2829 then

			setProperty('SebasyJumpscare.visible', true);

		end

		if curStep == 2830 then

			setProperty('SebasyJumpscare.visible', false);

		end

		if curStep == 2831 then

			setProperty('SebasyJumpscare.visible', true);

		end

		if curStep == 2832 then

			setProperty('SebasyJumpscare.visible', false);

		end

	end

	if curBeat == 355 then

		setProperty('black1.visible', false);
		setProperty('thefrickinbg.visible', true);

	end

	if curBeat == 800 then

		if curStep == 3201 then

			setProperty('betadciustatic.visible', true);
			luaSpritePlayAnimation('betadciustatic', 'betadciustatic', true);

		end

	end

	if curBeat == 804 then

		setProperty('betadciustatic.visible', false);

	end

	if curBeat == 1024 then

		if curStep == 4097 then

			setProperty('betadciustatic.visible', true);
			luaSpritePlayAnimation('betadciustatic', 'betadciustatic', true);

		end

	end

	if curBeat == 1028 then

		setProperty('Glitch.visible', false);
		setProperty('Trees.visible', false);
		setProperty('Trees.visible', true);
		setProperty('Grass.visible', true);
		setProperty('redstatic.visible', true);
		setProperty('betadciustatic.visible', false);
		setProperty('bg5.visible', false);
		setProperty('bg6.visible', true);

	end

end

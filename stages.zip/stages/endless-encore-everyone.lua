function onCreate()

	makeLuaSprite('funsky','funstage/sonicFUNsky', -300, 0);
	setScrollFactor('funsky', 0.8, 0.8);
    addLuaSprite('funsky', false);
	makeLuaSprite('backbush','funstage/Bush2', -300, 150);
	setScrollFactor('backbush', 1, 1);
    addLuaSprite('backbush', false);
	makeAnimatedLuaSprite('backbop','funstage/Majin Boppers Back', 0, -250);
	setScrollFactor('backbop', 0.9, 1);
	addAnimationByPrefix('backbop', 'bopback', 'MajinBop2 instance', 26, false);
	objectPlayAnimation('backbop', 'bopback', false);
    addLuaSprite('backbop', false);	
	makeLuaSprite('frontbush','funstage/Bush 1', -150, 350);
	setScrollFactor('frontbush', 1, 1);
    addLuaSprite('frontbush', false);	
	makeAnimatedLuaSprite('frontbop','funstage/Majin Boppers Front', -350, -300);
	setScrollFactor('frontbop', 0.9, 1);
	addAnimationByPrefix('frontbop', 'bopfront', 'MajinBop1 instance', 26, false);
	objectPlayAnimation('frontbop', 'bopfront', false);
    addLuaSprite('frontbop', false);
	makeLuaSprite('funfloor','funstage/floor BG', -400, 550);
	setScrollFactor('funfloor', 1, 1);
    addLuaSprite('funfloor', false);
	makeAnimatedLuaSprite('fg1','funstage/majin FG1', 1200, 750);
	setScrollFactor('fg1', 0.9, 1);
	addAnimationByPrefix('fg1', 'bop1', 'majin front bopper', 26, false);
	objectPlayAnimation('fg1', 'bop1', false);
	setObjectOrder('fg1',10);
    addLuaSprite('fg1', false);
	makeAnimatedLuaSprite('fg2','funstage/majin FG2', -400, 750);
	setScrollFactor('fg2', 0.9, 1);
	addAnimationByPrefix('fg2', 'bop2', 'majin front bopper2', 28, false);
	objectPlayAnimation('fg2', 'bop2', false);	
	setObjectOrder('fg2',11);
    addLuaSprite('fg2', false);


	precacheImage('majinthing/Majin_Notes')
	precacheImage('majinthing/Majin_Splashes')
	precacheImage('majinthing/three')
	precacheImage('majinthing/two')
	precacheImage('majinthing/one')
	precacheImage('majinthing/go')
end
local numbercount = 0
function onEvent(name,v1,v2)
    if name == 'wewe' then
        makeLuaSprite('fut', 'majinthing/future',60, 230);
        
        addLuaSprite('fut', 'false');
        scaleObject('fut',0.3,0.3)
        setObjectCamera('fut', 'other');
        doTweenAlpha('fut','fut',0,1.5,'sineOut')
end
end
function onCreatePost()
	setProperty('gf.alpha', 0)
	setProperty('iconP1.color',getColorFromHex('171EEA'))
	setProperty('scoreTxt.visible',false)
	setProperty('boyfriend.color',getColorFromHex('464CFF'))
end
local vasuhu = {'noone','backbush','backbop','frontbush','frontbop','funfloor','fg1','fg2'}
function onUpdate()
	for i = 1,8 do
	setProperty(vasuhu[i+1]..'.alpha',getProperty('funsky.alpha'))
	end
end
local dadsingL = 4
local bfsingL = 4

		realAnimdad = 'idle'
		realAnimbf = 'idle'
		function getAnim(char,prop)
			prop = prop or 'name'
				return getProperty(char .. '.animation.curAnim.' .. prop)
			
			end
function onStepHit()
	if curStep % 4 == 0 then
		if getAnim("dad") == "idle"..getProperty('dad.idleSuffix') then
			characterPlayAnim("dad","idle"..getProperty('dad.idleSuffix'),true)
		end
		if getAnim("boyfriend") == "idle"..getProperty('boyfriend.idleSuffix') then
			characterPlayAnim("boyfriend","idle"..getProperty('boyfriend.idleSuffix'),true)
		end
		objectPlayAnimation('fg1', 'bop1', true);
		objectPlayAnimation('fg2', 'bop2', true);
		objectPlayAnimation('frontbop', 'bopfront', true);
		objectPlayAnimation('backbop', 'bopback', true);
	end
end

local allowCountdown = false
local yeah = true;
function onCreate(elapsed) ---why its being elapsed? [X probably]
	precacheImage('Majin_Notes');
	precacheImage('MajinSplashes');
	setPropertyFromClass('GameOverSubstate', 'loopSoundName', 'lookyourself');
	setPropertyFromClass('GameOverSubstate', 'endSoundName', 'itsover');
	setProperty('gf.visible', false);
end                        --- Fun is Infinite [Fun Guy probably]


function onStartCountdown() --- i do countdown now fuck off [EX- X probably]
	if not allowCountdown then
		runTimer('circleThing', 0.1);
		allowCountdown = true;
		startCountdown();
		return Function_Stop;
	end
	return Function_Continue;
end                         --- no lol ratio + l [Fleet probably]

function onTimerCompleted(tag, loops, loopsLeft) ---WATCH YO TONE MF [X probably..]
	if tag == 'circleThing' then
		makeLuaSprite('void', 'majinthing/voidlol', 0, 0);
		setObjectCamera('void', 'hud');
		addLuaSprite('void', true);
		makeLuaSprite('dacircle', 'majinthing/CircleMajin', 777, 0);
		setObjectCamera('dacircle', 'hud');
		addLuaSprite('dacircle', true);
		makeLuaSprite('datext', 'majinthing/TextMajin', -1100, 0);
		setObjectCamera('datext', 'hud');
		addLuaSprite('datext', true);
		runTimer('firstlook', 0.6, 1);
		runTimer('endlook', 1.9, 1);
	elseif tag == 'firstlook' then
		doTweenX('gettwee', 'dacircle', 0, 0.5, linear);
		doTweenX('gettween', 'datext', 0, 0.5, linear);
	elseif tag == 'endlook' then
		doTweenAlpha('getfad', 'dacircle', 0, 1, linear);
		doTweenAlpha('getfade', 'datext', 0, 1, linear);
		doTweenAlpha('getfaded', 'void', 0, 1, linear);
	end
end                                            --- FUCK OFF [Fleet probably..]
﻿function onCreate()
	-- background shit
	makeLuaSprite('gotoubun-5_stage', 'quintuplets/gotoubun-5_stage', -400, -400);
	setScrollFactor('gotoubun-5_stage', 0.9, 0.9);

	addLuaSprite('gotoubun-5_stage', false);



	addLuaScript('extra_scripts/YotsubaNakano_chr', false)
	addLuaScript('extra_scripts/MikuNakano_chr', false)
end
function onCreate()

	makeAnimatedLuaSprite('staticBACKGROUND2', 'piracy/staticBACKGROUND2', -350, -300);
	setLuaSpriteScrollFactor('staticBACKGROUND2', 1.2, 1.2);
	scaleObject('staticBACKGROUND2', 2, 2);

    addAnimationByPrefix('staticBACKGROUND2', 'idle', 'menuSTATICNEW instance ', 24, true);
    addLuaSprite('staticBACKGROUND2', false);


    makeLuaSprite('vert bg1','piracy/vert bg', -1180,-300 )
    addLuaSprite('vert bg1', false)
    scaleObject('vert bg1', 1.5, 1.5);
    setProperty('vert bg1.angle', 90)

    makeLuaSprite('vert bg2','piracy/vert bg', 980,-300 )
    addLuaSprite('vert bg2', false)
    scaleObject('vert bg2', 1.5, 1.5);
    setProperty('vert bg2.angle', 90)

    makeLuaSprite('vert bg3','piracy/vert bg', -100,-300 )
    addLuaSprite('vert bg3', false)
    scaleObject('vert bg3', 1.5, 1.5);
    setProperty('vert bg3.angle', 90)


    makeLuaSprite('1s0s','piracy/1s0s', -500,-500 )
    addLuaSprite('1s0s', false)
    scaleObject('1s0s', 2.2, 2.5);

    makeLuaSprite('piracy bg','piracy/piracy bg', -500,-400 )
    addLuaSprite('piracy bg', false)
    scaleObject('piracy bg', 2.2, 2.5);

    makeLuaSprite('bg','piracy/bg', -400,-300 )
    addLuaSprite('bg', false)

    makeLuaSprite('piracy','piracy/piracy', 0,0 )
    addLuaSprite('piracy', false)

    makeLuaSprite('is','piracy/is', 0,0 )
    addLuaSprite('is', false)

    makeLuaSprite('a','piracy/a', 0,0 )
    addLuaSprite('a', false)

    makeLuaSprite('crime','piracy/crime', 0,0 )
    addLuaSprite('crime', false)

    setObjectCamera('piracy', 'other')
    setObjectCamera('is', 'other')
    setObjectCamera('a', 'other')
    setObjectCamera('crime', 'other')





    makeLuaSprite('please','please', 0,0 )
    addLuaSprite('please', false)

    makeLuaSprite('return','return', 0,0 )
    addLuaSprite('return', false)

    makeLuaSprite('this','this', 0,0 )
    addLuaSprite('this', false)

    makeLuaSprite('cart','cart', 0,0 )
    addLuaSprite('cart', false)

    makeLuaSprite('ridge','ridge', 0,0 )
    addLuaSprite('ridge', false)

    setObjectCamera('please', 'hud')
    setObjectCamera('return', 'hud')
    setObjectCamera('this', 'hud')
    setObjectCamera('cart', 'hud')
    setObjectCamera('ridge', 'hud')



    makeLuaSprite('error','piracy/error', 0,0 )
    addLuaSprite('error', true)
    setObjectCamera('error', 'hud')





    setProperty('vert bg1.visible', false)
    setProperty('vert bg2.visible', false)
    setProperty('vert bg3.visible', false)

    setProperty('piracy bg.visible', false)

    setProperty('1s0s.visible', false)
    
    setProperty('staticBACKGROUND2.visible', false)


    setProperty('skipCountdown', true)
end
function onCreatePost()
    setProperty('gf.visible', false)

    setProperty('showComboNum', false);
    setProperty('showRating', false);
    setProperty('scoreTxt.visible', false);
    setProperty('timeBar.visible', false);
    setProperty('timeBarBG.visible', false);
    setProperty('timeTxt.visible', false)
    setProperty('iconP1.visible', false);
    setProperty('iconP2.visible', false);
    setProperty('healthBar.visible', false);
    setProperty('healthBarBG.visible', false);
    setTextString("botplayTxt", "hreds")


    setProperty('piracy.alpha', 0)
    setProperty('is.alpha', 0)
    setProperty('a.alpha', 0)
    setProperty('crime.alpha', 0)


    setProperty('please.alpha', 0)
    setProperty('return.alpha', 0)
    setProperty('this.alpha', 0)
    setProperty('cart.alpha', 0)
    setProperty('ridge.alpha', 0)


    setProperty('error.alpha', 0)

    setProperty('char.alpha', 0)
    setProperty('char2.alpha', 0)
    setProperty('char3.alpha', 0)


    precacheImage('staticBACKGROUND2')

    precacheImage('piracy')
    precacheImage('is')
    precacheImage('a')
    precacheImage('crime')
    precacheImage('please')
    precacheImage('return')
    precacheImage('this')
    precacheImage('cart')
    precacheImage('ridge')
end



function onUpdate()
if dadName == 'PiracySonic' then
    if getProperty('dad.animation.curAnim.name') == 'singLEFT' then
    setProperty('boyfriend.angle', 14)
    setProperty('boyfriend.x', 680)
    setProperty('boyfriend.y', 70)
    end
    if getProperty('dad.animation.curAnim.name') == 'singDOWN' then
    setProperty('boyfriend.angle', 50)
    setProperty('boyfriend.x', 800)
    setProperty('boyfriend.y', 90)
    end
    if getProperty('dad.animation.curAnim.name') == 'singUP' then
    setProperty('boyfriend.x', 800)
    setProperty('boyfriend.y', 50)
    setProperty('boyfriend.angle', 50)
    end
    if getProperty('dad.animation.curAnim.name') == 'idle' then
    setProperty('boyfriend.angle', 0)
    setProperty('boyfriend.x', 750)
    setProperty('boyfriend.y', 70)
    end
    if getProperty('dad.animation.curAnim.name') == 'singRIGHT' then
    setProperty('boyfriend.angle', 0)
    setProperty('boyfriend.x', 850)
    setProperty('boyfriend.y', 40)
    end
end
end

function onSectionHit()
    if mustHitSection then
      setProperty('defaultCamZoom', 1.2)
    else
      setProperty('defaultCamZoom', 0.65)
    end
    if curStep >= 426 then
        if mustHitSection then
            setProperty('defaultCamZoom', 0.5)
        else
            setProperty('defaultCamZoom', 0.5)
        end
    end
    if curStep >= 686 then
        if mustHitSection then
            setProperty('defaultCamZoom', 1.2)
        else
            setProperty('defaultCamZoom', 0.65)
        end
    end
    if curStep >= 1086 then
        if mustHitSection then
            setProperty('defaultCamZoom', 0.65)
        else
            setProperty('defaultCamZoom', 0.65)
        end
    end
    if curStep >= 1479 then
        if mustHitSection then
            setProperty('defaultCamZoom', 1.2)
        else
            setProperty('defaultCamZoom', 0.65)
        end
    end
end


function onStepHit()
    if curStep == 1 then
        doTweenAlpha('piracy','piracy', 1, 0.25, 'expoInOut')

        setProperty('camGame.angle', 180)
        setProperty('camGame.alpha', 0)
        setProperty('camHUD.alpha', 0)

        for i = 0, 3 do
            setPropertyFromGroup("strumLineNotes", i, 'alpha', 0)
        end
    end
    if curStep == 9 then
        doTweenAlpha('is','is', 1, 0.25, 'expoInOut')
    end
    if curStep == 10 then
        doTweenAlpha('a','a', 1, 0.25, 'expoInOut')
    end
    if curStep == 12 then
        doTweenAlpha('crime','crime', 1, 0.25, 'expoInOut')
    end
    if curStep == 28 then
        doTweenAlpha('piracy','piracy', 0, 0.5, 'expoInOut')
        doTweenAlpha('is','is', 0, 0.5, 'expoInOut')
        doTweenAlpha('a','a', 0, 0.5, 'expoInOut')
        doTweenAlpha('crime','crime', 0, 0.5, 'expoInOut')
    end
    if curStep == 31 then
        doTweenAngle('ttrn', 'camGame', 1440, 1.2, 'expoOut')
    end
    if curStep == 32 then
        cameraFlash('game', '000000', 1, 1)
        setProperty('camGame.alpha', 1)
        doTweenAlpha('alpha', 'camHUD', 1, 3, 'expoInOut')
    end
end
function onCreate()
	-- background shit
	makeLuaSprite('stageback', 'russia/motherBG', -700, -800);
	setLuaSpriteScrollFactor('stageback', 0.9, 0.9);
	scaleObject('stageback', 1.1, 1.1);

	-- sprites that only load if Low Quality is turned off
	if not lowQuality then
	makeLuaSprite('stagefront', 'russia/motherFG', -650, -800);
	setLuaSpriteScrollFactor('stagefront', 0.9, 0.9);
	scaleObject('stagefront', 1.1, 1.1);

	makeAnimatedLuaSprite('sunday-guitar-bg', 'sunday_guitar_assets', 0, 0)addAnimationByPrefix('sunday-guitar-bg', 'idle', 'sunday guitar idle', 24, true)
	objectPlayAnimation('sunday guitar alt left', 'singLEFT', false)
	objectPlayAnimation('sunday guitar alt down', 'singDOWN', false)
	objectPlayAnimation('sunday guitar alt up', 'singUP', false)
	objectPlayAnimation('sunday guitar alt right', 'singRIGHT', false)
	setScrollFactor('sundaybg', 0.9, 0.9); --put In bg.lua shit

	makeLuaSprite('plants', 'russia/plants', -1000, -1200);

	scaleObject('plants', 1.4, 1.4);
	
	end

	addLuaSprite('stageback', false);
	addLuaSprite('stagefront', false);
	addAnimatedLuaSprite('sundaybg', false);
	addLuaSprite('plants',true);
	
end
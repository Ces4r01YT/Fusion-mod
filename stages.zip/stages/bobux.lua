function onCreate()
    makeLuaSprite('bobuxBg','backgrounds/Destruido',-600,-200)
    addLuaSprite('bobuxBg',false)
end
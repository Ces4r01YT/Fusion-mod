﻿function onCreate()
	-- background shit
	makeLuaSprite('gotoubun-5_stage', 'quintuplets/gotoubun-5_stage_sunset', -400, -400);
	setScrollFactor('gotoubun-5_stage', 0.9, 0.9);

	addLuaSprite('gotoubun-5_stage', false);


makeLuaSprite('white', '', -400, -400)
makeGraphic('white', 12800, 12000, 'FFFFFF')



makeLuaSprite('shad', '')
makeGraphic('shad', screenWidth, screenHeight, 'FF6A00')
setProperty('shad.alpha', 0.15)
setObjectCamera('shad', 'camHUD')
addLuaSprite('shad', false)
--setBlendMode('shad', 'add')


makeLuaSprite('black', '')
makeGraphic('black', screenWidth, screenHeight, '000000')
setObjectCamera('black', 'other')
addLuaSprite('black', false)


makeLuaText('text01', "Let's", 0, 400, 300);
setTextSize('text01', 127);
setTextFont('text01', 'NatsukiPoem.ttf')
setObjectCamera('text01', 'other');
setTextColor('text01', 'FFFFFF')
addLuaText('text01');
setProperty('text01.alpha', 0)

makeLuaText('text02', "Go!!", 0, 400, 400);
setTextSize('text02', 127);
setTextFont('text02', 'NatsukiPoem.ttf')
setObjectCamera('text02', 'other');
setTextColor('text02', 'FFFFFF')
addLuaText('text02');
setProperty('text02.alpha', 0)
end


function onUpdatePost(elapsed)
    for i = 0, getProperty('opponentStrums.length')-1 do
		setPropertyFromGroup('opponentStrums', i, 'texture', 'NOTE_assets_ddlc');
	end
	for i = 0, getProperty('unspawnNotes.length')-1 do
		if getPropertyFromGroup('unspawnNotes', i, 'mustPress') == false then
		setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets_ddlc');
		end
	end
	for i = 0, getProperty('playerStrums.length')-1 do
	setPropertyFromGroup('playerStrums', i, 'texture', 'NOTE_assets_Nino');
	end
	for i = 0, getProperty('unspawnNotes.length')-1 do
		if getPropertyFromGroup('unspawnNotes', i, 'mustPress') then
		setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets_Nino');
		end
	end
end

function onEvent(name,v1,v2)
	if name == 'Blank Event' then
		if v1 == 'lets' then
        doTweenAlpha('hewotext1', 'text01', 1, 0.5, 'cubeOut')
		doTweenX('movetext1', 'text01', 450, 0.5, 'cubeOut')
		end
		if v1 == 'go' then
			doTweenAlpha('hewotext2', 'text02', 1, 0.5, 'cubeOut')
			doTweenX('movetext2', 'text02', 450, 0.5, 'cubeOut')
		end
		if v1 == 'off' then
			doTweenAlpha('byetext1', 'text01', 0, 0.5, 'cubeOut')
			doTweenAlpha('byetext2', 'text02', 0, 0.5, 'cubeOut')
		end
		if v2 == 'reset' then
			doTweenX('reset1', 'text01', 400, 0.01, 'linear')
			doTweenX('reset2', 'text02', 400, 0.01, 'linear')
		end
	end
end

function onBeatHit()
	if curBeat == 1 then
		doTweenAlpha('starting', 'black', 0, 15, 'linear')
	end
	if curBeat == 290 then
		addLuaSprite('white', false)
		setProperty('shad.alpha', 0)
		setProperty('boyfriend.color', '000000')
		setProperty('dad.color', '000000')
	end
    if curBeat == 322 then
    	doTweenColor('colorNats', 'dad', 'FFFFFF', 10, 'cubeOut')
    	doTweenColor('colorNino', 'boyfriend', 'FFFFFF', 10, 'cubeOut')
    end
    if curBeat == 372 then
    	removeLuaSprite('white')
		setProperty('shad.alpha', 0.15)
    end
	if curBeat == 472 then
		doTweenAlpha('ending', 'black', 1, 2, 'linear')
    end
end
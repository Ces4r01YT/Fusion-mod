function onCreate()
	-- background shit
		makeLuaSprite('evilBG', 'stage holofunk red/evilBG', -400, -420);
   
	 scaleObject('evilBG', 0.9, 0.9);
	makeLuaSprite('stagefront', 'stage holofunk red/evilTreeUncensored', 400, -400);

		makeAnimatedLuaSprite('fireGoBrr', 'stage holofunk red/fireGoBrr',1020, -210);
      
    makeLuaSprite('fireGlow', 'stage holofunk red/fireGlow', 670, 100);
    scaleObject('fireGlow', 0.3, 0.3);

	
	addLuaSprite('evilBG', false);
	addLuaSprite('stagefront', false);
	addLuaSprite('fireGlow', false);
	setProperty('fireGlow.alpha', 0)
	
	addAnimationByPrefix('fireGoBrr', 'idle', 'Fire', 24, false);



    makeLuaSprite('screen', '')
    makeGraphic('screen', screenWidth, screenHeight, '000000')
	setObjectCamera('screen', 'camHUD')
    

	setProperty('cameraSpeed', 2.8);

	setProperty('skipCountdown', true)

	addLuaScript('extra_scripts/Holofunk-hud', false)
end


function onBeatHit()
	if curBeat == 32 then
		addLuaSprite('fireGoBrr', false); 
		objectPlayAnimation('fireGoBrr', 'idle', false)
		setProperty('fireGlow.alpha', 1)
		doTweenAlpha('fireOut', 'fireGlow', 0, 0.5, 'cubeOut')
	end
	if curBeat == 92 then
	--three
	end
	if curBeat == 93 then
		--two
	end
	if curBeat == 94 then
			--one
	end
	if curBeat == 95 then
		--go
	end
	if curBeat == 96 then
		objectPlayAnimation('fireGoBrr', 'idle', false)
		setProperty('fireGlow.alpha', 1)
		doTweenAlpha('fireOut', 'fireGlow', 0, 0.5, 'cubeOut')
	end
	if curBeat == 160 then
		setProperty('cameraSpeed', 5);
	end
	if curBeat == 192 then
		setProperty('cameraSpeed', 15);
	end
	if curBeat == 256 then
		addLuaSprite('screen', false)
		doTweenAlpha('blackFadeout', 'screen', 0, 11, 'cirIn')
		setProperty('cameraSpeed', 0.7);
	end
end

verticalHaatoPair = {770, 772, 774, 776, 778, 780, 782, 784, 786, 788, 790, 792, 794, 796, 798, 800, 802, 804, 806, 808, 810, 812, 814, 816, 818, 820, 822, 824, 826, 828, 830, 832, 834, 836, 838, 840, 842, 844, 846, 848, 850, 852, 854, 856, 858, 860, 862, 864, 866, 868, 870, 872, 874, 876, 878, 880, 882, 884, 886, 888, 890, 892, 894, 896, 898, 900, 902, 904, 906, 908, 910, 912, 914, 916, 918, 920, 922, 924, 926, 928, 930, 932, 934, 936, 938, 940, 942, 944, 946, 948, 950, 952, 954, 956, 958, 960, 962, 964, 966, 968, 970, 972, 974, 976, 978, 980, 982, 984, 986, 988, 990, 992, 994, 996, 998, 1000, 1002, 1004, 1006, 1008, 1010, 1012, 1014, 1016, 1018, 1020}
    verticalHaatoNotPair = {769, 771, 773, 775, 777, 779, 781, 783, 785, 787, 789, 791, 793, 795, 797, 799, 801, 803, 805, 807, 809, 811, 813, 815, 817, 819, 821, 823, 825, 827, 829, 831, 833, 835, 837, 839, 841, 843, 845, 847, 849, 851, 853, 855, 857, 859, 861, 863, 865, 867, 869, 871, 873, 875, 877, 879, 881, 883, 885, 887, 889, 891, 893, 895, 897, 899, 901, 903, 905, 907, 909, 911, 913, 915, 917, 919, 921, 923, 925, 927, 929, 931, 933, 935, 937, 939, 941, 943, 945, 947, 949, 951, 953, 955, 957, 959, 961, 963, 965, 967, 969, 971, 973, 975, 977, 979, 981, 983, 985, 987, 989, 991, 993, 995, 997, 999, 1001, 1003, 1005, 1007, 1009, 1011, 1013, 1015, 1017, 1019}

function onStepHit()
	if curStep == 640 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 50, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 50, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 50, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 50, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 50, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 50, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 50, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 50, 0.05, "bounceOut");
	end
	if curStep == 641 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 642 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 643 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 644 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 645 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 646 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 647 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 648 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 649 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 650 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 651 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 652 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 653 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 654 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 655 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 656 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 657 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 658 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 659 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 660 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 661 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 662 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 663 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 664 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 665 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 666 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 667 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 668 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 669 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 670 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 671 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 656 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 657 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 658 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 659 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 660 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 661 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 662 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 663 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 664 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 665 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 666 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 667 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 668 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 669 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 670 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 671 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 672 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 673 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 674 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 675 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 676 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 677 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 678 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 679 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 680 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 681 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 682 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 683 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 684 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 685 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 686 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 687 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 688 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 689 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 690 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 691 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 692 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 693 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 694 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 695 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 696 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 697 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 698 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 699 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 700 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 701 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 702 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 703 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 704 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 705 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 706 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 707 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 708 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 709 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 710 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 711 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 712 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 713 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 714 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 715 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 716 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 717 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 718 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 719 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 720 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 721 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 722 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 723 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 724 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 725 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 726 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 727 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 728 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 729 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 730 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 731 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 732 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 733 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 734 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 735 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 736 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 737 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 738 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 739 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 740 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 741 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 742 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 743 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 744 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 745 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 746 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 747 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 748 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 749 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 750 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 751 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 752 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 753 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 754 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 755 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 756 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 757 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 758 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 759 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 760 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 761 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 762 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 763 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end

	if curStep == 764 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 765 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 100, 0.05, "bounceOut");
	end
	if curStep == 766 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') + 100, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') + 100, 0.05, "bounceOut");
	end
	if curStep == 767 then
		noteTweenX("x1",0, getPropertyFromGroup('opponentStrums', 0, 'x') - 50, 0.05, "bounceOut");
		noteTweenX("x2",1, getPropertyFromGroup('opponentStrums', 1, 'x') - 50, 0.05, "bounceOut");
		noteTweenX("x3",2, getPropertyFromGroup('opponentStrums', 2, 'x') - 50, 0.05, "bounceOut");
		noteTweenX("x4",3, getPropertyFromGroup('opponentStrums', 3, 'x') - 50, 0.05, "bounceOut");
		noteTweenX("x5",4, getPropertyFromGroup('playerStrums', 0, 'x') - 50, 0.05, "bounceOut");
		noteTweenX("x6",5, getPropertyFromGroup('playerStrums', 1, 'x') - 50, 0.05, "bounceOut");
		noteTweenX("x7",6, getPropertyFromGroup('playerStrums', 2, 'x') - 50, 0.05, "bounceOut");
		noteTweenX("x8",7, getPropertyFromGroup('playerStrums', 3, 'x') - 50, 0.05, "bounceOut");
	end


	



     if curStep == 768 then
		noteTweenY("y1",0, getPropertyFromGroup('opponentStrums', 0, 'y') + 25, 0.05, "bounceOut");
		noteTweenY("y2",1, getPropertyFromGroup('opponentStrums', 1, 'y') + 25, 0.05, "bounceOut");
		noteTweenY("y3",2, getPropertyFromGroup('opponentStrums', 2, 'y') + 25, 0.05, "bounceOut");
		noteTweenY("y4",3, getPropertyFromGroup('opponentStrums', 3, 'y') + 25, 0.05, "bounceOut");
		noteTweenY("y5",4, getPropertyFromGroup('playerStrums', 0, 'y') + 25, 0.05, "bounceOut");
		noteTweenY("y6",5, getPropertyFromGroup('playerStrums', 1, 'y') + 25, 0.05, "bounceOut");
		noteTweenY("y7",6, getPropertyFromGroup('playerStrums', 2, 'y') + 25, 0.05, "bounceOut");
		noteTweenY("y8",7, getPropertyFromGroup('playerStrums', 3, 'y') + 25, 0.05, "bounceOut");
	end
	if curStep == verticalHaatoPair[i] then
		noteTweenY("y1",0, getPropertyFromGroup('opponentStrums', 0, 'y') + 50, 0.05, "bounceOut");
		noteTweenY("y2",1, getPropertyFromGroup('opponentStrums', 1, 'y') + 50, 0.05, "bounceOut");
		noteTweenY("y3",2, getPropertyFromGroup('opponentStrums', 2, 'y') + 50, 0.05, "bounceOut");
		noteTweenY("y4",3, getPropertyFromGroup('opponentStrums', 3, 'y') + 50, 0.05, "bounceOut");
		noteTweenY("y5",4, getPropertyFromGroup('playerStrums', 0, 'y') + 50, 0.05, "bounceOut");
		noteTweenY("y6",5, getPropertyFromGroup('playerStrums', 1, 'y') + 50, 0.05, "bounceOut");
		noteTweenY("y7",6, getPropertyFromGroup('playerStrums', 2, 'y') + 50, 0.05, "bounceOut");
		noteTweenY("y8",7, getPropertyFromGroup('playerStrums', 3, 'y') + 50, 0.05, "bounceOut");
	end
	if curStep == verticalHaatoNotPair[i] then
		noteTweenY("y1",0, getPropertyFromGroup('opponentStrums', 0, 'y') - 50, 0.05, "bounceOut");
		noteTweenY("y2",1, getPropertyFromGroup('opponentStrums', 1, 'y') - 50, 0.05, "bounceOut");
		noteTweenY("y3",2, getPropertyFromGroup('opponentStrums', 2, 'y') - 50, 0.05, "bounceOut");
		noteTweenY("y4",3, getPropertyFromGroup('opponentStrums', 3, 'y') - 50, 0.05, "bounceOut");
		noteTweenY("y5",4, getPropertyFromGroup('playerStrums', 0, 'y') - 50, 0.05, "bounceOut");
		noteTweenY("y6",5, getPropertyFromGroup('playerStrums', 1, 'y') - 50, 0.05, "bounceOut");
		noteTweenY("y7",6, getPropertyFromGroup('playerStrums', 2, 'y') - 50, 0.05, "bounceOut");
		noteTweenY("y8",7, getPropertyFromGroup('playerStrums', 3, 'y') - 50, 0.05, "bounceOut");
	end
	if curStep == 1021 then
		noteTweenY("y1",0, getPropertyFromGroup('opponentStrums', 0, 'y') - 25, 0.05, "bounceOut");
		noteTweenY("y2",1, getPropertyFromGroup('opponentStrums', 1, 'y') - 25, 0.05, "bounceOut");
		noteTweenY("y3",2, getPropertyFromGroup('opponentStrums', 2, 'y') - 25, 0.05, "bounceOut");
		noteTweenY("y4",3, getPropertyFromGroup('opponentStrums', 3, 'y') - 25, 0.05, "bounceOut");
		noteTweenY("y5",4, getPropertyFromGroup('playerStrums', 0, 'y') - 25, 0.05, "bounceOut");
		noteTweenY("y6",5, getPropertyFromGroup('playerStrums', 1, 'y') - 25, 0.05, "bounceOut");
		noteTweenY("y7",6, getPropertyFromGroup('playerStrums', 2, 'y') - 25, 0.05, "bounceOut");
		noteTweenY("y8",7, getPropertyFromGroup('playerStrums', 3, 'y') - 25, 0.05, "bounceOut");
	end

end

--1020
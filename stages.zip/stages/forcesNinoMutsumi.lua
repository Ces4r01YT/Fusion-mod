function onCreate()

	setProperty('skipCountdown', true)
	-- background shit
	makeLuaSprite('greenHill', 'greenHill', -350, 0);
	setScrollFactor('greenHill', 1.0, 1.0);

	makeLuaSprite('mountains2', 'mountains2', -350, -100);
	setScrollFactor('mountains2', 0.5, 0.7);

	makeLuaSprite('mountainsNOwater', 'mountainsNOwater', -350, -100);
	setScrollFactor('mountainsNOwater', 0.8, 1.0);

	makeLuaSprite('filter', 'filter', -500, 0);
	setScrollFactor('filter', 1.0, 1.0);
	setBlendMode('filter', 'add');
	scaleObject('filter', 5.6, 5.6);
	setProperty('filter.alpha', tonumber(0.13))


	makeLuaSprite('sky', 'sky', -350, 0);
	setScrollFactor('sky', 0.4, 1.0);

	makeAnimatedLuaSprite('mountainsWater','mountainsWater',-350, -100)addAnimationByPrefix('mountainsWater','mountainsWater','mountainsWater',24,true)
	objectPlayAnimation('mountainsWater','mountainsWater',false)
	setScrollFactor('mountainsWater', 0.6, 0.8);

	makeLuaSprite('gotoubun', 'quintuplets/gotoubun-5_stage', -400, -400);
	setScrollFactor('gotoubun', 0.9, 0.9);

	addLuaSprite('gotoubun', false);


	addLuaSprite('sky', false);
	addLuaSprite('mountains2', false);
	addLuaSprite('mountainsWater', false);
	addLuaSprite('greenHill', false);
	addLuaSprite('filter', true);

	setProperty('gotoubun.visible', false)

	makeAnimatedLuaSprite('static', 'home/HomeStaticWhite', -350, -200);
	luaSpriteAddAnimationByPrefix('static', 'hello_there', 'HomeStatic' , 24, true)
	addLuaSprite('static', true)

end
function onSongStart()
    setProperty('gf.alpha', 0)
	setProperty('static.alpha', 0)
end

local xx = 550;
local yy = 550;
local xx2 = 750;
local yy2 = 550;
local ofs = 10;
local followchars = true;
local del = 0;
local del2 = 0;


function onUpdate()
	if del > 0 then
		del = del - 1
	end
	if del2 > 0 then
		del2 = del2 - 1
	end
    if followchars == true then
        if mustHitSection == false then
            if getProperty('dad.animation.curAnim.name') == 'singLEFT' then
                triggerEvent('Camera Follow Pos',xx-ofs,yy)
            end
            if getProperty('dad.animation.curAnim.name') == 'singRIGHT' then
                triggerEvent('Camera Follow Pos',xx+ofs,yy)
            end
            if getProperty('dad.animation.curAnim.name') == 'singUP' then
                triggerEvent('Camera Follow Pos',xx,yy-ofs)
            end
            if getProperty('dad.animation.curAnim.name') == 'singDOWN' then
                triggerEvent('Camera Follow Pos',xx,yy+ofs)
            end
            if getProperty('dad.animation.curAnim.name') == 'singLEFT-alt' then
                triggerEvent('Camera Follow Pos',xx-ofs,yy)
            end
            if getProperty('dad.animation.curAnim.name') == 'singRIGHT-alt' then
                triggerEvent('Camera Follow Pos',xx+ofs,yy)
            end
            if getProperty('dad.animation.curAnim.name') == 'singUP-alt' then
                triggerEvent('Camera Follow Pos',xx,yy-ofs)
            end
            if getProperty('dad.animation.curAnim.name') == 'singDOWN-alt' then
                triggerEvent('Camera Follow Pos',xx,yy+ofs)
            end
            if getProperty('dad.animation.curAnim.name') == 'idle-alt' then
                triggerEvent('Camera Follow Pos',xx,yy)
            end
            if getProperty('dad.animation.curAnim.name') == 'idle' then
                triggerEvent('Camera Follow Pos',xx,yy)
            end
        else

            if getProperty('boyfriend.animation.curAnim.name') == 'singLEFT' then
                triggerEvent('Camera Follow Pos',xx2-ofs,yy2)
            end
            if getProperty('boyfriend.animation.curAnim.name') == 'singRIGHT' then
                triggerEvent('Camera Follow Pos',xx2+ofs,yy2)
            end
            if getProperty('boyfriend.animation.curAnim.name') == 'singUP' then
                triggerEvent('Camera Follow Pos',xx2,yy2-ofs)
            end
            if getProperty('boyfriend.animation.curAnim.name') == 'singDOWN' then
                triggerEvent('Camera Follow Pos',xx2,yy2+ofs)
            end
	    if getProperty('boyfriend.animation.curAnim.name') == 'idle' then
                triggerEvent('Camera Follow Pos',xx2,yy2)
            end
        end
    else
        triggerEvent('Camera Follow Pos','','')
    end
    
end

function opponentNoteHit()
    health = getProperty('health')
    if getProperty('health') > 0.05 then
        setProperty('health', health- 0.02);
    end
end

--[[
	hello kirbitus
	
	this is actually daHud script i made for waldo but only included the smooth camera
	
	SCRIPT FROM AND BY RALTYRO
--]]

--[[ Default Settings
	shiftCameraOnNote = true
	shiftCameraPixels = 52
	smoothCamera = true
	smoothZoom = true
	smoothIntensity = .475
--]]
local settings = {
	shiftCameraOnNote = true,
	shiftCameraPixels = 52,
	smoothCamera = true,
	smoothZoom = true,
	smoothIntensity = .475, -- too much smooth or below 0 = camera wont move lmao
}

-----------------------------------------------------------------------
-- NO TOUCHIES >:(
-----------------------------------------------------------------------







--[[ EASING ]]--

-- formulas from http://www.robertpenner.com/easing
easing = {
	-- linear
	linear = function(t,b,c,d)
		return c * t / d + b
	end,
	
	-- quad
	inQuad = function(t, b, c, d)
		return c * math.pow(t / d, 2) + b
	end,
	outQuad = function(t, b, c, d)
		t = t / d
		return -c * t * (t - 2) + b
	end,
	inOutQuad = function(t, b, c, d)
		t = t / d * 2
		if t < 1 then return c / 2 * math.pow(t, 2) + b end
		return -c / 2 * ((t - 1) * (t - 3) - 1) + b
	end,
	outInQuad = function(t, b, c, d)
		if t < d / 2 then return outQuad(t * 2, b, c / 2, d) end
		return inQuad((t * 2) - d, b + c / 2, c / 2, d)
	end,
	
	-- cubic
	inCubic = function(t, b, c, d)
		return c * math.pow(t / d, 3) + b
	end,
	outCubic = function(t, b, c, d)
		return c * (math.pow(t / d - 1, 3) + 1) + b
	end,
	inOutCubic = function(t, b, c, d)
		t = t / d * 2
		if t < 1 then return c / 2 * t * t * t + b end
		t = t - 2
		return c / 2 * (t * t * t + 2) + b
	end,
	outInCubic = function(t, b, c, d)
		if t < d / 2 then return outCubic(t * 2, b, c / 2, d) end
		return inCubic((t * 2) - d, b + c / 2, c / 2, d)
	end,
	
	-- quint
	inQuint = function(t, b, c, d)
		return c * math.pow(t / d, 5) + b
	end,
	outQuint = function(t, b, c, d)
		return c * (math.pow(t / d - 1, 5) + 1) + b
	end,
	inOutQuint = function(t, b, c, d)
		t = t / d * 2
		if t < 1 then return c / 2 * math.pow(t, 5) + b end
		return c / 2 * (math.pow(t - 2, 5) + 2) + b
	end,
	outInQuint = function(t, b, c, d)
		if t < d / 2 then return outQuint(t * 2, b, c / 2, d) end
		return inQuint((t * 2) - d, b + c / 2, c / 2, d)
	end,
	
	-- elastics
	outElastic = function(t, b, c, d, a, p)
		a = a or 3
		p = p or 1
		if t == 0 then return b end
		t = t / d
		if t == 1 then return b + c end
		if not p then p = d * 0.3 end
		local s
		if not a or a < math.abs(c) then
			a = c
			s = p / 4
		else
			s = p / (2 * math.pi) * math.asin(c/a)
		end
		return a * math.pow(2, -10 * t) * math.sin((t * d - s) * (2 * math.pi) / p) + c + b
	end
}

--[[ TWEENNUMBER ]]--
local time = 0
local os = os
function os.clock()
	return time
end

tweenReqs = {}

function tnTick()
	local clock = os.clock()
	--print(songPos, #tweenReqs)
	if #tweenReqs > 0 then
		for i,v in next,tweenReqs do
			if clock>v[5]+v[6] then
				v[1][v[2]] =  v[7](v[6],v[3],v[4]-v[3],v[6])
				table.remove(tweenReqs,i)
				if v[9] then
					v[9]()
				end
			else
				v[1][v[2]] = v[7](clock-v[5],v[3],v[4]-v[3],v[6])
				--if (v[8]) then
				--	v[8] = false
				--	v[1][v[2]] = v[7](0,v[3],v[4]-v[3],v[6])
				--end
			end
		end
	end
end

function tweenNumber(maps, varName, startVar, endVar, time, startTime, easeF, onComplete)
	local clock = os.clock()
	maps = maps or getfenv()
	
	if #tweenReqs > 0 then
		for i2,v2 in next,tweenReqs do
			if v2[2] == varName and v2[1] == maps then
				v2[1][v2[2]] =  v2[7](v2[6],v2[3],v2[4]-v2[3],v2[6])
				table.remove(tweenReqs,i2)
				if v2[9] then
					v2[9]()
				end
				break
			end
		end
	end
	
	--print("Created TweenNumber: "..tostring(varName), startVar, endVar, time, startTime, type(onComplete) == "function")
	local t = {
		maps,
		varName,
		startVar,
		endVar,
		startTime or clock,
		time,
		easeF or easing.linear,
		true,
		onComplete
	}
	
	table.insert(tweenReqs,t)
	t[1][t[2]] = t[7](0,t[3],t[4]-t[3],t[6])
	
	return function()
		maps[varName] = t[7](v[6],t[3],t[4]-t[3],t[6])
		table.remove(tweenReqs,table.find(tweenReqs,t))
		if onComplete then
			onComplete()
		end
		return nil
	end
end

function math.clamp(x,min,max)return math.max(min,math.min(x,max))end
function math.lerp(from,to,i)return from+(to-from)*i end

local function getCamString(cam)
	return type(cam) ~= "string" and "default" or (
		cam:lower():find("hud") and "camHUD" or
		cam:lower():find("other") and "camOther" or
		"default"
	)
end

local function getCamProperty(cam, p)
	if (p == nil) then p = cam; cam = nil end
	local str = getCamString(cam)
	
	if (str == "default") then
		return p == "scroll.x" and getProperty("camFollowPos.x") or p == "scroll.y" and getProperty("camFollowPos.y") or
			getPropertyFromClass("flixel.FlxG", "camera." .. p)
	end
	
	return getProperty(str .. "." .. p)
end

local function setCamProperty(cam, p, v)
	if (v == nil) then v = p; p = cam; cam = nil end
	local str = getCamString(cam)
	
	if (str == "default") then
		return p == "scroll.x" and setProperty("camFollowPos.x", v) or p == "scroll.y" and setProperty("camFollowPos.y", v) or
			setPropertyFromClass("flixel.FlxG", "camera." .. p, v)
	end
	
	return getProperty(str .. "." .. p, v)
end

local realCamScX = 0
local realCamScY = 0
local realCamAngle = 0
local realCamZoom = 1

local camScX = 0
local camScY = 0
local camAngle = 0
local camZoom = 1

function onCreatePost()
	realCamScX = getCamProperty("scroll.x")
	realCamScY = getCamProperty("scroll.y")
	realCamAngle = getCamProperty("angle")
	realCamZoom = getCamProperty("zoom")
	
	camScX = realCamScX
	camScY = realCamScY
	camAngle = realCamAngle
	camZoom = realCamZoom
	
	addLuaScript("zCameraFix")
end

local bfShift = {x = 0, y = 0}
local dadShift = {x = 0, y = 0}

function shiftCamNote(t, dir)
	if (settings.shiftCameraOnNote) then
		local x = dir == 0 and -1 or (dir == 3 and 1) or 0
		local y = dir == 1 and 1 or (dir == 2 and -1) or 0
		tweenNumber(t, "x", x, 0, (stepCrochet / 1000) * 3.14, nil, easing.outCubic)
		tweenNumber(t, "y", y, 0, (stepCrochet / 1000) * 3.14, nil, easing.outCubic)
	end
end

function opponentNoteHit(id, dir)
	shiftCamNote(dadShift, dir)
end

function goodNoteHit(id, dir, typ, sus)
	shiftCamNote(bfShift, dir)
end

function noteMiss(id, dir)
	shiftCamNote(bfShift, dir)
end

function noteMissPress(key)
	shiftCamNote(bfShift, key)
end

local isDead = false
function onGameOverStart()
	isDead = true
end

function onStepHit()
	if (isDead or getProperty("isDead")) then return end
	if (math.fmod(curStep, 16) ~= 0) then return end
	
	if (getProperty("camZooming") and getCamProperty("zoom") < 1.35 and getPropertyFromClass("ClientPrefs", "camZooms")) then
		camZoom = camZoom + .015
	end
end

local prevFollowXAdd = 0
local prevFollowYAdd = 0
function onUpdate(dt)
	time = time + dt
	
	if (settings.smoothCamera) then
		setCamProperty("scroll.x", getCamProperty("scroll.x") - (camScX - realCamScX))
		setCamProperty("scroll.y", getCamProperty("scroll.y") - (camScY - realCamScY))
		setCamProperty("angle", getCamProperty("angle") - (camAngle - realCamAngle))
		setCamProperty("zoom", getCamProperty("zoom") - (camZoom - realCamZoom))
	end
	
	if (isDead or getProperty("isDead")) then return end
	
	local pix = settings.shiftCameraPixels
	local pix2 = settings.shiftCameraPixels * .3
	
	local followXAdd = (bfShift.x * (mustHitSection and pix or pix2)) + (dadShift.x * (mustHitSection and pix2 or pix))
	local followYAdd = (bfShift.y * (mustHitSection and pix or pix2)) + (dadShift.y * (mustHitSection and pix2 or pix))
	
	setProperty("camFollow.x", getProperty("camFollow.x") - prevFollowXAdd)
	setProperty("camFollow.y", getProperty("camFollow.y") - prevFollowYAdd)
	if (settings.shiftCameraOnNote) then
		setProperty("camFollow.x", getProperty("camFollow.x") + followXAdd)
		setProperty("camFollow.y", getProperty("camFollow.y") + followYAdd)
		prevFollowXAdd = followXAdd
		prevFollowYAdd = followYAdd
	else
		prevFollowXAdd = 0
		prevFollowYAdd = 0
	end
end

function onMoveCamera()
	prevFollowXAdd = 0
	prevFollowYAdd = 0
end

--local camStrength = 0
function onUpdatePost(dt)
	local isDead = isDead or getProperty("isDead")
	
	realCamScX = getCamProperty("scroll.x")
	realCamScY = getCamProperty("scroll.y")
	realCamAngle = getCamProperty("angle")
	realCamZoom = getCamProperty("zoom")
	
	local camSpeed = isDead and 1 or getProperty("cameraSpeed")
	
	if (settings.smoothCamera) then
		--[[local x = camScX - realCamScX
		local y = camScY - realCamScY
		local distance = math.sqrt((x * x) + (y * y))
		print(distance)
		
		camStrength = math.clamp(math.lerp(camStrength, 0, 0), 0, 2.4)]]
		
		local smooth = ((1 / settings.smoothIntensity) + 1)
		
		local l = math.clamp(dt * 2.4 * smooth * camSpeed, 0, 1)
		
		camScX = math.lerp(camScX, realCamScX, l)
		camScY = math.lerp(camScY, realCamScY, l)
		camAngle = realCamAngle--math.lerp(camAngle, realCamAngle, math.clamp(dt * 2.4 * smooth, 0, 1))
		camZoom = settings.smoothZoom and math.lerp(camZoom, realCamZoom, math.clamp(dt * 3.125 * smooth, 0, 1)) or realCamZoom
		
		setCamProperty("scroll.x", camScX)
		setCamProperty("scroll.y", camScY)
		setCamProperty("angle", camAngle)
		setCamProperty("zoom", camZoom)
	end
	
	tnTick()
end


function onBeatHit()
	if curBeat == 124 then
	    doTweenAlpha('staticFadeEventTween', 'static', 1, 0.5, 'linear');
	end
    if curBeat == 125 then
		setProperty('gotoubun.visible', true);
		setProperty('greenHill.visible', false);
		setProperty('mountains2.visible', false);
		setProperty('mountainsNOwater.visible', false);
		setProperty('filter.visible', false);
		setProperty('sky.visible', false);
		setProperty('mountainsWater.visible', false);
	end
	if curBeat == 128 then
	    doTweenAlpha('staticFadeEventTween', 'static', 0, 0.5, 'linear');
	end

	if (curBeat % gfSpeed == 0) then
		if curBeat % (gfSpeed * 2) == 0 then
			setProperty('iconP1.scale.x', 0.8 );
			setProperty('iconP1.scale.y', 0.8 );
			setProperty('iconP2.scale.x', 1.2 );
			setProperty('iconP2.scale.y', 1.3 );

			setProperty('iconP1.angle', -15);
			setProperty('iconP2.angle', 15);
		else
			setProperty('iconP1.scale.x', 1.2 );
			setProperty('iconP1.scale.y', 1.3 );
			setProperty('iconP2.scale.x', 0.8 );
			setProperty('iconP2.scale.y', 0.8 );

			setProperty('iconP2.angle', -15);
			setProperty('iconP1.angle', 15);
		end

	end
end

local healthBarIsFlip = true
local stickThere = false
function onUpdate(elapsed)
	if healthBarIsFlip == true then -- if you want to flip the health bar or not (set to true to flip, set false will turn back to normal)
		setProperty('healthBar.flipX', true)

		if getProperty('health') < 2 then
			stickThere = false
		end

		if getProperty('health') >= 2 then
			stickThere = true
		end
	else
		setProperty('healthBar.flipX', false)
	end
end

function onUpdatePost()
	if healthBarIsFlip == true then
		setProperty('iconP1.flipX', true)
		setProperty('iconP2.flipX', true)

		if stickThere == false then
			if getProperty('health') > 0 then
				setProperty('iconP1.x', 216+getProperty('health')*296+getProperty('healthBar.x')-343.5)
				setProperty('iconP2.x', 317+getProperty('health')*297+getProperty('healthBar.x')-343.5)
			end

			if getProperty('health') <= 0 then
				setProperty('iconP1.x', 216+getProperty('healthBar.x')-343.5)
				setProperty('iconP2.x', 317+getProperty('healthBar.x')-343.5)
			end
		end

		if stickThere == true then
		   setProperty('iconP1.x', 808+getProperty('healthBar.x')-343.5)
		   setProperty('iconP2.x', 911+getProperty('healthBar.x')-343.5)
		end

		--setProperty('iconP1.y', getProperty('healthBar.y') -75) -- icons stick to health bar (y position), I added if you guys want
		--setProperty('iconP2.y', getProperty('healthBar.y') -75)
	else
		setProperty('iconP1.flipX', false)
		setProperty('iconP2.flipX', false)
	end
end
function onCreatePost()
        setPropertyFromGroup('playerStrums', 0, 'x', defaultPlayerStrumX0 - 635);
        setPropertyFromGroup('playerStrums', 1, 'x', defaultPlayerStrumX1 - 635);
        setPropertyFromGroup('playerStrums', 2, 'x', defaultPlayerStrumX2 - 635);
        setPropertyFromGroup('playerStrums', 3, 'x', defaultPlayerStrumX3 - 635);

		setPropertyFromGroup('opponentStrums', 0, 'x', defaultOpponentStrumX0 - -635);
        setPropertyFromGroup('opponentStrums', 1, 'x', defaultOpponentStrumX1 - -635);
        setPropertyFromGroup('opponentStrums', 2, 'x', defaultOpponentStrumX2 - -635);
        setPropertyFromGroup('opponentStrums', 3, 'x', defaultOpponentStrumX3 - -635);
end


function onCreate()
	-- background shit
	makeLuaSprite('stageback', 'Week1 B3/Stadium', -700, -300);
	setLuaSpriteScrollFactor('stageback', 0.9, 0.9);
	

	-- sprites that only load if Low Quality is turned off
	if not lowQuality then
  makeAnimatedLuaSprite('b', 'Week1 B3/dcameos',-700, -600);
     setLuaSpriteScrollFactor('b',0.9, 0.9);
	
	
	end

	addLuaSprite('stageback', false);
	addLuaSprite('b', false);
    addAnimationByPrefix('b','idle','bop',24,true); 
    runTimer('train2',1)
	
end

function onCreate()
	-- background shit
	makeLuaSprite('limoSunset2', 'limoholo/limoSunset', -120, -50);
	setLuaSpriteScrollFactor('limoSunset2', 0.1, 0.1);

    makeLuaSprite('limoNight2', 'limoholo/limoNight', -120, -50);
	setLuaSpriteScrollFactor('limoNight2', 0.1, 0.1);

	makeAnimatedLuaSprite('limoDrive2', 'limoholo/limoDrive',-120, 550);
    setLuaSpriteScrollFactor('limoDrive2', 1, 1);
	makeAnimatedLuaSprite('bgLimo2','limoholo/bgLimo', -150, 480);
	setLuaSpriteScrollFactor('bgLimo2', 0.4, 0.4);
	

	makeAnimatedLuaSprite('chainIcon', 'chainsaw/icons/icon-chain', 635, 570)

	addAnimationByPrefix('chainIcon', 'neutral', 'chain norm', 1, true)
    addAnimationByPrefix('chainIcon', 'lose', 'chain lose', 1, true)
    setObjectCamera('chainIcon', 'camHud')
    objectPlayAnimation('chainIcon', 'neutral', true)
	setProperty("chainIcon.alpha", 0)

	makeAnimatedLuaSprite('denjimorbs','chainsaw/DENJI PULL', 550, 1520)
    addAnimationByPrefix('denjimorbs','letitrip','DENJI PULL', 24, false)

	-- sprites that only load if Low Quality is turned off
	if not lowQuality then
	makeAnimatedLuaSprite('limoDancer2', 'limoholo/limoDancer',550, 100);
    setLuaSpriteScrollFactor('limoDancer2', 0.4, 0.4);

	makeAnimatedLuaSprite('limoDancer3', 'limoholo/limoDancer',250, 100);
    setLuaSpriteScrollFactor('limoDancer3', 0.4, 0.4);
	
	makeAnimatedLuaSprite('limoDancer4', 'limoholo/limoDancer',850, 100);
    setLuaSpriteScrollFactor('limoDancer4', 0.4, 0.4);
	
	makeAnimatedLuaSprite('limoDancer5', 'limoholo/limoDancer',1150, 100);
    setLuaSpriteScrollFactor('limoDancer5', 0.4, 0.4);
	end
	

	--NGAHHHH!
	makeLuaSprite('redbg', nil, 120, -100)
	makeGraphic('redbg', 1600, 900, 'D20000')
	makeAnimatedLuaSprite('sawMAN','chainsaw/ROAR', 110, -200)
    addAnimationByPrefix('sawMAN','rawr','DENJI ROAR', 24, false)
	scaleObject('sawMAN', 0.7, 0.7)
	addLuaSprite('redbg', true)
	addLuaSprite('sawMAN', true)
	
    
	addLuaSprite('limoSunset2', false);
	addLuaSprite('limoNight2', false);
	addLuaSprite('bgLimo2', false);
	addAnimationByPrefix('bgLimo2', 'idle', 'background limo pink', 20, true); 
	addLuaSprite('limoDancer2', false);
	addAnimationByPrefix('limoDancer2', 'idle', 'bg dancer sketch PINK', 24, true); 
	addLuaSprite('limoDancer3', false);
	addAnimationByPrefix('limoDancer3', 'idle', 'bg dancer sketch PINK', 24, true);
	addLuaSprite('limoDancer4', false);
	addAnimationByPrefix('limoDancer4', 'idle', 'bg dancer sketch PINK', 24, true);
	addLuaSprite('limoDancer5', false);
	addAnimationByPrefix('limoDancer5', 'idle', 'bg dancer sketch PINK', 24, true);

	addLuaSprite('limoDrive2', false);
	addAnimationByPrefix('limoDrive2', 'idle', 'Limo stage', 24, true); 

	addLuaSprite('denjimorbs', true)

    setProperty('limoNight2.alpha', 0)
	setProperty('redbg.alpha', 0)
	setProperty('sawMAN.alpha', 0)

end

function onBeatHit()
	if curBeat == 396 then
	    objectPlayAnimation('denjimorbs', 'letitrip', false)
	    doTweenY('objectTweenY', 'denjimorbs', 0, 0.7, 'cubeOut');
		cameraFlash('camHUD', 'FFFFFF', 0.5, false)
	end
	if curBeat == 398 then
		doTweenX('dadTweenX', 'gf', 1030, 1, 'cirOut');
		doTweenX('boyfriendTweenX', 'boyfriend', 1375, 1, 'cirIn');
		doTweenAlpha('morbFadeEventTween', 'denjimorbs', 0, 1, 'linear');
	end
	if curBeat == 402 then
		setProperty('limoNight2.alpha', 1)
		setProperty('limoSunset2.alpha', 0)
		setProperty('chainIcon.alpha', 1)
		cameraFlash('camHUD', 'FFFFFF', 0.2, false)
	removeLuaSprite('redbg', true)
	removeLuaSprite('sawMAN', true)
	end
end

function onCreatePost()
	addLuaSprite('chainIcon', true)
end

function onUpdate(elapsed)

	--bigger icons lol
	setProperty('chainIcon.x', getProperty('iconP2.x'))
	setProperty('chainIcon.flipX', true)
	
	setProperty('chainIcon.scale.x', getProperty('iconP2.scale.x'))
	setProperty('chainIcon.scale.y', getProperty('iconP2.scale.y'))
	if getProperty('health') >= 1.75 then
		objectPlayAnimation('chainIcon', 'lose', true)
	elseif getProperty('health') <= 0.3 then
		objectPlayAnimation('chainIcon', 'neutral', true)
	elseif getProperty('health') < 1.75 and getProperty('health') > 0.3 then
		objectPlayAnimation('chainIcon', 'neutral', true)
	end
end

function onEvent(name, value1, value2)
if name == 'ROAR' then --sword devil appears
	cameraFlash('camHUD', 'FFFFFF', 0.2, false)
	doTweenAlpha('dadFadeEventTween', 'sawMAN', 1, 1, 'linear');
	doTweenAlpha('bgFadeEventTween', 'redbg', 1, 1, 'linear');
	objectPlayAnimation('sawMAN', 'rawr', false)
end
end
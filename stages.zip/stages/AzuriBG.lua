function onCreate()
	makeLuaSprite('bg', 'streaming/BG_Azuri', 200, 10)
	scaleObject(2, 2)
	addLuaSprite('bg', false)
end
﻿function onCreate()

	makeLuaSprite('salon', 'quintuplets/HallLightoff', -150, 160); 
	setLuaSpriteScrollFactor('salon', 0.9, 0.9);
	scaleObject('salon', 0.75, 0.6);
	
	addLuaSprite('salon', false);

	makeLuaSprite('baka', nil, 120, 200)
	makeGraphic('baka', 1600, 900, 'FF817C')
	addLuaSprite('baka', true)

	makeLuaSprite('bakaText', 'quintuplets/Baka!!', 0, 0);
	addLuaSprite('bakaText')
	screenCenter('bakaText', 'xy')
	setObjectCamera('bakaText', 'other')
	scaleObject('bakaText', 1.2, 1.2);

	setProperty('bakaText.alpha', 0)
	setProperty('baka.alpha', 0)
end

function onBeatHit()
	if curBeat == 416 then
    doTweenAlpha('FadeInObject', 'bakaText', 1, 0.25, 'cubeOut')
	doTweenY('BounceObject', 'bakaText', 100, 0.50, 'bounceInOut')
	end
	if curBeat == 417 then
	doTweenAngle('angleObject', 'bakaText', 45, 0.45, 'circIn')
	doTweenAlpha('FadeOutObject', 'bakaText', 0, 0.25, 'cubeIn')
	end
	if curBeat == 418 then
		doTweenAlpha('FadeOutRed', 'baka', 0, 0.1, 'linear')
	end
end
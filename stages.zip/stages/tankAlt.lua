function onCreate()
	-- background shit
	makeLuaSprite('tankSky', 'week7/tankSky', -400,-400);
	setLuaSpriteScrollFactor('tankSky', 0, 0);
	scaleObject('tankGround', 15, 1.5)
	makeLuaSprite('tankClouds', 'week7/tankClouds', -700, -100);
	setLuaSpriteScrollFactor('tankClouds', 0.1, 0.1);

	makeLuaSprite('tankGround', 'week7/tankGround', -420,-150);
	setLuaSpriteScrollFactor('tankMountains', 1, 1);
	scaleObject('tankGround', 1.15, 1.15);

	-- sprites that only load if Low Quality is turned off
	if not lowQuality then
		makeLuaSprite('tankMountains', 'week7/tankMountains', -300,-20);
		setLuaSpriteScrollFactor('tankMountains', 0.2, 0.2);
		scaleObject('tankMountains', 1.2, 1.2);
		
		makeAnimatedLuaSprite('tankWatchtower', 'week7/tankWatchtower', 100,30);
		
		
		makeAnimatedLuaSprite('smokeRight', 'week7/smokeRight', 1100,-100);
		setLuaSpriteScrollFactor('smokeRight', 0.4, 0.4);
		
		makeAnimatedLuaSprite('smokeLeft', 'week7/smokeLeft', -200,-100);
		setLuaSpriteScrollFactor('smokeLeft', 0.4, 0.4);
	
		
		
	end

	addLuaSprite('tankSky', false);
	addLuaSprite('tankClouds', false);
	addLuaSprite('tankMountains', false);
	addLuaSprite('smokeRight', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('smokeRight', 'idle', 'SmokeRight', 24, true);
	addLuaSprite('smokeLeft', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('smokeLeft', 'idle', 'SmokeBlurLeft', 24, true);
	addLuaSprite('tankRolling', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('tankRolling', 'idle', 'BG tank w lighting', 24, true);
	addLuaSprite('tankWatchtower', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('tankWatchtower', 'idle', 'watchtower gradient color instance 1', 24, true);
	
	addLuaSprite('tankGround', false);
	addLuaSprite('tank0', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('tank0','idle', 'fg tankhead far right instance 100', 24, true);
	addLuaSprite('tank1', true); --Added offscreen before it starts moving.
	addAnimationByPrefix('tank1','idle', 'fg tankhead 5 ', 24, true);
	addLuaSprite('tank2', true); --Added offscreen before it starts moving.
	addAnimationByPrefix('tank2','idle', 'foreground man 3 ', 24, true);
	addLuaSprite('tank3', true); --Added offscreen before it starts moving.
	addAnimationByPrefix('tank3','idle', 'fg tankhead 4 ', 24, true);
	addLuaSprite('tank4', true); --Added offscreen before it starts moving.
	addAnimationByPrefix('tank4','idle', 'fg tankman bobbin 3 ', 24, true);
	addLuaSprite('tank5', true); --Added offscreen before it starts moving.
	addAnimationByPrefix('tank5','idle', 'fg tankhead far right ', 24, true);
	
	close(true); --For performance reasons, close this script once the stage is fully loaded, as this script won't be used anymore after loading the stage
end
function onEvent(name,value1,value2)
	if name == 'Play Animation' then 
		
		if value1 == 'changebg1' then
			setProperty('stage.visible', false);
			setProperty('stage2.visible', true);
			setProperty('stage3.visible', false);
			setProperty('stage4.visible', false
		end
		if value1 == 'changebg2' then
			setProperty('stage3.visible', true);
			setProperty('stage.visible', false);
			setProperty('stage2.visible', false);
			setProperty('stage4.visible', false);
		end
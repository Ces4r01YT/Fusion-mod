function onCreate()
    makeLuaSprite('call','streaming/DiscordCall2',-300,-200)
    addLuaSprite('call',true)
end
function onCreate()
	-- background shit
	makeLuaSprite('stageback', 'CJ/bgnight', -550, -160);
	setLuaSpriteScrollFactor('stageback', 0.5, 0.5);
	
	makeLuaSprite('bgrgb', 'CJ/bgrgb', -550, -160);
	setLuaSpriteScrollFactor('bgrgb', 0.5, 0.5);
	
	makeLuaSprite('stage', 'CJ/stage', -510, -260);

    makeLuaSprite('stagergb', 'CJ/stagergb', -510, -260);
	
	makeAnimatedLuaSprite('stagefront', 'CJ/lights', -510, -260);
  
    makeAnimatedLuaSprite('stagefront2', 'CJ/lights', -510, -260);
	-- sprites that only load if Low Quality is turned off
	if not lowQuality then
	makeAnimatedLuaSprite('Max', 'CJ/Max',1150, 245); 

		makeAnimatedLuaSprite('Maxrgb', 'CJ/Max',1150, 245); 
	
	makeAnimatedLuaSprite('Abel', 'CJ/Abel',-220, 205); 
	makeAnimatedLuaSprite('Abelrgb', 'CJ/Abel',-220, 205); 
	makeAnimatedLuaSprite('frontboppers', 'CJ/frontboppers',-510, 950);
    makeAnimatedLuaSprite('RGBfrontboppers', 'CJ/RGBfrontboppers',-510, 950);
    makeAnimatedLuaSprite('headlights', 'CJ/headlights',-510, -80);
	 makeAnimatedLuaSprite('headlightsRGB', 'CJ/headlightsRGB',-510, -80);
     makeAnimatedLuaSprite('Olley', 'CJ/Olley',1470, 370);
	 makeAnimatedLuaSprite('Olleyrgb', 'CJ/Olley',1470, 370);
	end
	


	addLuaSprite('stageback', false);
	addLuaSprite('stagefront', false);
	addAnimationByPrefix('stagefront', 'idle', 'lights idle', 1, true);
	addLuaSprite('stage', false);

	addLuaSprite('Max', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('Max', 'idle', 'MAX', 24, true);
    addLuaSprite('Abel', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('Abel', 'idle', 'ABEL', 24, true);
	  addLuaSprite('frontboppers', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('frontboppers', 'idle', 'frontboppers', 24, true);
	  addLuaSprite('headlights', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('headlights', 'idle', 'lightsrepeated', 15, true);
	  addLuaSprite('Olley', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('Olley', 'idle', 'OLLEY', 24, true);
	
	
	addLuaSprite('bgrgb', false);
	addLuaSprite('stagefront2', false);
	addAnimationByPrefix('stagefront2', 'idle', 'lights idle', 1, true);
	addLuaSprite('stagergb', false);

	addLuaSprite('Maxrgb', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('Maxrgb', 'idle', 'altMAX', 24, true);
    addLuaSprite('Abelrgb', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('Abelrgb', 'idle', 'altABEL', 24, true);
	  addLuaSprite('RGBfrontboppers', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('RGBfrontboppers', 'idle', 'frontboppers', 24, true);
	  addLuaSprite('headlightsRGB', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('headlightsRGB', 'idle', 'lightsrepeated', 30, true);
	  addLuaSprite('Olleyrgb', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('Olleyrgb', 'idle', 'altOLLEY', 24, true);
	setProperty('bgrgb.visible', false);
	setProperty('stagefront2.visible', false);
	setProperty('stagergb.visible', false);
	setProperty('Maxrgb.visible', false);
	setProperty('Abelrgb.visible', false);
	setProperty('RGBfrontboppers.visible', false);
	setProperty('headlightsRGB.visible', false);
	setProperty('Olleyrgb.visible', false);
	
end
function onEvent(name,value1,value2)
	if name == 'Play Animation' then 
		
		if value1 == '2' then
	setProperty('bgrgb.visible', true);
	setProperty('stagefront2.visible', true);
	setProperty('stagergb.visible', true);
	setProperty('Maxrgb.visible', true);
	setProperty('Abelrgb.visible', true);
	setProperty('RGBfrontboppers.visible', true);
	setProperty('headlightsRGB.visible', true);
	setProperty('Olleyrgb.visible', true);
	
		setProperty('stageback.visible', false);
	setProperty('stagefront.visible', false);
	setProperty('stage.visible', false);
	setProperty('Max.visible', false);
	setProperty('Abel.visible', false);
	setProperty('frontboppers.visible', false);
	setProperty('headlights.visible', false);
	setProperty('Olley.visible', false);
		end

		if value1 == '1' then
    setProperty('bgrgb.visible', false);
	setProperty('stagefront2.visible', false);
	setProperty('stagergb.visible', false);
	setProperty('Maxrgb.visible', false);
	setProperty('Abelrgb.visible', false);
	setProperty('RGBfrontboppers.visible', false);
	setProperty('headlightsRGB.visible', false);
	setProperty('Olleyrgb.visible', false);
	
	setProperty('stageback.visible', true);
	setProperty('stagefront.visible', true);
	setProperty('stage.visible', true);
	setProperty('Max.visible', true);
	setProperty('Abel.visible', true);
	setProperty('frontboppers.visible', true);
	setProperty('headlights.visible', true);
	setProperty('Olley.visible', true);
		end
	end
end

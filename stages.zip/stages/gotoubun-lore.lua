﻿function onCreate()
	-- background shit
	makeLuaSprite('gotoubun-5_stage-night', 'quintuplets/gotoubun-5_stage_night', -400, -400);
	setScrollFactor('gotoubun-5_stage-night', 0.9, 0.9);

	addLuaSprite('gotoubun-5_stage-night', false);

	makeLuaSprite('gotoubun-5_stage-sunset', 'quintuplets/gotoubun-5_stage_sunset', -400, -400);
	setScrollFactor('gotoubun-5_stage-sunset', 0.9, 0.9);

	addLuaSprite('gotoubun-5_stage-sunset', false);

	makeLuaSprite('gotoubun-5_stage', 'quintuplets/gotoubun-5_stage', -400, -400);
	setScrollFactor('gotoubun-5_stage', 0.9, 0.9);

	addLuaSprite('gotoubun-5_stage', false);

	makeLuaSprite('calling', 'quintuplets/MikuPhone-NinoCalling', 400, 890);

	addLuaSprite('calling', true);

	makeAnimatedLuaSprite('phone','quintuplets/MikuPhoneTable',400, 590)
	addAnimationByPrefix('phone','idle','Phone',24,true)
	addAnimationByPrefix('phone','callingU','Call',24,true)
	objectPlayAnimation('phone','idle',false)
	scaleObject('phone', 0.5, 0.5)

	addLuaSprite('phone', false);

	makeLuaSprite('bub', 'Bubble', 450, 140);
	scaleObject('bub', 0.3, 0.3)

	precacheImage('The')
	precacheImage('Quintessential')
	precacheImage('Quintuplets1')
	precacheImage('Go-logo')
end

local healthBarIsFlip = true
local stickThere = false
function onUpdate(elapsed)
	if healthBarIsFlip == true then -- if you want to flip the health bar or not (set to true to flip, set false will turn back to normal)
		setProperty('healthBar.flipX', true)

		if getProperty('health') < 2 then
			stickThere = false
		end

		if getProperty('health') >= 2 then
			stickThere = true
		end
	else
		setProperty('healthBar.flipX', false)
	end
end

function onUpdatePost()
	if healthBarIsFlip == true then
		setProperty('iconP1.flipX', true)
		setProperty('iconP2.flipX', true)
		setProperty('winningIconBf.flipX', false)
		setProperty('winningIconDad.flipX', true)

		if stickThere == false then
			if getProperty('health') > 0 then
				setProperty('iconP1.x', 216+getProperty('health')*296+getProperty('healthBar.x')-343.5)
				setProperty('iconP2.x', 317+getProperty('health')*297+getProperty('healthBar.x')-343.5)
			end

			if getProperty('health') <= 0 then
				setProperty('iconP1.x', 216+getProperty('healthBar.x')-343.5)
				setProperty('iconP2.x', 317+getProperty('healthBar.x')-343.5)
			end
		end

		if stickThere == true then
		   setProperty('iconP1.x', 808+getProperty('healthBar.x')-343.5)
		   setProperty('iconP2.x', 911+getProperty('healthBar.x')-343.5)
		end

		--setProperty('iconP1.y', getProperty('healthBar.y') -75) -- icons stick to health bar (y position), I added if you guys want
		--setProperty('iconP2.y', getProperty('healthBar.y') -75)
	else
		setProperty('iconP1.flipX', false)
		setProperty('iconP2.flipX', false)
	end
end

function onCreatePost()
	addCharacterToList('nino-bubble', 'gf')
	if not middleScroll then
        setPropertyFromGroup('playerStrums', 0, 'x', defaultPlayerStrumX0 - 635);
        setPropertyFromGroup('playerStrums', 1, 'x', defaultPlayerStrumX1 - 635);
        setPropertyFromGroup('playerStrums', 2, 'x', defaultPlayerStrumX2 - 635);
        setPropertyFromGroup('playerStrums', 3, 'x', defaultPlayerStrumX3 - 635);

		setPropertyFromGroup('opponentStrums', 0, 'x', defaultOpponentStrumX0 - -635);
        setPropertyFromGroup('opponentStrums', 1, 'x', defaultOpponentStrumX1 - -635);
        setPropertyFromGroup('opponentStrums', 2, 'x', defaultOpponentStrumX2 - -635);
        setPropertyFromGroup('opponentStrums', 3, 'x', defaultOpponentStrumX3 - -635);
	end
end

function onBeatHit()
	if curBeat == 1 then
		doTweenAlpha('tweenAlphaDay', 'gotoubun-5_stage',0 ,155.5, 'cubeOut')
	end
	if curBeat == 29 then
		makeLuaSprite('Three', 'The', 0, 0)
		addLuaSprite('Three')
		screenCenter('Three', 'xy')
		setObjectCamera('Three', 'other')
		doTweenAlpha('tweenAlpha1', 'Three',0 ,0.2)
		end
		if curBeat == 30 then
			makeLuaSprite('Two', 'Quintessential', 0, 0)
			addLuaSprite('Two')
			screenCenter('Two', 'xy')
			setObjectCamera('Two', 'other')
			doTweenAlpha('tweenAlpha2', 'Two',0 ,0.2)
		end
		if curBeat == 31 then
			makeLuaSprite('One', 'Quintuplets1', 0, 0)
			addLuaSprite('One')
			screenCenter('One', 'xy')
			setObjectCamera('One', 'other')
			doTweenAlpha('tweenAlpha3', 'One',0 ,0.2)
		end
	if curBeat == 386 then
	objectPlayAnimation('phone','callingU', true)
	doTweenY('call', 'calling', -170, 1, 'circOut')
	end
	if curBeat == 444 then
		addLuaSprite('bub', false)
	objectPlayAnimation('phone','idle', false)
	removeLuaSprite('calling')
	doTweenAlpha('tweenAlphaSunset', 'gotoubun-5_stage-sunset',0 ,45.5, 'cubeOut')
	end
end
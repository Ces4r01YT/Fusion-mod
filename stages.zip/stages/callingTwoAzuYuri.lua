function onCreate()
    makeLuaSprite('bg','streaming/BG_Azuri',-310,-200)
    addLuaSprite('bg',false)
    scaleObject('bg', 1.25, 1.25);
    makeLuaSprite('call','streaming/DiscordCall2',-310,-200)
    addLuaSprite('call',true)
    scaleObject('call', 1.05, 1.05);
end
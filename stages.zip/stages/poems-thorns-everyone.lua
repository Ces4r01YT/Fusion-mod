function onCreate()
	-- background shit
	makeLuaSprite('weebSky','poems n thorns/weebSky',-150, -20);
	setLuaSpriteScrollFactor('weebSky', 0.6,0.90);
	scaleObject('weebSky', 9, 6);
	makeLuaSprite('weebSchool', 'poems n thorns/weebSchool', -200, 0);
	setLuaSpriteScrollFactor('weebSchool', 0.6,0.90);
	scaleObject('weebSchool',6, 7);
	makeLuaSprite('weebStreet', 'poems n thorns/weebStreet',-200, 0);
	setLuaSpriteScrollFactor('weebStreet',  0.95, 0.95);
	scaleObject('weebStreet', 7, 7);
    
	-- sprites that only load if Low Quality is turned off
	if not lowQuality then
	makeLuaSprite('weebTreesBack','poems n thorns/weebTreesBack',-200, -20)
	setLuaSpriteScrollFactor('weebTreesBack', 0.85, 0.85);
	scaleObject('weebTreesBack', 6, 7);
	makeAnimatedLuaSprite('weebTrees', 'poems n thorns/weebTrees',-190, -20);
    setLuaSpriteScrollFactor('weebTrees', 0.85, 0.85);		
	scaleObject('weebTrees',6, 7)
	setProperty('weebSky.antialiasing', false);
	setProperty('weebSchool.antialiasing', false);
	setProperty('weebTreesBack.antialiasing', false);
    setProperty('weebStreet.antialiasing', false);

	end

	addLuaSprite('weebSky', false);
	addLuaSprite('weebSchool', false);
	addLuaSprite('weebStreet', false);
	addLuaSprite('weebTreesBack', false);
	addLuaSprite('weebTrees', false);
	addAnimationByPrefix('weebTrees','idle', 'weebTrees idle',12,true);

	makeLuaSprite('Screen', 'empty', -140, -10)
	makeGraphic('Screen', 12800, 1200, '000000')
	setObjectCamera('Screen', 'hud')
	--addLuaSprite('Screen', false)


	makeLuaSprite('nat','Natsuki_Hearts', -100, 1000)
	setObjectCamera('nat', 'camHUD')
	scaleObject('nat', 0.7, 0.7)
	addLuaSprite('nat', false)

	makeLuaSprite('yur','Yuri_Hearts', 700, 1000)
	setObjectCamera('yur', 'camHUD')
	scaleObject('yur', 0.7, 0.7)
	addLuaSprite('yur', false)

	
mikucam = 'camHUD'

	makeLuaSprite('miku1','MikuNakanoArt/MikuN1', -190, 0)
	setObjectCamera('miku1', mikucam)
    scaleObject('miku1', 1.25, 1.25)
	

	makeLuaSprite('miku2','MikuNakanoArt/MikuN2', 160, -10)
	setObjectCamera('miku2', mikucam)
	scaleObject('miku2', 0.85, 0.85)
	

	makeLuaSprite('miku3','MikuNakanoArt/MikuN3', 370, -7)
	setObjectCamera('miku3', mikucam)
	scaleObject('miku3', 0.67, 0.67)
	

	makeLuaSprite('miku4','MikuNakanoArt/MikuN4', 1000, -10)
	setObjectCamera('miku4', mikucam)
	scaleObject('miku4', 0.5, 0.5)
	

	makeLuaSprite('miku5','MikuNakanoArt/MikuN9', 785, -10)
	setObjectCamera('miku5', mikucam)
	--scaleObject('miku5', 0.25, 0.25)
	

	makeLuaSprite('miku6','MikuNakanoArt/MikuN6', 525, -25)
	setObjectCamera('miku6', mikucam)
	scaleObject('miku6', 0.7, 0.7)


	--makeLuaSprite('miku7','MikuNakanoArt/MikuN7', 700, 100)
	--setObjectCamera('miku7', mikucam)
	--scaleObject('miku7', 0.5, 0.5)


	addLuaSprite('miku4', true)
	addLuaSprite('miku5', true)
	addLuaSprite('miku6', true)
	--addLuaSprite('miku7', true)
	addLuaSprite('miku3', true)
	addLuaSprite('miku2', true)
	addLuaSprite('miku1', true)



    setProperty('miku1.alpha', 0)
    setProperty('miku2.alpha', 0)
    setProperty('miku3.alpha', 0)
    setProperty('miku4.alpha', 0)
    setProperty('miku5.alpha', 0)
    setProperty('miku6.alpha', 0)	
    --setProperty('miku7.alpha', 1)
	
	
end

function onBeatHit()
    if curBeat == 50 then
		doTweenY('natIn', 'nat', 0, 0.8, 'backOut')
		doTweenY('yurIn', 'yur', 0, 0.8, 'backOut')
    end

    if curBeat == 110 then
		doTweenAlpha('mik1', 'miku1', 1, 0.5, 'cubeOut')
	end
	if curBeat == 111 then
		doTweenAlpha('mik2', 'miku2', 1, 0.5, 'cubeOut')
	end
	if curBeat == 112 then
		doTweenAlpha('mik3', 'miku3', 1, 0.5, 'cubeOut')
	end
	if curBeat == 113 then
		doTweenAlpha('mik4', 'miku6', 1, 0.5, 'cubeOut')
	end
	if curBeat == 114 then
		doTweenAlpha('mik5', 'miku5', 1, 0.5, 'cubeOut')
	end
	if curBeat == 115 then
		doTweenAlpha('mik6', 'miku4', 1, 0.5, 'cubeOut')
	end

end


function onTweenCompleted(tag)
	if tag == 'natIn' then
		doTweenY('natOut', 'nat', 700, 0.5, 'cubeIn')
	end
	if tag == 'natIn' then
		doTweenY('yurOut', 'yur', 700, 0.5, 'cubeIn')
	end
end

function onUpdate(elapsed)
    --Change To Pixel
	if curStep == 208 then

	    for i=0,4,1 do
		    setPropertyFromGroup('opponentStrums', i, 'texture', 'NOTE_assets_ddlc');
		    setPropertyFromGroup('playerStrums', i, 'texture', 'NOTE_assets_ddlc');
	    end
	end

	if curStep == 187 then --This one MUST be at least 16 or 32 steps earlier (depends of the version of Psych Engine)
        for i = 0, getProperty('unspawnNotes.length')-1 do
		    setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets_ddlc');
			setPropertyFromGroup('unspawnNotes', i, 'noteSplashTexture', 'NOTE_splashes_doki');
        end
	end
	

end

--If you also have custom notes use this one
--function onUpdate(elapsed)
--	    for i = 0, getProperty('unspawnNotes.length')-1 do
--		    if getPropertyFromGroup('unspawnNotes', i, 'noteType') == 'custom Note' then
--			    setPropertyFromGroup('unspawnNotes', i, 'texture', 'yourNoteAssets');
--				setPropertyFromGroup('unspawnNotes', i, 'noteSplashTexture', 'yourNoteSplashes'); --If you are not gonna use this, delete this
--			else
--		        setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets');
--				setPropertyFromGroup('unspawnNotes', i, 'noteSplashTexture', 'noteSplashes');
--			end
--        end
--	
--end
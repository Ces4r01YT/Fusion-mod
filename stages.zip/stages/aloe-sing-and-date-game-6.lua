function onCreate()



	makeLuaSprite('holo', 'sinner-stage', 0, 0);
	addLuaSprite('holo', false);
	--scaleObject('holo', 2.6, 2.6)

	
	makeLuaSprite('offScreen', '')
	makeGraphic('offScreen', screenWidth, screenHeight, '000000')
	addLuaSprite('offScreen', false)

	
	makeLuaSprite('room', 'doog/room_TvEffect', -1050, -350);
	setScrollFactor('room', 1, 1);
	scaleObject('room', 0.7, 0.7);
	addLuaSprite('room', false);

	makeLuaSprite('somari2', '', -750, -540)
	makeGraphic('somari2', screenWidth, screenHeight, '000000')
	scaleObject('somari2', 2.2, 2.2)
	addLuaSprite('somari2', false)
	setProperty('somari2.alpha', 0)


	
	--setObjectCamera('room', 'camHUD')
	makeAnimatedLuaSprite('aloe', 'characters/Aloo-Guitar', 870, 620);
    addAnimationByPrefix('aloe', 'idle', 'BF idle dance', 24, false);
	addLuaSprite('aloe', true)
	setProperty('aloe.visible', false)

	makeLuaSprite('intro', '')
	makeGraphic('intro', screenWidth, screenHeight, '000000')
	setObjectCamera('intro', 'other')
	addLuaSprite('intro', false)

	
setProperty('cameraSpeed', 2.7);
addLuaScript("extra_scripts/Holofunk-hud-nostrums", false)


setProperty('camHUD.alpha', 0)
setProperty('introSoundsSuffix', '-hf')




    makeLuaText('ts1', "Mario sing and game rythm 9", 0, -1245, 170);  --245
	setTextSize('ts1', 50);
	setTextFont('ts1', 'Krungthep.ttf')
	setObjectCamera('ts1', 'other');
	setTextColor('ts1', 'FFFFFF')
	addLuaText('ts1');

	makeLuaText('ts2', "but", 0, -1570, 270);   --570
	setTextSize('ts2', 50);
	setTextFont('ts2', 'Krungthep.ttf')
	setObjectCamera('ts2', 'other');
	setTextColor('ts2', 'FFFFFF')
	addLuaText('ts2');

	makeLuaText('KoroText', "Korone", 0, -1300, 370);    --300
	setTextSize('KoroText', 50);
	setTextFont('KoroText', 'Krungthep.ttf')
	setObjectCamera('KoroText', 'other');
	setTextColor('KoroText', 'AB6458')
	addLuaText('KoroText');

	makeLuaText('ts3', "and", 0, -1570, 370);    --570
	setTextSize('ts3', 50);
	setTextFont('ts3', 'Krungthep.ttf')
	setObjectCamera('ts3', 'other');
	setTextColor('ts3', 'FFFFFF')
	addLuaText('ts3');

	makeLuaText('AlooText', "Aloe", 0, -1750, 370);    --750
	setTextSize('AlooText', 50);
	setTextFont('AlooText', 'Krungthep.ttf')
	setObjectCamera('AlooText', 'other');
	setTextColor('AlooText', 'EF71B1')
	addLuaText('AlooText');


	makeLuaText('ts4', "sings it", 0, -1525, 470);    --525
	setTextSize('ts4', 50);
	setTextFont('ts4', 'Krungthep.ttf')
	setObjectCamera('ts4', 'other');
	setTextColor('ts4', 'FFFFFF')
	addLuaText('ts4');

	makeLuaSprite('angykayu', 'doog/OkayuAngry1', 1500, -50);
	scaleObject('angykayu', 0.7, 0.7);
	setObjectCamera('angykayu', 'other')
	addLuaSprite('angykayu', false);




end


function onUpdate()
	--removeLuaText('watermark')
	--removeLuaText('name')
	setObjectOrder('gfGroup', getObjectOrder('room') - 2)

	idleDance(curBeat);
end

function onBeatHit()
    if curBeat == 16 then
		doTweenAlpha('enterthehud', 'camHUD', 1, 0.25, 'quarterOut')   
	end 

    if curBeat == 279 then
	doTweenAlpha('spotlightsupposed', 'somari2', 1, 0.25, 'linear')   
    end
	if curBeat == 286 then
		doTweenX('okayum', 'angykayu', 300, 0.35, 'backOut')
	end
    if curBeat == 287 then
	--doTweenAlpha('3rdact', 'somari2', 0, 0.5, 'linear')   
	doTweenX('okayumbye', 'angykayu', -700, 0.35, 'backIn')
    end
	if curBeat == 288 then
		setProperty('somari2.alpha', 0)
		setProperty('aloe.visible', true)
		removeLuaSprite('offScreen', false)
		addLuaScript("extra_scripts/okayu-screen-zoom", false)
		setProperty('cameraSpeed', 5.7);
    end
end

function idleDance(beat)
        if beat % 2 == 0 then
            objectPlayAnimation('aloe', 'idle', false);
        end
end




function onCountdownTick(counter)
	if counter == 0 then
		doTweenX('ti1', 'ts1', 245, 0.25, 'cubeOut')
		doTweenX('ti2', 'ts2', 570, 0.25, 'cubeOut')
	elseif counter == 1 then
		doTweenX('ti3', 'KoroText', 300, 0.25, 'cubeOut')
		doTweenX('ti4', 'ts3', 570, 0.25, 'cubeOut')	
		doTweenX('ti5', 'AlooText', 750, 0.25, 'cubeOut')	
	elseif counter == 2 then
		doTweenX('ti6', 'ts4', 525, 0.25, 'cubeOut')
	elseif counter == 3 then
		doTweenAlpha('byeIntro', 'intro', 0, 0.7, 'cubeOut')
		doTweenAlpha('bye1', 'ts1', 0, 0.7, 'cubeOut')
		doTweenAlpha('bye2', 'ts2', 0, 0.7, 'cubeOut')
		doTweenAlpha('bye3', 'ts3', 0, 0.7, 'cubeOut')
		doTweenAlpha('bye4', 'ts4', 0, 0.7, 'cubeOut')
		doTweenAlpha('bye5', 'KoroText', 0, 0.7, 'cubeOut')
		doTweenAlpha('bye6', 'AlooText', 0, 0.7, 'cubeOut')
	end
end


function onStepHit()
	if curStep == 1543 then
		setProperty('camGame.visible', false)
	end
end





--runHaxeCode([[
--    FlxG.cameras.remove(game.camHUD, false);
--    FlxG.cameras.remove(game.camOther, false);
--
--
--
--	Holo6Cam = new FlxCamera();
--	Holo6Cam.x = 150;
--	Holo6Cam.y = 50;
--	Holo6Cam.width = 640;   
--	Holo6Cam.height = 375;  
--	Holo6Cam.zoom = 0.4;
--	Holo6Cam.alpha = 1;
--	Holo6Cam.scroll.x = 2500;
--	Holo6Cam.scroll.y = 0;
--
--
--
--	FlxG.cameras.add(Holo6Cam);
--	FlxG.cameras.add(game.camHUD, false);
--	FlxG.cameras.add(game.camOther, false);
--	
--		
--    ]])
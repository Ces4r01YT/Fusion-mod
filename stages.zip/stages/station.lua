function onCreate()

		makeLuaSprite('sky','station/bg_week_3_sky',-250,0);
		
		scaleObject('sky',1.5,  1.5);
		
		makeLuaSprite('city','station/bg_week_3_city', -180, 210);
		setLuaSpriteScrollFactor('city', 0.1, 0.1);
		scaleObject('city',1.4,  1.4);
	
		makeLuaSprite('behindTrain','station/behindTrain', -140, 50);
		
		makeLuaSprite('station2','station/bg_week_3', -250, -50);
		scaleObject('station2',1.5,  1.7);
		makeAnimatedLuaSprite('bop', 'station/boppers',  -250, 400);
	    scaleObject('bop', 1.5, 1.5);

		makeLuaSprite('street','station/bg_week_3_street', -250, 40);
		scaleObject('street',1.5,  1.5);
		makeLuaSprite('train','station/train',  2000, 360);
        
	
	addLuaSprite('sky', false);
	addLuaSprite('city', false);
	addLuaSprite('behindTrain', false);
	addLuaSprite('station2', false);
	addLuaSprite('bop', false);
	addAnimationByPrefix('bop', 'idle', 'bop', 24, true);
	addLuaSprite('train', false);
	addLuaSprite('street', false);
	runTimer('trainsound',4)

end
function onTimerCompleted(t,l,ll)
	if t == 'trainsound' then
	    playSound('train_passes');
	    runTimer('trainCome',4)
	end
	if t == 'trainCome' then
		setProperty('train.x', 1150)
		doTweenX('train','train',-1150,0.4,'sineOut')
		triggerEvent('Play Animation','hairBlow',2)
		runTimer('trainCome2',0.4)
	end
	if t == 'trainCome2' then
		setProperty('train.x', 1150)
		doTweenX('train','train',-1150,0.4,'sineOut')
		runTimer('trainCome3',0.4)
	end
		if t == 'trainCome3' then
		setProperty('train.x', 1150)
		doTweenX('train','train',-1150,0.4,'sineOut')
		runTimer('trainCome4',0.4)
		end
		if t == 'trainCome4' then
		setProperty('train.x', 1150)
		doTweenX('train','train',-1150,0.4,'sineOut')
		runTimer('trainCome5',0.4)
		end
		if t == 'trainCome5' then
		setProperty('train.x', 1150)
		doTweenX('train','train',-1150,0.4,'sineOut')
		runTimer('trainCome6',0.4)
		end
		if t == 'trainCome6' then
		setProperty('train.x', 1150)
		doTweenX('train','train',-1150,0.4,'sineOut')
		runTimer('trainCome7',0.4)
		end
	if t == 'trainCome7' then
    triggerEvent('Play Animation','hairFall',2)
	doTweenX('train','train',-4000,0.5,'sineOut')
	runTimer('trainRide',1)

	end
	if t == 'trainRide' then
  
	setProperty('train.x', 2000)
	runTimer('trainsound',8)

	end
end


	

﻿function onCreate()

	makeLuaSprite('salon', 'quintuplets/HallLightoff', 240, 160); 
	setLuaSpriteScrollFactor('salon', 0.6, 0.6);
	scaleObject('salon', 0.6, 0.6);
	

	addLuaSprite('salon', false);


	end
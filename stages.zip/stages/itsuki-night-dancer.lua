﻿function onCreate()
	-- background shit
	makeLuaSprite('gotoubun-5_stage', 'quintuplets/gotoubun-5_stage_night', -400, -400);
	setScrollFactor('gotoubun-5_stage', 0.9, 0.9);

	addLuaSprite('gotoubun-5_stage', false);

	makeLuaSprite('shad', '')
	makeGraphic('shad', screenWidth, screenHeight, '000077')
	setProperty('shad.alpha', 0.1)
	setObjectCamera('shad', 'camHUD')
	addLuaSprite('shad', false)

end

function onUpdate()
	setProperty('iconP2.alpha', 0)
	setProperty('dad.alpha', 0)
end

function onCreatePost()
	if not middlescroll then
        setPropertyFromGroup('opponentStrums', 0, 'x', -5000)
        setPropertyFromGroup('opponentStrums', 1, 'x', -5000)
        setPropertyFromGroup('opponentStrums', 2, 'x', -5000)
        setPropertyFromGroup('opponentStrums', 3, 'x', -5000)

        setPropertyFromGroup('playerStrums', 0, 'x', defaultPlayerStrumX0 - 350)
        setPropertyFromGroup('playerStrums', 1, 'x', defaultPlayerStrumX1 - 330)
        setPropertyFromGroup('playerStrums', 2, 'x', defaultPlayerStrumX2 - 310)
        setPropertyFromGroup('playerStrums', 3, 'x', defaultPlayerStrumX3 - 290)
	end
end
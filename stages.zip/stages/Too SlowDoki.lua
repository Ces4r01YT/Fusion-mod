function onCreate()
	
	makeLuaSprite('black', 'black', 0, 0);
	scaleObject('black', 20, 20);
	setProperty('black.visible', false);

	makeLuaSprite('black1', 'blackFlash', -720, -680);
	scaleObject('black1', 1, 1);
	setProperty('black1.visible', false);

	makeLuaSprite('bg', 'back1', -720, -680);
    scaleObject('bg', 2, 2);
	addLuaSprite('bg', false);

	makeLuaSprite('thefrickinbg', 'BGsky', -420, -55); --imagine being lazy lol

	scaleObject('thefrickinbg', 1.35, 1.35);
	setProperty('thefrickinbg.antialiasing', true);

	makeLuaSprite('thebg', 'TreesFG', -235, -55); --imagine being lazy lol

	scaleObject('thebg', 1.2, 1.2);

	addLuaSprite('thefrickinbg', false);
	addLuaSprite('thebg', true);
	addLuaSprite('black1', true);

end

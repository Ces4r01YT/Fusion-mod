function onCreate()
	-- background shit
	makeLuaSprite('weebSky2','school2/weebSkyAquino',-150, -20);
	setLuaSpriteScrollFactor('weebSky2', 0.6,0.90);
	scaleObject('weebSky2', 9, 6);
	addLuaSprite('weebSky2', false);
	makeLuaSprite('weebSchool2', 'school2/weebSchoolAquino', -200, 0);
	setLuaSpriteScrollFactor('weebSchool2', 0.6,0.90);
	scaleObject('weebSchool2',6, 7);
	addLuaSprite('weebSchool2', false);
	makeLuaSprite('weebStreet2', 'school2/weebStreetAquino',-200, 0);
	setLuaSpriteScrollFactor('weebStreet2',  0.95, 0.95);
	scaleObject('weebStreet2', 7, 7);
	addLuaSprite('weebStreet2', false);
    
	setProperty('weebSky2.antialiasing', false);
	setProperty('weebSchool2.antialiasing', false);
    setProperty('weebStreet2.antialiasing', false);

end
function onCreate()
	-- background shit
	makeLuaSprite('stageback', 'holoweek1/stageback', -500, -200);
	setLuaSpriteScrollFactor('stageback', 0.9, 0.9);
	
	makeLuaSprite('stagefront', 'holoweek1/stagefront', -650, 600);
	setLuaSpriteScrollFactor('stagefront', 0.9, 0.9);
	scaleObject('stagefront', 1.1, 1.1);


	addLuaSprite('stageback', false);
	addLuaSprite('stagefront', false);




	precacheImage('ready_holo')
	precacheImage('set_holo')
	precacheImage('go_holo')
	makeLuaSprite('two', 'ready_holo', 0, 0)
	screenCenter('two', 'xy')
	setObjectCamera('two', 'other')
	makeLuaSprite('one', 'set_holo', 0, 0)
	screenCenter('one', 'xy')
	setObjectCamera('one', 'other')
	makeLuaSprite('go', 'go_holo', 0, 0)
	screenCenter('go', 'xy')
	setObjectCamera('go', 'other')
	setProperty('introSoundsSuffix', '-hf')
	
	addLuaScript('extra_scripts/Holofunk-hud', false)
end


function onCountdownTick(counter)
	if counter == 1 then
		addLuaSprite('two')
		doTweenAlpha('countdown2', 'two',0 ,0.3, 'cubeIn')
		playSound('countdown')
		setProperty('countdownReady.visible', false)		
	elseif counter == 2 then
		doTweenAlpha('countdown1', 'one',0 ,0.3, 'cubeIn')
		addLuaSprite('one')
		playSound('countdown')
		setProperty('countdownSet.visible', false)
	elseif counter == 3 then
		doTweenAlpha('countdowngo', 'go',0 ,0.3, 'cubeIn')
		addLuaSprite('go')
		playSound('countdownend')
		setProperty('countdownGo.visible', false)
	end
end
function onCreate()
	-- background shit
	makeLuaSprite('MainBG', 'stage ddlc/DDLCbg', -700, -490);
	setLuaSpriteScrollFactor('MainBG', 1, 0.9);
    scaleObject('MainBG', 1.6, 1.6);

    makeLuaSprite('DesksFestival', 'stage ddlc/DesksFront', -700, -500);
	setLuaSpriteScrollFactor('DesksFestival', 1, 0.9);
	scaleObject('DesksFestival', 1.6, 1.6);
	
	
	makeLuaSprite('FarBack', 'stage festival/FarBack', -700, -500);
	setLuaSpriteScrollFactor('FarBack', 1, 0.9);
	scaleObject('FarBack', 1.6, 1.6);
	-- sprites that only load if Low Quality is turned off
	if not lowQuality then
		makeAnimatedLuaSprite('lights_back', 'stage festival/lights_back',210, 130);
        setLuaSpriteScrollFactor('lights_back', 1, 0.9);		
        scaleObject('lights_back', 1.6, 1.6);
		
		makeAnimatedLuaSprite('yuri', 'stage festival/yuri',0, 150);
        setLuaSpriteScrollFactor('yuri', 1, 0.9);		
        scaleObject('yuri', 0.7, 0.7);
		
	
		
		makeAnimatedLuaSprite('natsuki', 'stage festival/natsuki',1000, 300);
        setLuaSpriteScrollFactor('natsuki', 1, 0.9);		
        scaleObject('natsuki', 0.7, 0.7);
		

		
		makeAnimatedLuaSprite('lights_front', 'stage festival/lights_front',-1305, 700);
        setLuaSpriteScrollFactor('lights_front',1, 0.9);		
        scaleObject('lights_front', 1.5, 1);
		setPropertyLuaSprite('lights_front', 'flipX', true);
   
	end

	addLuaSprite('MainBG', false);
	addLuaSprite('FestivalBanner', false);
	--addLuaSprite('lights_back', false); 
	--addAnimationByPrefix('lights_back', 'idle', 'lights back', 24, true);
	addLuaSprite('sayori', false); 
	addAnimationByPrefix('sayori', 'idle', 'Sayori BG', 24, true);
	addLuaSprite('yuri', false); 
	addAnimationByPrefix('yuri', 'idle', 'Yuri BG', 24, true);
	addLuaSprite('protag', false); 
	addAnimationByPrefix('protag', 'idle', 'Protag-kun BG', 24, true);
	addLuaSprite('monika', false); 
	addAnimationByPrefix('monika', 'idle', 'Moni BG', 24, true);
	addLuaSprite('natsuki', false); 
	addAnimationByPrefix('natsuki', 'idle', 'Natsu BG', 24, true);
	addLuaSprite('DesksFestival', false);
	--addLuaSprite('lights_front', false); 
	--addAnimationByPrefix('lights_front', 'idle', 'Lights front', 24, true);
        addLuaSprite('FestivalBanner', false); 




	
	makeLuaSprite('two', 'ready_doki', 100, 100)
	screenCenter('two', 'xy')
	setObjectCamera('two', 'other')
	makeLuaSprite('one', 'set_doki', 100, 100)
	screenCenter('one', 'xy')
	setObjectCamera('one', 'other')
	makeLuaSprite('go', 'go_doki', 100, 100)
	screenCenter('go', 'xy')
	setObjectCamera('go', 'other')
	setProperty('countdownReady.visible', false)
	setProperty('countdownSet.visible', false)
	setProperty('countdownGo.visible', false)
	setProperty('introSoundsSuffix', '-NADALAVERGAEXACTO')


	--scaleObject('two', 0.75, 0.75)
	--scaleObject('one', 0.75, 0.75)
	--scaleObject('go', 0.75, 0.75)
	
end

function onCountdownTick(counter)
	if counter == 0 then
		playSound('DokiOverlap', 0.5)
	
	elseif counter == 1 then
		addLuaSprite('two')
		playSound('DokiOverlap',0.5)
		doTweenAlpha('countdown2', 'two',0 ,0.3, 'cubeIn')
		setProperty('countdownReady.visible', false)
				
	elseif counter == 2 then
		addLuaSprite('one')
		playSound('DokiOverlap',0.5)
		doTweenAlpha('countdown1', 'one',0 ,0.3, 'cubeIn')
		setProperty('countdownSet.visible', false)

	elseif counter == 3 then
		addLuaSprite('go')
		playSound('DokiSelect',0.5)
		doTweenAlpha('countdownGo', 'go',0 ,0.3, 'cubeIn')
		setProperty('countdownGo.visible', false)
	end
end
function onCreate()
	-- background shit
	
	makeLuaSprite('skyBG', 'FL_bg', -1220, -550)
	scaleObject('skyBG', 1.2, 1.2)
	setScrollFactor('skyBG', 0.1, 0.1)

	makeAnimatedLuaSprite('bgLimo', 'FL_backtrain', -2620, -250)
	addAnimationByPrefix('bgLimo', 'pleaseWork', 'BG limo', 24, true)
	objectPlayAnimation('bgLimo', 'pleaseWork', false)
	setScrollFactor('bgLimo', 0.4, 0.4)

	makeAnimatedLuaSprite('limo', 'FL_train', -700, 480)
	addAnimationByPrefix('limo', 'drive', 'Limo stage', 24, true)
	objectPlayAnimation('limo', 'drive', false)
	setScrollFactor('limo', 0.4, 0.4)

	addLuaSprite('skyBG')
	addLuaSprite('bgLimo')
	addLuaSprite('limo')
end
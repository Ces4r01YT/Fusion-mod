local x = -1200
local y = -760

function onCreate()

	makeLuaSprite('bg', '', x, y-250)
	makeGraphic("bg", 3840, 2560, '000000')
	setScrollFactor('bg', 1, 1);
	addLuaSprite('bg', false);
	scaleObject('bg', 1, 1)

	makeLuaSprite('gbg', '', x, y-250)
	makeGraphic("gbg", 3840, 2560, '151515')
	setScrollFactor('gbg', 1, 1);
	addLuaSprite('gbg', false);
	scaleObject('gbg', 1, 1)
	setProperty("gbg.alpha", 0)

	makeLuaSprite('headbg', 'virtual/headbg', x, y);
	setScrollFactor('headbg', 1.12, 1.12);
	precacheImage('virtual/headbg')
	addLuaSprite('headbg', false);
	scaleObject('headbg', 2.2, 2.2)
	setProperty("headbg.alpha", 0)


	makeLuaSprite('Wall Bg', 'virtual/Wall Bg', x, y);
	setScrollFactor('Wall Bg', 1.12, 1.12);
	precacheImage('virtual/Wall Bg')
	addLuaSprite('Wall Bg', false);
	scaleObject('Wall Bg', 1, 1)

	makeAnimatedLuaSprite('GF','characters/Mr_Virtual_Girlfriend_Assets_jaj', 540, -50)
	addAnimationByPrefix('GF','dance','GF Dies lol',24,true)
	setScrollFactor('GF', 1, 1);
	precacheImage('characters/Mr_Virtual_Girlfriend_Assets_jaj')
	addLuaSprite('GF', false);
	scaleObject('GF', 1, 1)
	setProperty("GF.alpha", 0)


	makeLuaSprite('Back Pipes', 'virtual/Back Pipes', x, y);
	setScrollFactor('Back Pipes', 1.07, 1.07);
	precacheImage('virtual/Back Pipes')
	addLuaSprite('Back Pipes', false);
	scaleObject('Back Pipes', 1, 1)

	makeLuaSprite('Back Platform', 'virtual/Back Platform', x, y);
	setScrollFactor('Back Platform', 1.07, 1.07);
	precacheImage('virtual/Back Platform')
	addLuaSprite('Back Platform', false);
	scaleObject('Back Platform', 1, 1)

	makeLuaSprite('Corner top Left Pipes', 'virtual/Corner top Left Pipes', x, y);
	setScrollFactor('Corner top Left Pipes', 1.07, 1.07);
	precacheImage('virtual/Corner top Left Pipes')
	addLuaSprite('Corner top Left Pipes', false);
	scaleObject('Corner top Left Pipes', 1, 1)
	
	makeLuaSprite('Front Pipes', 'virtual/Front Pipes', x, y);
	setScrollFactor('Front Pipes', 1, 1);
	precacheImage('virtual/Front Pipes')
	addLuaSprite('Front Pipes', false);
	scaleObject('Front Pipes', 1, 1)

	makeLuaSprite('TooLate1', 'virtual/TooLate', startX, startY)
	addLuaSprite('TooLate1', false)
	makeLuaSprite('TooLate2', 'virtual/TooLate', startX + size, startY)
	addLuaSprite('TooLate2', false)
	scaleObject('TooLate1', 1.7, 1.7)
	scaleObject('TooLate2', 1.7, 1.7)
	setProperty("TooLate1.alpha", 0)
	setProperty("TooLate2.alpha", 0)
	scrollA()

	makeLuaSprite('Main Platform', 'virtual/Main Platform', x, y);
	setScrollFactor('Main Platform', 1, 1);
	precacheImage('virtual/Main Platform')
	addLuaSprite('Main Platform', false);
	scaleObject('Main Platform', 1, 1)

	makeLuaSprite('Platform', 'virtual/Platform', x, y+580);
	setScrollFactor('Platform', 1, 1);
	precacheImage('virtual/Platform')
	addLuaSprite('Platform', false);
	scaleObject('Platform', 1, 1)
	setProperty("Platform.alpha", 0)


addLuaScript('extra_scripts/charting/paranoia/TransparentWindow.lua', false)
addLuaScript('extra_scripts/charting/paranoia/Window.lua', false)
addLuaScript('extra_scripts/charting/paranoia/CCountdown.lua', false)
addLuaScript('extra_scripts/charting/paranoia/Eventsbl.lua', false)
addLuaScript('extra_scripts/charting/paranoia/Shaders.lua', false)
end

function onCreatePost()
	makeLuaSprite('Health', 'healthBarNEW')
	setObjectCamera('Health', 'hud')
	addLuaSprite('Health', true)
	setObjectOrder('Health', getObjectOrder('healthBar') + 1)
	setProperty('healthBar.visible', true)

	setTextFont('timeTxt', 'Felixti.ttf')
	setTextColor("timeTxt", "FF0000")
    setProperty('timeBar.y', 50000);
    setTextFont('scoreTxt', 'Felixti.ttf')
	setTextColor("scoreTxt", "FF0000")

	setProperty('botplayTxt.x', -170);
	setProperty('botplayTxt.y', 0);
    setTextFont('botplayTxt', 'Felixti.ttf')
	setTextColor("botplayTxt", "FF0000")
end

function onUpdatePost(elapsed)
	setProperty('Health.x', getProperty('healthBar.x') - 45)
	setProperty('Health.y', getProperty('healthBar.y') - 10)
end

function onUpdate()
	--initLuaShader('virtualBoy')
    --setSpriteShader('camGame', 'virtualBoy', true)
end

size = 3248
startX = -800
startY = -660
duration = 3

function scrollA()
doTweenX('TooLate1move','TooLate1', startX - size, duration)
doTweenX('TooLate2move','TooLate2', startX, duration)
end

function onTweenCompleted(tag)
if tag == ('TooLate2move') then
scrollB()
end
if tag == ('TooLate2move2') then
scrollA()
end
end
function scrollB()
doTweenX('TooLate1move2','TooLate1', startX, 0.001)
doTweenX('TooLate2move2','TooLate2', startX + size, 0.001)
end
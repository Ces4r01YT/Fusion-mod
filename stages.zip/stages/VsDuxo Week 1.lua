function onCreate()
	-- background shit
	makeLuaSprite('stageback', 'Vs Duxo/Week1D/stage_auditions_sus', -500, -300);
    scaleObject('stageback', 2, 2);


	-- sprites that only load if Low Quality is turned off
	
	addLuaSprite('stageback', false);

	
	close(true); --For performance reasons, close this script once the stage is fully loaded, as this script won't be used anymore after loading the stage
end
function onCreate()
	makeLuaSprite('yard','DdlcSoft/Central_Courtyard', -370, -400);
    addLuaSprite('yard', false);
	setProperty('yard.color',getColorFromHex('5D36C1'))

	precacheImage('majinthing/Majin_Notes')
	precacheImage('majinthing/Majin_Splashes')
	precacheImage('majinthing/three')
	precacheImage('majinthing/two')
	precacheImage('majinthing/one')
	precacheImage('majinthing/go')
end

function onCreatePost()
	setProperty('scoreTxt.visible',false)
	setProperty('boyfriend.color',getColorFromHex('5D36C1'))
end

function onUpdatePost()
	setProperty('trailBF.color',getColorFromHex('5D36C1'))
	setProperty('trailDad.color',getColorFromHex('5D36C1'))
	setProperty('iconP1.alpha', 0)
	setProperty('iconP2.alpha', 0)
	setProperty('winningIconBf.alpha', 0)
	setProperty('winningIconDad.alpha', 0)
end
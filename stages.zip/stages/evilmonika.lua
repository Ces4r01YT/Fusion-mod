function onCreate()
	-- background shit
	makeLuaSprite('stageback', 'bigmonika/BG',-500, -300);
	setLuaSpriteScrollFactor('stageback', 1, 0.9);
	  scaleObject('stageback', 1.7, 1.8);
	makeLuaSprite('stagefront', 'bigmonika/FG', -500, -300);
	setLuaSpriteScrollFactor('stagefront', 1, 0.9);
	scaleObject('stagefront', 1.7, 1.8);

	-- sprites that only load if Low Quality is turned off
	if not lowQuality then
	makeLuaSprite('Sky', 'bigmonika/Sky', -500, -300);
	setLuaSpriteScrollFactor('Sky', 1, 0.9);
	scaleObject('Sky', 1.7, 1.8);
	
	end
	
    addLuaSprite('Sky', false);
	addLuaSprite('stageback', false);
	addLuaSprite('stagefront', false);
	

end
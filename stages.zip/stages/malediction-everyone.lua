function onCreate()
  makeAnimatedLuaSprite('static', 'STATIC_curse', -590, -120);
  setLuaSpriteScrollFactor('static', 1, 1);
  scaleObject('static', 1.5, 1.5);
  
  addLuaSprite('static', false)
  addAnimationByPrefix('static', 'idle', 'staticBackground', 24, true);

  setProperty('static.alpha', 0.5)


--im boing boing rushia uruha
  makeLuaSprite('stageback', 'russia/motherBG', -700, -800);
	setLuaSpriteScrollFactor('stageback', 0.9, 0.9);
	scaleObject('stageback', 1.1, 1.1);

  makeLuaSprite('stagefront', 'russia/motherFG', -650, -800);
	setLuaSpriteScrollFactor('stagefront', 0.9, 0.9);
	scaleObject('stagefront', 1.1, 1.1);

  makeLuaSprite('plants', 'russia/plants', -1000, -1200);
	scaleObject('plants', 1.4, 1.4);



  --literature club
  makeLuaSprite('MainBG', 'stage ddlc/DDLCbg', -700, -490);
	setLuaSpriteScrollFactor('MainBG', 1, 0.9);
    scaleObject('MainBG', 1.6, 1.6);

    makeLuaSprite('DesksFestival', 'stage ddlc/DesksFront', -700, -500);
	setLuaSpriteScrollFactor('DesksFestival', 1, 0.9);
	scaleObject('DesksFestival', 1.6, 1.6);
	
	
	makeLuaSprite('FarBack', 'stage festival/FarBack', -700, -500);
	setLuaSpriteScrollFactor('FarBack', 1, 0.9);
	scaleObject('FarBack', 1.6, 1.6);




--vocaloid
  makeLuaSprite('skyMiku', 'expo/nightsky',-280, -100);
	setScrollFactor('skyMiku', 0.6, 0.6);
	scaleObject('skyMiku', 1.1, 1.1);

	makeLuaSprite('backlightsMiku', 'expo/backlight',-285, -100);
	setScrollFactor('backlightsMiku', 0.7, 0.7);
	scaleObject('backlightsMiku', 1.1, 1.1);
	
	makeLuaSprite('concerttopMiku', 'expo/concerttop',-285, -100);
	setScrollFactor('concerttopMiku', 0.75, 0.75);
	scaleObject('concerttopMiku', 1.1, 1.1);

	makeLuaSprite('stadiumMiku', 'expo/stadiumback',-420, -100);
	setScrollFactor('stadiumMiku', 0.9, 0.9);
	scaleObject('stadiumMiku', 1.1, 1.1);

	makeLuaSprite('stagefrontMiku', 'expo/mainstage',-285, -100);
	scaleObject('stagefrontMiku', 1.1, 1.1);

--la diabla
makeLuaSprite('azulabg', 'streaming/BG_Azula', -450, 50)
scaleObject('azulabg', 2, 2)





--windows xp
makeLuaSprite('wallpaper', 'horudavt/xp_bg', -280, -100);
--setScrollFactor('wallpaper', 0.6, 0.6);
--scaleObject('wallpaper', 1.1, 1.1);

makeLuaSprite('window', 'horudavt/VIDEO', 285, -100);
--setScrollFactor('window', 0.7, 0.7);
scaleObject('window', 3.5, 3.5);

makeLuaSprite('error', 'horudavt/Error_Screen', 285, -100);
setObjectCamera('error', 'other')








addLuaScript('extra_scripts/Sayori_chr', false)
addLuaScript('extra_scripts/Yuri-player_chr', false)


setProperty('sayo-char.alpha', 0)
setProperty('yuri-player-char.alpha', 0)
end



function onUpdate()
  if dadName == 'azula-closeup' or dadName == 'nanda-closeup' or dadName == 'bigtomoe' then
  cameraSetTarget('dad')
  end

  if curBeat == 147 then
    setProperty('vocals.volume', 0)
    playSound('WindowsXpError', 0.5)
  end

  if dadName == 'bigtomoe' then
    setProperty('iconP2.alpha', 0)
  end

end



function onUpdatePost()
  if dadName == 'majin' then
  setProperty('boyfriend.color',getColorFromHex('5D36C1'))
  setProperty('gf.color',getColorFromHex('5D36C1'))
  setProperty('trailBF.color',getColorFromHex('5D36C1'))
	setProperty('trailDad.color',getColorFromHex('5D36C1'))
  else
  setProperty('boyfriend.color',getColorFromHex('FFFFFF'))
  setProperty('gf.color',getColorFromHex('FFFFFF'))
  setProperty('trailBF.color',getColorFromHex('FFFFFF'))
	setProperty('trailDad.color',getColorFromHex('FFFFFF'))
  end
end

function onBeatHit()
    if curBeat == 20 then
      removeLuaSprite('static')
      addLuaSprite('stageback', false);
      addLuaSprite('stagefront', false);
      addLuaSprite('plants',true);
    end
    if curBeat == 36 then
      removeLuaSprite('stageback');
      removeLuaSprite('stagefront');
      removeLuaSprite('plants');


      addLuaSprite('MainBG', false);
      addLuaSprite('DesksFestival', true);

      setProperty('sayo-char.alpha', 1)
      setProperty('yuri-player-char.alpha', 1)
    end

    if curBeat == 52 then
    --enter the other dokis
    end
    if curBeat == 68 then
      removeLuaSprite('MainBG');
      setProperty('DesksFestival.alpha', 0);

      addLuaSprite('skyMiku',false)
      addLuaSprite('backlightsMiku',false)
      addLuaSprite('concerttopMiku',false)
      addLuaSprite('stadiumMiku',false)
      addLuaSprite('stagefrontMiku',false)
    end
    if curBeat == 100 then
      --soul stage
    end
    if curBeat == 116 then
      addLuaSprite('azulabg', false)
    end
    if curBeat == 132 then
      --black stage fades in
    end
    if curBeat == 133 then
      --text from Yamada and Otori
    end
    if curBeat == 137 then
      --Nino comes in
    end
    if curBeat == 140 then
      --quintuplets
    end
    if curBeat == 147 then
       addLuaSprite('error', false)
    end
    if curBeat == 148 then
      addLuaSprite('wallpaper', false)
      addLuaSprite('window', true)
      removeLuaSprite('error')
    end
    if curBeat == 156 then
      --nene room and ces4r visible
    end
    if curBeat == 184 then
      --helltaker stage
    end
    if curBeat == 200 then
      --soft ddlc stage
    end
    if curBeat == 216 then
      --big tomoe stage
    end
    if curBeat == 232 then
      --nanda stage
    end
    if curBeat == 248 then
      --mako and azuri
    end
end




function onStepHit()
  if curStep == 711 then
    --setProperty('static.alpha', 0.5)
  end
  if curStep == 976 then
    --doTweenAlpha('fadeInn', 'static', 0, 0.5, 'linear')
  end
end
size = 1.6
function onCreate()
--South park

    makeLuaSprite('hallway', 'hallway', -300, -50);
	scaleObject('hallway', 1.2, 1.2);

    makeAnimatedLuaSprite('people', 'people', 120, 550)addAnimationByPrefix('people','dance','people',30,true)
	setScrollFactor('people', 1, 1);
    objectPlayAnimation('people','dance',false)
	scaleObject('people', 0.9, 0.9);

    addLuaSprite('hallway', false);
    addLuaSprite('people', false);
	

--Sinner    
makeLuaSprite('sky-ok', 'onigiri/evening/sky', -400, -400);
setScrollFactor("sky-ok", 0.1, 0.1)


makeLuaSprite('school', 'onigiri/evening/school', -220, -130);
scaleObject("school", 0.9, 0.9)
setScrollFactor("school", 0.9, 0.95)


makeLuaSprite('gate', 'onigiri/evening/gate', -380, 320);
setScrollFactor("gate", 0.95, 0.95)


makeLuaSprite('street', 'onigiri/evening/street', -370, 570);


makeLuaSprite('lightleft', 'onigiri/evening/greenlight', -270, 470);
setBlendMode("lightleft", "add")


makeLuaSprite('lightright', 'onigiri/evening/greenlight', 1320, 470);
setBlendMode("lightright", "add")


makeLuaSprite('treeleft', 'onigiri/evening/treeleft', -340, -140);


makeLuaSprite('treeright', 'onigiri/evening/treeright', 1190, -170);


makeLuaSprite('bushesleft', 'onigiri/evening/bushesleft', -385, 475);


makeLuaSprite('bushesright', 'onigiri/evening/bushesright', 1490, 475);


makeAnimatedLuaSprite('bop2', 'onigiri/evening/bop2', 160, 260);
addAnimationByIndices("bop2", "danceUp", "idle", "0,1,2,3,4,5", 24)
addAnimationByIndices("bop2", "danceDown", "idle", "9,8,7,6,5,4", 24)
setProperty("bop2.color", getColorFromHex("FFD8EB"))
scaleObject("bop2", 0.97, 0.97)


makeAnimatedLuaSprite('bop1', 'onigiri/evening/bop1', -130, 220);
addAnimationByIndices("bop1", "danceUp", "idle", "0,1,2,3,4,5", 24)
addAnimationByIndices("bop1", "danceDown", "idle", "9,8,7,6,5,4", 24)
setProperty("bop1.color", getColorFromHex("FFD8EB"))


makeAnimatedLuaSprite('sanabg', 'onigiri/evening/sana', 540, 160);
addAnimationByIndices("sanabg", "danceUp", "idle", "0,1,2,3,4,5", 24)
addAnimationByIndices("sanabg", "danceDown", "idle", "9,8,7,6,5,4", 24)
setProperty("sanabg.color", getColorFromHex("FFD8EB"))
scaleObject("sanabg", 0.9, 0.9)


makeAnimatedLuaSprite('bop4', 'onigiri/evening/bop4', 1175, 185);
addAnimationByIndices("bop4", "danceUp", "idle", "0,1,2,3,4,5", 24)
addAnimationByIndices("bop4", "danceDown", "idle", "9,8,7,6,5,4", 24)
setProperty("bop4.color", getColorFromHex("FFD8EB"))
scaleObject("bop4", 0.87, 0.87)


makeAnimatedLuaSprite('bop5', 'onigiri/evening/bop5', 1370, 280);
addAnimationByIndices("bop5", "danceUp", "idle", "0,1,2,3,4,5", 24)
addAnimationByIndices("bop5", "danceDown", "idle", "9,8,7,6,5,4", 24)
setProperty("bop5.color", getColorFromHex("FFD8EB"))
scaleObject("bop5", 0.93, 0.93)


makeAnimatedLuaSprite('bop6', 'onigiri/evening/bop6', 1550, 255);
addAnimationByIndices("bop6", "danceUp", "idle", "0,1,2,3,4,5", 24)
addAnimationByIndices("bop6", "danceDown", "idle", "9,8,7,6,5,4", 24)
setProperty("bop6.color", getColorFromHex("FFD8EB"))
scaleObject("bop6", 0.96, 0.96)



--Helluva
makeLuaSprite('bg1', 'weekblitz/nightsky',-1700, -1000)
scaleObject('bg1', size, size)


makeLuaSprite('bg2', 'weekblitz/cityslick',-1700, -1000)
scaleObject('bg2', size, size)


makeLuaSprite('bg3', 'weekblitz/roadtodeath',-1700,-1000)
scaleObject('bg3', size, size)


makeLuaSprite('bg4', 'weekblitz/ground',-1700, -1000)
scaleObject('bg4', size, size)


makeLuaSprite('bg5', 'weekblitz/brickedup',-1700, -1000)
scaleObject('bg5', size, size)


makeLuaSprite('bg6', 'weekblitz/insectguy',-1700, -800)
scaleObject('bg6', size, size)


makeLuaSprite('bg7', 'weekblitz/wall-e',-1700, -1000)
scaleObject('bg7', size, size)


--Re:zero
makeLuaSprite('Lugunica', 'reFunkin/Lugunica', -656, -90);
setScrollFactor('Lugunica', 1.0, 1.0);



--Doki doki <3
    makeLuaSprite('MainBG', 'stage ddlc/DDLCbg', -700, -400);
	setLuaSpriteScrollFactor('MainBG', 1, 0.9);
    scaleObject('MainBG', 1.6, 1.6);

    --makeLuaSprite('DesksFestival', 'stage ddlc/DesksFront', -700, -410);
	--setLuaSpriteScrollFactor('DesksFestival', 1, 0.9);
	--scaleObject('DesksFestival', 1.6, 1.6);
    
    --setProperty('DesksFestival.visible', false)
    


--Kizuna AI
makeLuaSprite('kizuna-ai', 'streaming/KizunaBG', -503, -810)

	scaleObject('kizuna-ai', 2.3, 2.3)


--Rushia my beloved
makeLuaSprite('necrobg', 'russia/motherBG', -700, -470);
	setLuaSpriteScrollFactor('necrobg', 0.9, 0.9);

    makeLuaSprite('necrofg', 'russia/motherFG', -650, -1000);
	setLuaSpriteScrollFactor('necrofg', 0.9, 0.9);
    scaleObject('necrofg', 1, 1.35);

    makeLuaSprite('plants', 'russia/plants', -1000, -600);
    setLuaSpriteScrollFactor('plants', 1.1, 1.1);
	scaleObject('plants', 1.4, 1.4);
    addLuaSprite('plants', true)
    setProperty('plants.visible', false)


--Azula Biack
makeLuaSprite('azulabg', 'streaming/BG_Azula', -400, 50)
scaleObject('azulabg', 2.1, 2.1)


--DDLC act 3
makeLuaSprite('stagebackMon', 'bigmonika/BG',-1000, -300);
	setLuaSpriteScrollFactor('stagebackMon', 1, 0.9);
	scaleObject('stagebackMon', 1.6, 1.7);
	makeLuaSprite('stagefrontMon', 'bigmonika/FG', -1000, -300);
	setLuaSpriteScrollFactor('stagefrontMon', 1, 0.9);
	scaleObject('stagefrontMon', 1.6, 1.7);


--Virtual boy
makeLuaSprite('wall', 'virtual/Wall bg', -1200, -550);
	setLuaSpriteScrollFactor('wall', 0.6, 0.6);

	makeLuaSprite('floorbg', 'virtual/Back Platform', -1200, -550);
	setLuaSpriteScrollFactor('floorbg', 0.75, 0.75);


	makeLuaSprite('bpipes', 'virtual/Back Pipes', -1200, -550);
	setLuaSpriteScrollFactor('bpipes', 0.75, 0.75);

	makeLuaSprite('floor', 'virtual/Main Platform', -1200, -550);
	setLuaSpriteScrollFactor('floor', 1, 1);

	makeLuaSprite('fpipes', 'virtual/Front Pipes', -1200, -550);
	setLuaSpriteScrollFactor('fpipes', 1, 1);

	makeLuaSprite('floating', 'virtual/Corner top Left Pipes', -1400, -400);
	setLuaSpriteScrollFactor('floating', 0.75, 0.75);


--Hell pentagram
makeLuaSprite('Alastor', 'Alastor_pentagram', -500, 380);
setScrollFactor('Alastor', 0.9, 0.9);
scaleObject('Alastor', 1.4, 1.4);

--Snowdin
makeLuaSprite('snowdin', 'Papyrus_BG', -300, 0);
scaleObject('snowdin', 1.15, 1.15)

--Fua la re vivis Scooby
makeLuaSprite('scoob','bg2', -200, 100)
setGraphicSize('scoob', getProperty('bg2.width') * 1.4);




--extra
makeLuaSprite('intro', '')
makeGraphic('intro', screenWidth, screenHeight, '000000')
setObjectCamera('intro', 'other')
addLuaSprite('intro', false)

--makeLuaSprite('holologo', 'holo_triangle_shape', 0, 700);
--setObjectCamera('holologo', 'camHUD')
--scaleObject('holologo', 1.2, 1.2);

--setProperty('holologo.alpha', 0.5)
--addLuaSprite('holologo', true)



makeLuaSprite('MikuNino1', 'quintuplets/MikuNino-arg1', 0, 700);
setObjectCamera('MikuNino1', 'camHUD')
scaleObject('MikuNino1', 0.8, 0.8);


makeLuaSprite('MikuNino2', 'quintuplets/MikuNino-arg2', -20, -100);
setObjectCamera('MikuNino2', 'camHUD')
scaleObject('MikuNino2', 0.8, 0.8);


precacheImage('quintuplets/NinoMikuFightSceneFIXED')


makeLuaSprite('Loony', 'Loona_Static', -1500, 0);
setObjectCamera('Loony', 'camHUD');
addLuaSprite('Loony', true);
scaleObject('Loony', 3, 3);


makeLuaSprite('gray', '')
makeGraphic('gray', screenWidth, screenHeight, '808080')
setObjectCamera('gray', 'camHUD')
setProperty('gray.alpha', 0.5)



makeLuaText('loo', "Y'know? \nI had enough\nof this shit ", 0, -1000, 200);
setTextSize('loo', 100);
setTextFont('loo', 'Metropolische_2016.ttf')
setObjectCamera('loo', 'other');
setTextColor('loo', 'F8F8F8')
addLuaText('loo');

makeLuaSprite('ks', 'russia/killer_scream', 0, 0);
setObjectCamera('ks', 'camHUD');

makeLuaSprite('doki', 'DDLC_Logo', 500, 1000);
setObjectCamera('doki', 'camHUD');
scaleObject('doki', 0.25, 0.25);
addLuaSprite('doki', false);


makeLuaSprite('nira', 'streaming/Nira_static', 100, 1400);    --400
setObjectCamera('nira', 'camHUD');
addLuaSprite('nira', false);


makeLuaSprite('shiona', 'streaming/Pinshi_Shiona_1', 400, 1320);    --320
setObjectCamera('shiona', 'camHUD');
addLuaSprite('shiona', false);


makeLuaSprite('nuly', 'streaming/NulyV2_1', 785, 1390);    --390
setObjectCamera('nuly', 'camHUD');
scaleObject('nuly', 0.5, 0.5);
addLuaSprite('nuly', false);

makeLuaSprite('morningstar', 'reFunkin/TheMorningstar', 1150, 200);    --390
setObjectCamera('morningstar', 'camHUD');
scaleObject('morningstar', 1.5, 1.5);
setProperty('morningstar.origin.y', -20);
setProperty('morningstar.antialiasing', false);
addLuaSprite('morningstar', true);
















makeLuaSprite('Nat1', 'ddlc-sprites/nat/Stand3', 0, 0);    
setObjectCamera('Nat1', 'camHUD');
addLuaSprite('Nat1', false);
setProperty('Nat1.alpha', 0)

makeLuaSprite('Nat2', 'ddlc-sprites/nat/Stand13', 250, 0);    
setObjectCamera('Nat2', 'camHUD');
addLuaSprite('Nat2', false);
setProperty('Nat2.alpha', 0)

makeLuaSprite('Nat3', 'ddlc-sprites/nat/Stand17', 250, 0);    
setObjectCamera('Nat3', 'camHUD');
addLuaSprite('Nat3', false);
setProperty('Nat3.alpha', 0)

makeLuaSprite('Nat4', 'ddlc-sprites/nat/Stand20', 350, 0);    
setObjectCamera('Nat4', 'camHUD');
addLuaSprite('Nat4', false);
setProperty('Nat4.alpha', 0)

makeLuaSprite('Nat5', 'ddlc-sprites/nat/Pose5', -170, 0);    
setObjectCamera('Nat5', 'camHUD');
addLuaSprite('Nat5', false);
setProperty('Nat5.alpha', 0)

makeLuaSprite('Nat6', 'ddlc-sprites/nat/Pose6', -170, -50);    
setObjectCamera('Nat6', 'camHUD');
addLuaSprite('Nat6', false);
setProperty('Nat6.alpha', 0)

makeLuaSprite('Nat7', 'ddlc-sprites/nat/Stand8', -170, 0);    
setObjectCamera('Nat7', 'camHUD');
addLuaSprite('Nat7', false);
setProperty('Nat7.alpha', 0)

makeLuaSprite('Nat8', 'ddlc-sprites/nat/Stand16', 350, 0);    
setObjectCamera('Nat8', 'camHUD');
addLuaSprite('Nat8', false);
setProperty('Nat8.alpha', 0)

makeLuaSprite('Nat9', 'ddlc-sprites/nat/Stand18', 350, -50);    
setObjectCamera('Nat9', 'camHUD');
addLuaSprite('Nat9', false);
setProperty('Nat9.alpha', 0)

makeLuaSprite('Nat10', 'ddlc-sprites/nat/Pose3', 350, -50);    
setObjectCamera('Nat10', 'camHUD');
addLuaSprite('Nat10', false);
setProperty('Nat10.alpha', 0)












makeAnimatedLuaSprite('naenae','dialogue/nene', 1400, 50)
addAnimationByPrefix('naenae','idle','NeneDefault Cheery', 24, true)
scaleObject('naenae', 0.7, 0.7)
setProperty('naenae.flipX', true)
setObjectCamera('naenae', 'camHUD')
addLuaSprite('naenae', true);



makeLuaSprite('stopRightThereCabronHijoDePerra','', 0, 0)
addLuaSprite('stopRightThereCabronHijoDePerra', false)
setObjectCamera('stopRightThereCabronHijoDePerra', 'other')
setProperty('stopRightThereCabronHijoDePerra.alpha', 0)

addHaxeLibrary('MP4Handler','vlc')
addHaxeLibrary('Event','openfl.events')



makeLuaSprite('alastor2', 'Alastor_Normal', 0, 100)
setObjectCamera('alastor2', 'other')
addLuaSprite('alastor2', false)
setProperty('alastor2.alpha', 0)

makeLuaText('alastudtext', "If i wanted to hurt anyone here", 0, 20, 75);
setTextSize('alastudtext', 75);
setTextFont('alastudtext', 'Metropolische_2016.ttf')
setObjectCamera('alastudtext', 'other');
setTextColor('alastudtext', 'FF0000')
addLuaText('alastudtext');
setProperty('alastudtext.alpha', 0)

makeLuaText('hurtalastud', "I would have it done so long", 0, 200, 570);
setTextSize('hurtalastud', 75);
setTextFont('hurtalastud', 'Metropolische_2016.ttf')
setObjectCamera('hurtalastud', 'other');
setTextColor('hurtalastud', 'FF0000')
addLuaText('hurtalastud');
setProperty('hurtalastud.alpha', 0)

--Pre caching
precacheImage('hallway')
precacheImage('people')
precacheImage('onigiri/evening/sky')
precacheImage('onigiri/evening/school')
precacheImage('onigiri/evening/gate')
precacheImage('onigiri/evening/street')
precacheImage('onigiri/evening/greenlight')
precacheImage('onigiri/evening/treeleft')
precacheImage('onigiri/evening/treeright')
precacheImage('onigiri/evening/bushesleft')
precacheImage('onigiri/evening/bushesright')
precacheImage('onigiri/evening/bop2')
precacheImage('onigiri/evening/bop1')
precacheImage('onigiri/evening/sana')
precacheImage('onigiri/evening/bop4')
precacheImage('onigiri/evening/bop5')
precacheImage('onigiri/evening/bop6')
precacheImage('weekblitz/nightsky')
precacheImage('weekblitz/cityslick')
precacheImage('weekblitz/roadtodeath')
precacheImage('weekblitz/ground')
precacheImage('weekblitz/brickedup')
precacheImage('weekblitz/insectguy')
precacheImage('weekblitz/wall-e')
precacheImage('reFunkin/Lugunica')
precacheImage('stage ddlc/DDLCbg')
precacheImage('streaming/KizunaBG')
precacheImage('russia/motherBG')
precacheImage('russia/motherFG')
precacheImage('russia/plants')
precacheImage('streaming/BG_Azula')
precacheImage('bigmonika/BG')
precacheImage('bigmonika/FG')
precacheImage('virtual/Wall bg')
precacheImage('virtual/Back Platform')
precacheImage('virtual/Back Pipes')
precacheImage('virtual/Main Platform')
precacheImage('virtual/Front Pipes')
precacheImage('virtual/Corner top Left Pipes')
precacheImage('Alastor_pentagram')
precacheImage('Papyrus_BG')
precacheImage('bg2')
precacheImage('ddlc-sprites/nat/Stand3')
precacheImage('ddlc-sprites/nat/Stand13')
precacheImage('ddlc-sprites/nat/Stand17')
precacheImage('ddlc-sprites/nat/Stand20')
precacheImage('ddlc-sprites/nat/Pose5')
precacheImage('ddlc-sprites/nat/Pose6')
precacheImage('ddlc-sprites/nat/Stand8')
precacheImage('ddlc-sprites/nat/Stand16')
precacheImage('ddlc-sprites/nat/Stand18')
precacheImage('ddlc-sprites/nat/Pose3')
precacheImage('new')
precacheImage('BLITZONOTE_assets')
precacheImage('NOTE_assets_helluva')
precacheImage('noteSplashesHololive')
precacheImage('noteSplashesDefault')
precacheImage('NOTE_assets_soft')
precacheImage('Rem_Notes')
precacheImage('Rem_Splashes')
precacheImage('noteSplashesSoft')
precacheImage('NOTE_assets_ddlc')
precacheImage('noteSplashes_Doki')
addCharacterToList('cartman', 'dad');
addCharacterToList('kyle', 'boyfriend');
addCharacterToList('okayu-sinner', 'dad');
addCharacterToList('nerd-aloo', 'boyfriend');
addCharacterToList('loona', 'dad');
addCharacterToList('wenamy-player', 'boyfriend');
addCharacterToList('erika', 'dad');
addCharacterToList('rem-player', 'boyfriend');
addCharacterToList('natsuki', 'dad');
addCharacterToList('sayo-speaker', 'gf');
addCharacterToList('yuri-player', 'boyfriend');
addCharacterToList('kizuna-ai-closeup', 'dad');
addCharacterToList('uruha-rushia', 'dad');
addCharacterToList('momosuzu-nene', 'boyfriend');
addCharacterToList('azula-closeup', 'dad');
addCharacterToList('alastor-closeup', 'dad');
addCharacterToList('big-monika', 'dad');
addCharacterToList('bosozoku-nene', 'gf');
addCharacterToList('aloe-speakers', 'gf');

--load scripts
addLuaScript('extra_scripts/Azuri-closeup_chr', false)
addLuaScript('extra_scripts/Nanda-closeup_chr', false)
addLuaScript('extra_scripts/JustMonikaThing', false)
--addLuaScript('extra_scripts/Doubling-down-notes', false)
--addLuaScript('extra_scripts/Doubling-down-splashes', false)
addLuaScript('extra_scripts/SinnerEatingBar', false)

--setSpriteShader("holologo", "ActualMaskShader")

end


function onUpdate()
    setProperty('healthBar.origin.x', 0);
    setProperty('healthBarBG.origin.x', 0);
    --setBlendMode('holo-logo', 'ERASE')


    if dadName == 'okayu-sinner' then
        

        setProperty('health', 2);
    end
    if dadName == 'loona' then
       
    end
    if boyfriendName == 'rem-player' then
        
    end
    if dadName == 'natsuki' then
       
    end
    if dadName == 'kizuna-ai-closeup' then
       
        cameraSetTarget('dad')
    end
    if dadName == 'uruha-rushia' then
        
        
    end
    if dadName == 'azula-closeup' then
       
    end
    if dadName == 'big-monika' then
        
        cameraSetTarget('dad')
    end
    if dadName == 'mrvirtual' then
        
    end
    if dadName == 'alastor-closeup' then
       addLuaSprite('Alastor', false)
       removeLuaSprite('wall', false)
       removeLuaSprite('floorbg', false)
       removeLuaSprite('bpipes', false)
       removeLuaSprite('floor', false)
       removeLuaSprite('fpipes', false)
       removeLuaSprite('floating', false)
    end
    if dadName == 'sans' then
        addLuaSprite('snowdin', false)
        removeLuaSprite('Alastor', false)
    end
    if dadName == 'scoobshow' then
        addLuaSprite('scoob', false)
        removeLuaSprite('snowdin', false)
        cameraSetTarget('dad')
    end
end

speedMod = 1
danced = false

upToDown = {"bop1", "sanabg", "bop5"}
downToUp = {"bop2", "bop4", "bop6"}


function onBeatHit()
    if curBeat %2 == 0 then
    playAnim('bg8', 'idle', true)
    playAnim('bg9', 'idle', true)
    playAnim('bg10', 'idle', true)
    end
    if curBeat % (getProperty('gfSpeed') * speedMod) == 0 then  
        
        if danced then
            for i = 1, #upToDown do
                objectPlayAnimation(upToDown[i], "danceUp", true)
            end

            for i = 1, #downToUp do
                objectPlayAnimation(downToUp[i], "danceDown", true)
            end
        else
            for i = 1, #upToDown do
                objectPlayAnimation(upToDown[i], "danceDown", true)
            end
            
            for i = 1, #downToUp do
                objectPlayAnimation(downToUp[i], "danceUp", true)
            end
        end
        
        danced = not danced
    end

if curBeat == 79 then
    doTweenAlpha('mogumoguyummy', 'neko', 1, 0.5, 'cubeOut')

    --noteTweenDirection('noteTween76', 4, 0, 1, 'backOut')
end
if curBeat == 80 then
doTweenX('eating1', 'healthBar.scale', 0.4, 7, 'linear')
doTweenX('eating2', 'healthBarBG.scale', 0.4, 7, 'linear')
doTweenX('comemelabarra', 'neko', 450, 9, 'linear')


addLuaSprite('sky-ok', false);
        addLuaSprite('school', false);
        addLuaSprite('gate', false);
        addLuaSprite('street', false);
        addLuaSprite('lightleft', false);
        addLuaSprite('lightright', false);
        addLuaSprite('treeleft', false);
        addLuaSprite('treeright', false);
        addLuaSprite('bushesleft', false);
        addLuaSprite('bushesright', false);
        addLuaSprite('bop2', false);
        addLuaSprite('bop1', false);
        addLuaSprite('sanabg', false);
        addLuaSprite('bop4', false);
        addLuaSprite('bop5', false);
        addLuaSprite('bop6', false);
        removeLuaSprite('hallway');
        removeLuaSprite('people');
end

    if curBeat == 112 then
        addLuaSprite('MikuNino1', true)
        doTweenY('ninoup', 'MikuNino1', 0, 0.5, 'backOut')
    end
    if curBeat == 119 then
        removeLuaSprite('MikuNino1')
        addLuaSprite('MikuNino2', true)
        doTweenY('mikuanswer', 'MikuNino2', -50, 0.5, 'cubeOut')
    end
    if curBeat == 124 then
        makeAnimatedLuaSprite('fight','quintuplets/NinoMikuFightSceneFIXED', 0, 0)
		addAnimationByPrefix('fight','quintuplets/NinoMikuFightSceneFIXED','Intro', 24, true)
		addLuaSprite('fight', true);
		setObjectCamera('fight', 'camHUD')
		scaleObject('fight', 1.5, 1.5)
		screenCenter('fight', 'xy')
        doTweenAlpha('byeneko', 'neko', 0, 0.5, 'cubeOut')
    end
   
    
    if curBeat == 128 then
        addLuaSprite('bg1', false);
        addLuaSprite('bg2', false);
        addLuaSprite('bg3', false);
        addLuaSprite('bg4', false);
        addLuaSprite('bg5', false);
        addLuaSprite('bg6', false);
        addLuaSprite('bg7', true);
        addLuaSprite('bg8', false);
        addLuaSprite('bg9', false);
        removeLuaSprite('sky-ok');
        removeLuaSprite('school');
        removeLuaSprite('gate');
        removeLuaSprite('street');
        removeLuaSprite('lightleft');
        removeLuaSprite('lightright');
        removeLuaSprite('treeleft');
        removeLuaSprite('treeright');
        removeLuaSprite('bushesleft');
        removeLuaSprite('bushesright');
        removeLuaSprite('bop2');
        removeLuaSprite('bop1');
        removeLuaSprite('sanabg');
        removeLuaSprite('bop4');
        removeLuaSprite('bop5');
        removeLuaSprite('bop6');

        removeLuaSprite('fight');
        removeLuaSprite('MikuNino2')

        scaleObject('healthBar', 1, 1)
        scaleObject('healthBarBG', 1, 1)
    end
    if curBeat == 152 then
        doTweenX('loonadialogue', 'loo', 100, 0.7, 'backOut')
        doTweenX('comeloona', 'Loony', 270, 0.5, 'backOut')
        doTweenAngle('boingloona', 'Loony', 0, 0.25, 'quadIn')
        addLuaSprite('gray', false)
    end
    if curBeat == 158 then
        doTweenAngle('RemAttacks', 'morningstar', -359, 0.65, 'cubeOut')
    end
    if curBeat == 160 then
        removeLuaSprite('bg1', false);
        removeLuaSprite('bg2', false);
        removeLuaSprite('bg3', false);
        removeLuaSprite('bg4', false);
        removeLuaSprite('bg5', false);
        removeLuaSprite('bg6', false);
        removeLuaSprite('bg7', true);
        removeLuaSprite('bg8', false);
        removeLuaSprite('bg9', false);
        addLuaSprite('Lugunica', false);


        removeLuaSprite('Loony')
        removeLuaText('loo')
        removeLuaSprite('gray')
    end
    if curBeat == 188 then
        doTweenY('dokilogohewo', 'doki', 225, 0.7, 'backOut')
        doTweenAngle('dokilogoangle', 'doki', 0, 0.5, 'cuartOut')

    end
    if curBeat == 190 then
        doTweenX('dokilogoscale1', 'doki.scale', 2, 1.1, 'backInOut')
        doTweenY('dokilogoscale2', 'doki.scale', 2, 1.1, 'backInOut')
    end
    if curBeat == 192 then
        doTweenAlpha('byedoki', 'doki', 0, 0.5, 'cubeOut')
        

        removeLuaSprite('Lugunica', false);
        addLuaSprite('MainBG', false);
        addLuaSprite('DesksFestival', true);
        setProperty('DesksFestival.visible', true)
    end
    if curBeat == 224 then
        addLuaSprite('kizuna-ai', false)
        removeLuaSprite('MainBG', false);
        removeLuaSprite('DesksFestival', false);
        setProperty('DesksFestival.visible', false)
    end
    if curBeat == 256 then
        addLuaSprite('ks', false);

        removeLuaSprite('kizuna-ai', false)
        addLuaSprite('necrobg', false)
        addLuaSprite('necrofg', false)
    end
    if curBeat == 257 then
        doTweenX('konnene', 'naenae', 350, 0.35, 'cubeOut')
    end
    if curBeat == 258 then
        doTweenX('byenene', 'naenae', -750, 0.35, 'backIn')
    end
    if curBeat == 260 then
        doTweenAlpha('loadingshit', 'ks', 0, 0.5, 'linear')
    end
    if curBeat == 291 then
        doTweenY('niraappears', 'nira', 440, 0.5, 'backOut')
    end
    if curBeat == 292 then
        addLuaSprite('azulabg', false)
        removeLuaSprite('necrobg', false)
        removeLuaSprite('necrofg', false)
        removeLuaSprite('plants', false)
    end
    if curBeat == 299 then
        doTweenX('AzulaMove1', 'dad', -430, 0.7, 'backInOut')
        doTweenX('AzuriCome', 'big-azuri', 70, 0.7, 'backOut')
    end
    if curBeat == 300 then
        doTweenY('shionaappears', 'shiona', 360, 0.5, 'backOut')
    end
    if curBeat == 310 then
        doTweenX('AzulaMove2', 'dad', -670, 0.7, 'backInOut')
        doTweenX('AzuriMove', 'big-azuri', -280, 0.7, 'backOut')
        doTweenX('NandaCome', 'big-nanda', 430, 0.7, 'backOut')
    end
    if curBeat == 311 then
        doTweenY('nulyappears', 'nuly', 430, 0.5, 'backOut')
    end
    if curBeat == 314 then
        doTweenAlpha('mousein', 'doki_cursor', 1, 0.5, 'linear')
    end
    if curBeat == 318 then
        doTweenY('just-monika', 'doki_button', 225, 0.25, 'cubeOut')
    end
    if curBeat == 322 then
        makeLuaText('del', "Deleting: stage = AzulaBG", 0, 0, 25);
        setTextSize('del', 25);
        setObjectCamera('del', 'other');
        addLuaText('del');
    end
    if curBeat == 324 then
        removeLuaSprite('big-azuri')
        removeLuaSprite('big-nanda')
        removeLuaSprite('nira')
        removeLuaSprite('shiona')
        removeLuaSprite('nuly')
        removeLuaText('del')


        removeLuaSprite('azulabg', false)
        addLuaSprite('stagebackMon', false)
        addLuaSprite('stagefrontMon', false)
    end
    if curBeat == 356 then
        addLuaSprite('wall', false)
        addLuaSprite('floorbg', false)
        addLuaSprite('bpipes', false)
        addLuaSprite('floor', false)
        addLuaSprite('fpipes', false)
        addLuaSprite('floating', false)
        removeLuaSprite('stagebackMon', false)
        removeLuaSprite('stagefrontMon', false)
    end


    if curBeat == 388 then
        setProperty('intro.alpha', 1)
        setProperty('alastor2.alpha', 1)
        setProperty('alastudtext.alpha', 1)
    end
    if curBeat == 396 then
        runHaxeCode([[
            var filepath = Paths.video('AlastorDoublingDown');		
            var video = new MP4Handler();
            video.playVideo(filepath);
            video.visible = false;
            setVar('video',video);
            FlxG.stage.removeEventListener('enterFrame', video.update); 
        ]])

        doTweenAlpha('alastorwonthurtanyone', 'stopRightThereCabronHijoDePerra', 1, 0.7, 'cubeOut')
        doTweenAlpha('alastud123', 'alastor2', 0, 0.25, 'cubeOut')
        doTweenAlpha('alastud1234', 'alastudtext', 0, 0.25, 'cubeOut')
        doTweenAlpha('alastud12345', 'hurtalastud', 1, 0.5, 'cubeOut')
    end
    if curBeat == 403 then
        doTweenAlpha('byealastud', 'stopRightThereCabronHijoDePerra', 0, 0.7, 'cubeOut')
        doTweenAlpha('byeblackthing', 'intro', 0, 0.7, 'cubeOut')
        doTweenAlpha('hurtbyebye', 'hurtalastud', 0, 0.7, 'cubeOut')
    end
end

function onSongStart()
    doTweenAlpha('startdasong', 'intro', 0, 7, 'quadIn')
    doTweenAngle('loonaangle', 'Loony', 25, 0.01, 'quadIn')
    doTweenAngle('dokilogostart', 'doki', 37, 0.01, 'quadIn')
end



function onEvent(name, v1, v2)
    if name == 'Blank Event' then
        if v1 == 'bye' then
            doTweenY('byep1', 'iconP1', getProperty('iconP1.y') +250, 0.2, 'backIn')
            doTweenY('byep2', 'iconP2', getProperty('iconP2.y') +250, 0.2, 'backIn')
            doTweenY('byew1', 'winningIconBf', getProperty('winningIconBf.y') +250, 0.2, 'backIn')
            doTweenY('byew2', 'winningIconDad', getProperty('winningIconDad.y') +250, 0.2, 'backIn')
            doTweenY('byehb', 'healthBar', getProperty('healthBar.y') +250, 0.27, 'backIn')
            doTweenY('byebg', 'healthBarBG', getProperty('healthBarBG.y') +250, 0.27, 'backIn')
            doTweenAngle('hbRem', 'healthBar', 1800, 0.2, 'circInOut')
            doTweenAngle('bgRem', 'healthBarBG', 1800, 0.2, 'circInOut')
        end
        if v1 == 'back' then
            doTweenY('backing1', 'iconP1', getProperty('iconP1.y') -250, 1, 'circInOut')
            doTweenY('backing2', 'iconP2', getProperty('iconP2.y') -250, 1, 'cubeInOut')
            doTweenY('backing3', 'winningIconBf', getProperty('winningIconBf.y') -250, 1, 'quartInOut')
            doTweenY('backing4', 'winningIconDad', getProperty('winningIconDad.y') -250, 1, 'quintInOut')
            doTweenY('backing5', 'healthBar', getProperty('healthBar.y') -250, 1, 'backInOut')
            doTweenY('backing6', 'healthBarBG', getProperty('healthBarBG.y') -250, 1, 'bounceInOut')
        end
        if v1 == 'rem' then
            playSound('Rem_MorningstarAttack', 0.7)
        end
        if v1 == 'scooby' then
            playSound('ScoobyBite', 1)
            setProperty('camHUD.alpha', 0)
            setProperty('camGame.alpha', 0)
        end
    end
end


function onDestroy()
    setProperty('camGame.alpha', 1)
end


function onUpdatePost()
    
    runHaxeCode([[
        var video = getVar('video');
        game.getLuaObject('stopRightThereCabronHijoDePerra').loadGraphic(video.bitmapData);
        video.volume = FlxG.sound.volume - 100;	
        if(game.paused)video.pause();
    ]])
end


function onResume()
    runHaxeCode([[
        var video = getVar('video');
        video.resume();
    ]])
end






function onStepHit()
    if curStep == 896 then
        setProperty('Nat1.alpha', 1)
        doTweenX('naty', 'Nat1', 250, 0.5, 'cubeIn')
    end
    if curStep == 903 then
        doTweenX('naty1', 'Nat1.scale', 0.0001, 0.25, 'quadOut')
        doTweenX('naty1.5', 'Nat2.scale', 0.0001, 0.25, 'quadOut')
    end
    if curStep == 904 then
        setProperty('Nat1.alpha', 0)
        setProperty('Nat2.alpha', 1)
        doTweenX('naty1.7', 'Nat2.scale', 1, 0.2, 'quadOut')
    end
    if curStep == 912 then
        setProperty('Nat2.alpha', 0)
        setProperty('Nat3.alpha', 1)
        doTweenX('naty2', 'Nat3', 350, 0.4, 'backIn')
    end
    if curStep == 920 then
        setProperty('Nat3.alpha', 0)
        setProperty('Nat4.alpha', 1)
        doTweenX('naty3', 'Nat4', -170, 0.55, 'smoothStepIn')
    end
    if curStep == 944 then
        setProperty('Nat4.alpha', 0)
        setProperty('Nat5.alpha', 1)
    end
    if curStep == 952 then
        setProperty('Nat5.alpha', 0)
        setProperty('Nat6.alpha', 1)
        doTweenY('naty4', 'Nat6', 0, 0.1, 'cubeIn')
    end
    if curStep == 960 then
        setProperty('Nat6.alpha', 0)
        setProperty('Nat7.alpha', 1)
        doTweenX('naty5', 'Nat7', 350, 0.45, 'quarterIn')
    end
    if curStep == 984 then
        setProperty('Nat7.alpha', 0)
        setProperty('Nat8.alpha', 1)
    end
    if curStep == 992 then
        setProperty('Nat8.alpha', 0)
        setProperty('Nat9.alpha', 1)
        doTweenY('naty6', 'Nat9', 0, 0.1, 'cubeIn')
    end
    if curStep == 1008 then
        setProperty('Nat9.alpha', 0)
        setProperty('Nat10.alpha', 1)
        doTweenY('naty7', 'Nat10', 0, 0.1, 'cubeIn')
    end
    if curStep == 1010 then
        doTweenX('naty-byebye', 'Nat10', -1000, 1, 'backInOut')
    end
    if curStep == 1020 then
        removeLuaSprite('Nat1')
        removeLuaSprite('Nat2')
        removeLuaSprite('Nat3')
        removeLuaSprite('Nat4')
        removeLuaSprite('Nat5')
        removeLuaSprite('Nat6')
        removeLuaSprite('Nat7')
        removeLuaSprite('Nat8')
        removeLuaSprite('Nat9')
        removeLuaSprite('Nat10')
    end
end
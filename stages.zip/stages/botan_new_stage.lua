--made with Super_Hugo's Stage Editor

function onCreate()

	makeLuaSprite('obj1', 'holofunk_week3stage/bg_sky', -580, -283)

	setObjectOrder('obj1', 0)
	scaleObject('obj1', 1.2, 1.2)

	addLuaSprite('obj1', true)


	makeLuaSprite('obj2', 'holofunk_week3stage/bg_city', -580, -17)

	setObjectOrder('obj2', 1)
	scaleObject('obj2', 1.2, 1.2)

	addLuaSprite('obj2', true)


	makeLuaSprite('obj3', 'holofunk_week3stage/light_blue', -583, 73)

	setObjectOrder('obj3', 2)
	scaleObject('obj3', 1.2, 1.2)

	addLuaSprite('obj3', true)


	makeLuaSprite('obj4', 'holofunk_week3stage/bridge', -580, 347)

	setObjectOrder('obj4', 3)
	scaleObject('obj4', 1.2, 1.2)

	addLuaSprite('obj4', true)


	makeLuaSprite('obj5', 'holofunk_week3stage/street', -586, 870)

	setObjectOrder('obj5', 4)
	scaleObject('obj5', 1.2, 1.2)

	addLuaSprite('obj5', true)

end
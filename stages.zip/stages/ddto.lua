function onCreate()
	
	makeLuaSprite('MainBG', 'stage ddlc/DDLCbg', -700, -490);
	setLuaSpriteScrollFactor('MainBG', 1, 0.9);
    scaleObject('MainBG', 1.6, 1.6);
    addLuaSprite('MainBG', false);

    makeLuaSprite('DesksFestival', 'stage ddlc/DesksFront', -700, -500);
	setLuaSpriteScrollFactor('DesksFestival', 1, 0.9);
	scaleObject('DesksFestival', 1.6, 1.6);
    addLuaSprite('DesksFestival', false);

    makeLuaSprite('icons', 'full_black',100, 50);
	addLuaSprite('icons', false);

    makeLuaSprite('icons2', 'full_black',100, 50);
	addLuaSprite('icons2', false);
    scaleObject('icons2', 1.6, 1.6);
    setObjectOrder('icons2',123);

    setProperty('DesksFestival.visible', false)
    setProperty('icons.visible', false)
    setProperty('icons2.visible', false)

    end

	function onEvent(name,value1,value2)
		if name == 'Play Animation' then 
			
			if value1 == 'takeover' then
            playSound('glitchin', 1);
			setProperty('MainBG.visible', true);
            setProperty('DesksFestival', true);
            setProperty('icons', false)
            setProperty('icons2', false)
	    end
			if value1 == 'off' then
		    playSound('Lights_Shut_off', 1);
			setProperty('MainBG.visible', false);
            setProperty('DesksFestival', false);
            setProperty('icons', true)
            setProperty('icons2', true)
	    end
    end
end
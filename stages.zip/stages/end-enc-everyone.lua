--made with Super_Hugo's Stage Editor

function onCreate()

	makeLuaSprite('obj1', 'funstage/fun', -372, -176)

	setObjectOrder('obj1', 0)

	addLuaSprite('obj1', true)


	makeLuaSprite('obj2', 'quintuplets/gotoubun-5_stage_sunset', -507, -374)

	setObjectOrder('obj2', 1)

	addLuaSprite('obj2', true)


	makeLuaSprite('obj3', 'badending/ClosetBG', -204, -171)

	setObjectOrder('obj3', 2)
	scaleObject('obj3', 1.1, 1.1)

	addLuaSprite('obj3', true)


	makeLuaSprite('obj4', 'streaming/BG_azuri', -387, -324)

	setObjectOrder('obj4', 3)
	scaleObject('obj4', 1.2, 1.2)

	addLuaSprite('obj4', true)


	makeLuaSprite('obj5', 'russia/motherBG', -480, -394)

	setObjectOrder('obj5', 4)

	addLuaSprite('obj5', true)


	makeLuaSprite('obj6', 'russia/motherFG', -564, -574)

	setObjectOrder('obj6', 5)

	addLuaSprite('obj6', true)


	makeLuaSprite('obj7', 'streaming/KizunaBG', -407, -537)

	setObjectOrder('obj7', 6)
	scaleObject('obj7', 1.9, 1.9)

	addLuaSprite('obj7', true)


	makeLuaSprite('obj8', 'mashup/botanStage', -533, -455)

	setObjectOrder('obj8', 7)

	addLuaSprite('obj8', true)


	makeLuaSprite('obj9', 'week1D/stage_auditions_sus', -593, -531)

	setObjectOrder('obj9', 8)
	scaleObject('obj9', 2.5, 2.5)

	addLuaSprite('obj9', true)


	makeLuaSprite('obj10', 'stage ddlc/DDLCbg', -885, -615)

	setObjectOrder('obj10', 9)
	scaleObject('obj10', 1.8, 1.8)

	addLuaSprite('obj10', true)


	precacheImage('majinthing/Majin_Notes')
	precacheImage('majinthing/Majin_Splashes')
	precacheImage('majinthing/three')
	precacheImage('majinthing/two')
	precacheImage('majinthing/one')
	precacheImage('majinthing/go')


	setProperty('skipCountdown', true)

end

function onBeatHit()
	if curBeat == 578 then
		doTweenX('dadTweenX', 'gf', 230, 0.50, 'linear');
	end
    if curBeat == 656 then
		doTweenX('dadTweenX', 'dad', 100, 1, 'linear');
		doTweenY('dadTweenX', 'gf', 130, 1, 'linear');
	end
end
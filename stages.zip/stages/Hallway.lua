function onCreate()

    makeLuaSprite('hallway', 'hallway', -300, -50);
	scaleObject('hallway', 1.2, 1.2);

    makeAnimatedLuaSprite('people', 'people', 120, 550)addAnimationByPrefix('people','dance','people',30,true)
	setScrollFactor('people', 1, 1);
    objectPlayAnimation('people','dance',false)
	scaleObject('people', 0.9, 0.9);

    addLuaSprite('hallway', false);
    addLuaSprite('people', false);
	
	close(true);
end
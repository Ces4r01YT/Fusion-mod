function onCreate()

	makeAnimatedLuaSprite('bg', 'misery/Misery_Stage',100, 50);
	addLuaSprite('bg', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('blank_bg', 'idle', 'Stage Idle', 24, true);
	
	makeAnimatedLuaSprite('trend', 'misery/Misery_Stage',100, 50);
	addLuaSprite('trend', false); --Added offscreen before it starts moving.
	addAnimationByPrefix('trend', 'idle', 'That Part', 10, true);

	setProperty('trend.visible', false)

    end

	function onEvent(name,value1,value2)
		if name == 'Play Animation' then 
			
			if value1 == 'tiktok' then
            playSound('Shine Holo SFX', 1, 'That Part');
			setProperty('bg.visible', false);
			setProperty('trend.visible', true);
	    end
			if value1 == 'off' then
		    playSound('Shine Holo SFX', 1, 'Stage Idle');
			setProperty('bg.visible', true);
			setProperty('trend.visible', false);
	    end
    end
end
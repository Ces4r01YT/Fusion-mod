function onCreate()
	--background boi
	makeLuaSprite('bg', 'bg_week_3_sky', -274, -137)
	setScrollFactor('bg', 0.1, 0.1)
	scaleObject('bg', 1.5, 1.5)

	makeLuaSprite('city', 'bg_week_3_city', -250, 310);
	setScrollFactor('city', 0.2, 0.2);
	scaleObject('city', 1.4, 1.4);

	makeLuaSprite('streetBehind', 'behindTrain', -140, -50);

	makeLuaSprite('station', 'bg_week_3', -270, -15);
	scaleObject('station', 1.7, 1.7);

	makeAnimatedLuaSprite('trainBop', 'boppers', -200, 330)
    addAnimationByPrefix('trainBop', 'boping', 'bop', 24, true)
	scaleObject('trainBop', 1.5, 1.5);

	makeLuaSprite('street', 'bg_week_3_street', -270, -15);
	scaleObject('street', 1.7, 1.7);

	makeLuaSprite('MainBG', 'stage festival/MainBG', -700, -490);
	setLuaSpriteScrollFactor('MainBG', 1, 0.9);
    scaleObject('MainBG', 1.6, 1.6);

	makeLuaSprite('FestivalBanner', 'stage festival/FestivalBanner', -700, -440);
	setLuaSpriteScrollFactor('FestivalBanner', 1, 0.9);
	scaleObject('FestivalBanner', 1.6, 1.6);

    makeLuaSprite('DesksFestival', 'stage festival/DesksFestival', -700, -500);
	setLuaSpriteScrollFactor('DesksFestival', 1, 0.9);
	scaleObject('DesksFestival', 1.6, 1.6);
	
	makeLuaSprite('FarBack', 'stage festival/FarBack', -700, -500);
	setLuaSpriteScrollFactor('FarBack', 1, 0.9);
	scaleObject('FarBack', 1.6, 1.6);

	addLuaSprite('bg', false);
	addLuaSprite('city', false);
	addLuaSprite('streetBehind', false);
	addLuaSprite('station', false);
	addLuaSprite('trainBop', false);
	addLuaSprite('phillyTrain', false);
	addLuaSprite('street', false);
	addLuaSprite('MainBG', false);
	addLuaSprite('FestivalBanner', false);
	addLuaSprite('DesksFestival', false);
	addLuaSprite('FarBack', false);

	setProperty('MainBG.visible', false)
	setProperty('FestivalBanner.visible', false)
	setProperty('DesksFestival.visible', false)
	setProperty('FarBack.visible', false)
	
end

function onEvent(name,value1,value2)
	if name == 'Play Animation' then 
		
		if value1 == 'changebg1' then
			setProperty('bg.visible', false);
			setProperty('city.visible', false);
			setProperty('streetBehind.visible', false);
			setProperty('trainBop.visible', false);
	        setProperty('street.visible', false);
			setProperty('MainBG.visible', true);
			setProperty('FestivalBanner.visible', true);
			setProperty('DesksFestival.visible', true);
			setProperty('FarBack.visible', true);
		end
		if value1 == 'changebg2' then
			setProperty('bg.visible', true);
			setProperty('city.visible', true);
			setProperty('streetBehind.visible', true);
			setProperty('trainBop.visible', true);
	        setProperty('street.visible', true);
			setProperty('MainBG.visible', false);
			setProperty('FestivalBanner.visible', false);
			setProperty('DesksFestival.visible', false);
			setProperty('FarBack.visible', false);
		end
	end
end
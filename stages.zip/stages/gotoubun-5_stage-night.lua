﻿function onCreate()
	-- background shit
	makeLuaSprite('gotoubun-5_stage', 'quintuplets/gotoubun-5_stage_night', -400, -400);
	setScrollFactor('gotoubun-5_stage', 0.9, 0.9);

	addLuaSprite('gotoubun-5_stage', false);

	close(true); --For performance reasons, close this script once the stage is fully loaded, as this script won't be used anymore after loading the stage
end
function onCreate()
	makeLuaSprite('city', 'stage3_holo', -500, -350);
	scaleObject('city', 1.9, 1.95);
	addLuaSprite('city', false);

	makeAnimatedLuaSprite('chibinuly', 'streaming/NulyChibiV2_actions', 0, 400)
	addAnimationByPrefix('chibinuly', 'Idle', 'nuly_idle', 24, false);
	addAnimationByPrefix('chibinuly', 'Talk', 'nuly_talk', 24, false);
	setProperty('chibinuly.flipX', true)
	--scaleObject('chibinuly', 0.275, 0.275)
	objectPlayAnimation('chibinuly', 'Idle', true)
	addLuaSprite('chibinuly', true)
	setProperty('chibinuly.alpha', 0)



	makeLuaSprite('asd', '', -420, -50)
	makeGraphic('asd', 12000, 1200, 'FFFFFF')
	scaleObject('asd', 1.25, 1.25)
	--setObjectCamera('asd', 'other')
	--addLuaSprite('asd', false)


	addLuaScript('extra_scripts/Holofunk-hud-nostrums', false)
end

function boopingChibi()
	doTweenX('nulybopXR1', 'chibinuly', 25, 0.25, 'quarterIn')
	doTweenY('nulybopYR1', 'chibinuly', 450, 0.25, 'cubeIn')
    runTimer('talkingNuly', 1)
	objectPlayAnimation('chibinuly', 'Talk', true)
end

function onTimerCompleted(tag)
	if tag == 'talkingNuly' then
		objectPlayAnimation('chibinuly', 'Idle', true)
    end
end

function onUpdate()
	if dadName == 'mako7w7-closeup' then
		setProperty('boyfriend.alpha', 0)
		setProperty('gf.alpha', 0)
		setProperty('trailBF.alpha', 0)
		setProperty('trailDad.alpha', 0)
	end
end


function onBeatHit()
    if curBeat == 196 then
	setProperty('dad.color', '000000')
	addLuaSprite('asd', false)
    end
	if curBeat == 204 then
		doTweenColor('MakoComesBack', 'dad', 'FFFFFF', 25, 'quadIn')
	end
    if curBeat == 264 then
	removeLuaSprite('asd')
	setProperty('chibinuly.alpha', 1)
	setProperty('boyfriend.alpha', 1)
	setProperty('gf.alpha', 1)
	end
    if curBeat == 266 then
    boopingChibi()
    end
	if curBeat == 270 then
		boopingChibi()
	end
	if curBeat == 277 then
		boopingChibi()
    end
	if curBeat == 279 then
		boopingChibi()
    end
	if curBeat == 284 then
		boopingChibi()
    end
	if curBeat == 286 then
		boopingChibi()
    end
	if curBeat == 293 then
		boopingChibi()
    end
	if curBeat == 298 then
		boopingChibi()
    end
	if curBeat == 302 then
		boopingChibi()
    end
	if curBeat == 308 then
		boopingChibi()
    end
	if curBeat == 310 then
		boopingChibi()
    end
	if curBeat == 317 then
		boopingChibi()
    end
	if curBeat == 319 then
		boopingChibi()
    end
	if curBeat == 323 then
		boopingChibi()
    end
	if curBeat == 325 then
		boopingChibi()
    end
	if curBeat == 327 then
		boopingChibi()
    end
end


function onTweenCompleted(tag)
	if tag == 'nulybopXR1' then
		doTweenX('nulybopXR2', 'chibinuly', 0, 0.25, 'cubeIn')
	end
	if tag == 'nulybopYR1' then
		doTweenY('nulybopYR2', 'chibinuly', 400, 0.25, 'quarterIn')
	end
	if tag == 'nulybopXR2' then
		doTweenX('nulybopXR3', 'chibinuly', -25, 0.25, 'quarterIn')
	end
	if tag == 'nulybopYR2' then
		doTweenY('nulybopYR3', 'chibinuly', 450, 0.25, 'cubeIn')
	end
	if tag == 'nulybopXR3' then
		doTweenX('nulybopXR4', 'chibinuly', 0, 0.25, 'cubeIn')
	end
	if tag == 'nulybopYR3' then
		doTweenY('nulybopYR4', 'chibinuly', 400, 0.25, 'quarterIn')
	end
end

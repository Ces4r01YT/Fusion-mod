function onCreate()

	makeLuaSprite('gotoubun-5_stage', 'quintuplets/gotoubun-5_stage', -400, -400);
	addLuaSprite('gotoubun-5_stage', false);

	makeLuaSprite('stagebackRussia', 'russia/motherBG', -700, -800);
	setLuaSpriteScrollFactor('stagebackRussia', 0.9, 0.9);
	scaleObject('stagebackRussia', 1.1, 1.1);

	makeLuaSprite('stagefrontRussia', 'russia/motherFG', -650, -800);
	setLuaSpriteScrollFactor('stagefrontRussia', 0.9, 0.9);
	scaleObject('stagefrontRussia', 1.1, 1.1);

	makeLuaSprite('plantsRussia', 'russia/plants', -1000, -1200);

	scaleObject('plantsRussia', 1.4, 1.4);

	addLuaSprite('stagebackRussia', false);
	addLuaSprite('stagefrontRussia', false);
	addLuaSprite('plantsRussia',true);

	makeLuaSprite('skyPhilly','philly2/sky', -100, 00);
	setLuaSpriteScrollFactor('skyPhilly', 0.1, 0.1);
		
	makeLuaSprite('cityPhilly','philly2/cityHF', -10, 0);
	setLuaSpriteScrollFactor('cityPhilly', 0.3, 0.3);
	scaleObject('cityPhilly', 0.85, 0.85);
	makeLuaSprite('lightPhilly', 'philly2/win0',-10, 0);
    setLuaSpriteScrollFactor('lightPhilly', 0.3, 0.3);		
	scaleObject('lightPhilly',0.85, 0.85);
	makeLuaSprite('behindTrainPhilly','philly2/behindTrain', -40, 50);
	makeLuaSprite('streetPhilly','philly2/street2', -40, 50);

	addLuaSprite('skyPhilly', false);
	addLuaSprite('cityPhilly', false);
	addLuaSprite('lightPhilly', false); --Added offscreen before it starts moving.
	addLuaSprite('behindTrainPhilly', false);
	addLuaSprite('streetPhilly', false);

	makeLuaSprite('stagebackHolo', 'holoweek1/stageback', -500, -300);
	setLuaSpriteScrollFactor('stagebackHolo', 0.9, 0.9);
	
	makeLuaSprite('stagefrontHolo', 'holoweek1/stagefront', -650, 600);
	setLuaSpriteScrollFactor('stagefrontHolo', 0.9, 0.9);
	scaleObject('stagefrontHolo', 1.1, 1.1);


	addLuaSprite('stagebackHolo', false);
	addLuaSprite('stagefrontHolo', false);

	makeLuaSprite('MainBGdoki', 'stage ddlc/DDLCbg', -700, -490);
	setLuaSpriteScrollFactor('MainBGdoki', 1, 0.9);
    scaleObject('MainBGdoki', 1.6, 1.6);

    makeLuaSprite('DesksFestival', 'stage ddlc/DesksFront', -700, -500);
	setLuaSpriteScrollFactor('DesksFestival', 1, 0.9);
	scaleObject('DesksFestival', 1.6, 1.6);
	
	makeLuaSprite('FarBack', 'stage festival/FarBack', -700, -500);
	setLuaSpriteScrollFactor('FarBack', 1, 0.9);
	scaleObject('FarBack', 1.6, 1.6);    

    addLuaSprite('MainBGdoki', false);
	addLuaSprite('DesksFestival', false);
	addLuaSprite('FarBack', false);

	makeLuaSprite('videocall', 'mashup/CallChikaKizunaBG', -400, -400);
	addLuaSprite('videocall', false);

	makeLuaSprite('callFG', 'mashup/CallChikaKizunaBG', -400, -400);
	addLuaSprite('callFG', false);

    makeLuaSprite('Lugunica', 'Lugunica', -256, -100);
	setScrollFactor('Lugunica', 1.0, 1.0);

	addLuaSprite('Lugunica', false);

	makeLuaSprite('stagebackTari', 'smg4/stageback_tari', -500, -300);
	setLuaSpriteScrollFactor('stagebackTari', 0.9, 0.9);
	
	makeLuaSprite('stagefrontTari', 'smg4/stagefront_tari', -650, 600);
	setLuaSpriteScrollFactor('stagefrontTari', 0.9, 0.9);
	scaleObject('stagefrontTari', 1.1, 1.1);

	addLuaSprite('stagebackTari', false);
	addLuaSprite('stagefrontTari', false);

	makeLuaSprite('sky','station/bg_week_3_sky',-250,0);
		
	scaleObject('sky',1.5,  1.5);
		
	makeLuaSprite('city','station/bg_week_3_city', -180, 210);
	setLuaSpriteScrollFactor('city', 0.1, 0.1);
	scaleObject('city',1.4,  1.4);
	
	makeLuaSprite('behindTrain','station/behindTrain', -140, 50);
		
	makeLuaSprite('station2','station/bg_week_3', -250, -50);
	scaleObject('station2',1.5,  1.7);
	makeAnimatedLuaSprite('bop', 'station/boppers',  -250, 400);
	scaleObject('bop', 1.5, 1.5);

	makeLuaSprite('street','station/bg_week_3_street', -250, 40);
	scaleObject('street',1.5,  1.5);

	addLuaSprite('sky', false);
	addLuaSprite('city', false);
	addLuaSprite('behindTrain', false);
	addLuaSprite('station2', false);
	addLuaSprite('bop', false);
	addAnimationByPrefix('bop', 'idle', 'bop', 24, true);
	addLuaSprite('street', false);
	runTimer('trainsound',4)

	makeLuaSprite('stagebackb3', 'Week1 B3/Stadium', -700, -300);
	setLuaSpriteScrollFactor('stagebackb3', 0.9, 0.9);
	makeAnimatedLuaSprite('b', 'Week1 B3/dcameos',-700, -600);
    setLuaSpriteScrollFactor('b',0.9, 0.9);

	addLuaSprite('stageback', false);
	addLuaSprite('b', false);
    addAnimationByPrefix('b','idle','bop',24,true);

    makeLuaSprite('trees1', 'exep3/Trees', -607, -401)
    addLuaSprite('trees1')
    setScrollFactor('trees1', 0.95, 1)
    setGraphicSize('trees1', getProperty('trees1.width') * 1.2)

    makeLuaSprite('trees2', 'exep3/Trees2', -623, -410)
    setGraphicSize('trees2', getProperty('trees2.width') * 1.2)
    addLuaSprite('trees2', false)

    makeLuaSprite('grass', 'exep3/Grass', -630, -266)
    addLuaSprite('grass', false)
    setGraphicSize('grass', getProperty('grass.width') * 1.2)

end

function onSongStart()
	setProperty("skipCountdown", true)
	setProperty('stagebackRussia.alpha', 0)
	setProperty('stagefrontRussia.alpha', 0)
	setProperty('plantsRussia.alpha', 0)
	setProperty('skyPhilly.alpha', 0)
	setProperty('cityPhilly.alpha', 0)
	setProperty('lightPhilly.alpha', 0)
	setProperty('behindTrainPhilly.alpha', 0)
	setProperty('streetPhilly.alpha', 0)
	setProperty('stagebackHolo.alpha', 0)
	setProperty('stagefrontHolo.alpha', 0)
	setProperty('MainBGdoki.alpha', 0)
	setProperty('DesksFestival.alpha', 0)
	setProperty('FarBack.alpha', 0)
	setProperty('videocall.alpha', 0)
	setProperty('callFG.alpha', 0)
	setProperty('Lugunica.alpha', 0)
	setProperty('stagebackTari.alpha', 0)
	setProperty('stagefrontTari.alpha', 0)
	setProperty('sky.alpha', 0)
	setProperty('city.alpha', 0)
	setProperty('behindTrain.alpha', 0)
	setProperty('station2.alpha', 0)
	setProperty('bop.alpha', 0)
	setProperty('street.alpha', 0)
	setProperty('stagebackb3.alpha', 0)
	setProperty('b.alpha', 0)
	setProperty('trees1.alpha', 0)
	setProperty('trees2.alpha', 0)
	setProperty('grass.alpha', 0)
end
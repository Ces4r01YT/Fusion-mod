function onCreate()
	makeLuaSprite('bgFIX', 'quintuplets/gotoubun-5_stage_sunset', -70, -400);

	makeLuaSprite('fg', 'quintuplets/gotoubun-1_sister', -70, -400);

	makeLuaSprite('bars', 'insanityStage/bars', 0, 0);
	setProperty('bars.antialiasing', true)
	setObjectCamera('bars', 'camHUD')


	addLuaSprite('bgFIX', false);
	
	addLuaSprite('bars', true);


	makeLuaSprite('nino', 'quintuplets/MurderIchikaPannel1', 800, 900)
	addLuaSprite('nino', true)
	scaleObject('nino', 0.7, 0.7)
	setObjectCamera('nino', 'other')

	makeLuaSprite('miku', 'quintuplets/MurderIchikaPannel2', 600, 900)
	addLuaSprite('miku', true)
	setObjectCamera('miku', 'other')

	makeLuaSprite('yot', 'quintuplets/MurderIchikaPannel3', 400, 900)
	addLuaSprite('yot', true)
	setObjectCamera('yot', 'other')

	makeLuaSprite('itsu', 'quintuplets/MurderIchikaPannel4', 200, 900)
	addLuaSprite('itsu', true)
	setObjectCamera('itsu', 'other')

	setProperty('JukeBoxTag.alpha', 0)
	setProperty('JukeBox.alpha', 0)
	setProperty('JukeBoxText.alpha', 0)
	setProperty('JukeBoxSubText.alpha', 0)
end

function onBeatHit()
	if curBeat == 335 then
		doTweenY('scene1', 'itsu', 200, 1, 'cubeOut')
	end
	if curBeat == 339 then
		doTweenY('scene2', 'yot', 200, 1, 'cubeOut')
	end
	if curBeat == 343 then
		doTweenY('scene3', 'miku', 200, 1, 'cubeOut')
	end
	if curBeat == 347 then
		doTweenY('scene4', 'nino', 50, 1, 'cubeOut')
	end
	if curBeat == 352 then
		removeLuaSprite('nino')
		removeLuaSprite('miku')
		removeLuaSprite('yot')
		removeLuaSprite('itsu')
	end
end
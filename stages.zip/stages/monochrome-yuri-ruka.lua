function onCreate()

	makeLuaSprite('bg', 'badEnding/ClosetBG', 3676, 688)

	setObjectOrder('bg', 1)
	scaleObject('bg', 1.8, 1.8)

	addLuaSprite('bg', true)

	
	


	setProperty('camHUD.alpha', 0.90);
	setProperty('skipCountdown', true);
	setProperty('cameraSpeed', 10);
	setPropertyFromClass('FlxTransitionableState', 'skipNextTransIn', true);
	setPropertyFromClass('FlxTransitionableState', 'skipNextTransOut', true);
	changeAssets(false);

    --PRECACHE
	addCharacterToList('yuri-closeup', 'dad');

end

function onStepHit()
	if curStep == 128 then
	changeAssets(true);
	end
	if curStep == 190 then
	   doTweenY('dadTweenEvent', 'boyfriend', 1625, 0.5, 'linear');
	end
	if curStep == 1664 then
	setProperty('cameraSpeed', 1.25);
	setProperty('defaultCamZoom', 0.7);
	end
end

function hideArrows()
	setPropertyFromGroup('opponentStrums',0,'alpha','0')
	setPropertyFromGroup('opponentStrums',1,'alpha','0')
	setPropertyFromGroup('opponentStrums',2,'alpha','0')
	setPropertyFromGroup('opponentStrums',3,'alpha','0')
end

function changeAssets(x)
	hideArrows();
	setProperty('camHUD.visible', x);
end
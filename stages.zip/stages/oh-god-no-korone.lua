function onCreate()
	makeLuaSprite('bg', 'doog/room_MarioMadnessPoster', -1050, -350);
	setScrollFactor('bg', 1, 1);
	scaleObject('bg', 0.75, 0.75);
	addLuaSprite('bg', false);

	makeLuaSprite('intro', '', -10000, -210)
    makeGraphic('intro', 12800, 12000, '000000')
    addLuaSprite('intro', true)

	makeLuaSprite('kone', 'doog/KoroneAngry1', 0, 750);
	scaleObject('kone', 1.3, 1.3)
	setObjectCamera('kone', 'camHUD')
	addLuaSprite('kone', false);

	makeLuaText('hell', "Go to hell!", 0, 400, 200);
	setTextSize('hell', 120);
	setTextFont('hell', 'Krungthep.ttf')
	setObjectCamera('hell', 'other');
	setTextColor('hell', 'FFFFFF')
	addLuaText('hell');
	setProperty('hell.alpha', 0)

	makeLuaText('hell2', "GO TO HELL!!!", 0, 400, 400);
	setTextSize('hell2', 125);
	setTextFont('hell2', 'Krungthep.ttf')
	setObjectCamera('hell2', 'other');
	setTextColor('hell2', 'FFFFFF')
	addLuaText('hell2');
	setProperty('hell2.alpha', 0)

	makeLuaText('myside', "You haven't noticed yet?\nI always have you right next to me", 0, -7, 250);
	setTextSize('myside', 65);
	setTextFont('myside', 'Krungthep.ttf')
	setObjectCamera('myside', 'other');
	setTextColor('myside', 'FFFFFF')
	screenCenter('myside', 'x')
	addLuaText('myside');
	setProperty('myside.alpha', 0)

addLuaScript('extra_scripts/OhKoroneNo_vid')
addLuaScript('extra_scripts/Holofunk-hud', false)


precacheImage('ready_holo')
	precacheImage('set_holo')
	precacheImage('go_holo')
	makeLuaSprite('two', 'ready_holo', 0, 0)
	scaleObject('two', 0.7, 0.7)
	screenCenter('two', 'xy')
	setObjectCamera('two', 'other')
	makeLuaSprite('one', 'set_holo', 0, 0)
	scaleObject('one', 0.7, 0.7)
	screenCenter('one', 'xy')
	setObjectCamera('one', 'other')
	makeLuaSprite('go', 'go_holo', 0, 0)
	scaleObject('go', 0.7, 0.7)
	screenCenter('go', 'xy')
	setObjectCamera('go', 'other')
	
	setProperty('introSoundsSuffix', '-hf')

end


function onCountdownTick(counter)
	if counter == 1 then
		setProperty('countdownReady.visible', false)
		addLuaSprite('two')
		doTweenAlpha('fadeReady', 'two', 0, 0.5, 'quarterOut')
	elseif counter == 2 then
		setProperty('countdownSet.visible', false)
		addLuaSprite('one')
		doTweenAlpha('fadeSet', 'one', 0, 0.5, 'quarterOut')
	elseif counter == 3 then
		setProperty('countdownGo.visible', false)
		addLuaSprite('go')
		doTweenAlpha('fadeGo', 'go', 0, 0.5, 'quarterOut')
	end
end

function onStartCountdown()
	setProperty('camHUD.alpha', 0)
	setProperty('gf.alpha', 0)
end

function onStepHit()
	if curStep == 8 then
		setProperty('intro.alpha', 0)
		setProperty('camHUD.alpha', 1)
	end
end
	
function onBeatHit()
	if curBeat == 168 then
		setProperty('bg.visible', false)
		doTweenAlpha('miomama', 'gf', 1, 10.5, 'cubeIn')
	end
	if curBeat == 199 then
		doTweenAlpha('byemion', 'gf', 0, 0.7, 'linear')
	end
	if curBeat == 200 then
		setProperty('bg.visible', true)
	end
	if curBeat == 296 then
		doTweenAlpha('introagain', 'intro', 1, 1.5, 'quintOut')
	end
	if curBeat == 304 then
		doTweenY('angykone', 'kone', 90, 1, 'circOut')
	end
	if curBeat == 305 then
		doTweenAlpha('text1hi', 'hell', 1, 0.7, 'linear')
	end
	if curBeat == 308 then
		doTweenAlpha('text2hi', 'hell2', 1, 0.7, 'linear')
	end
	if curBeat == 309 then
		playSound('KoroneChainsawSFX', 1)
	end
	if curBeat == 312 then
		setProperty('hell.alpha', 0)
		setProperty('hell2.alpha', 0)
		setProperty('intro.alpha', 0)
		setProperty('kone.alpha', 0)
	end
	if curBeat == 343 then
		doTweenAlpha('endingsong', 'intro', 1, 0.6, 'quintIn')
		doTweenAlpha('yandereKorone', 'myside', 1, 0.7, 'quintIn')
	end
	if curBeat == 344 then
		doTweenAlpha('byehud', 'camHUD', 0, 0.25, 'linear')
	end
	if curBeat == 353 then
		doTweenAlpha('last2', 'myside', 0, 0.5, 'linear')
	end
end

function onCreate()

	precacheImage('City_night_bg')

	makeLuaSprite('stageback', 'City_night_bg', 0, 170);
	scaleObject('stageback', 3.25, 3.25)
	
	--setProperty('stageback.antialiasing', false)

	addLuaSprite('stageback', false);
end

function onUpdate()
	cameraSetTarget('dad')
	setProperty('trailDad.visible', false)
end

function onStartCountdown()
	doTweenColor('dacolorxd', 'dad', '9F4EC8', 0.0000001, 'linear')
end
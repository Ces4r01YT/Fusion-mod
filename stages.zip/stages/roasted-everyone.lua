﻿function onCreate()
	precacheImage('PIXEL_NOTE_assets');
	addCharacterToList('sayori', 'gf');
	addCharacterToList('azuri-panda', 'dad');
	addCharacterToList('takamori-christmas', 'dad');
	addCharacterToList('suyen-player', 'boyfriend');
	addCharacterToList('okayu', 'gf');
	addCharacterToList('aloe-christmas', 'boyfriend');
	addCharacterToList('kizuna-ai-closeup', 'dad');
	addCharacterToList('shirakami-fubuki-player', 'boyfriend');
	addCharacterToList('nino', 'dad');
	addCharacterToList('korone-fw-rival', 'dad');
	addCharacterToList('monika-pixel', 'dad');
	addCharacterToList('natsuki', 'dad');
	addCharacterToList('mako7w7', 'gf');
	addCharacterToList('bf-pixel-offset', 'bf');
	addCharacterToList('rem-ram-duet', 'dad');
	addCharacterToList('itsuki-player', 'bf');
	addCharacterToList('ichika-player', 'bf');
	

	-- background shit
	makeLuaSprite('MainBG', 'stage festival/MainBG', -700, -490);
	setLuaSpriteScrollFactor('MainBG', 1, 0.9);
    scaleObject('MainBG', 1.6, 1.6);
	addLuaSprite('MainBG', false)


	makeLuaSprite('pixel', 'stage festival/MainBGpixel', -700, -430);
	setLuaSpriteScrollFactor('pixel', 1, 0.9);
    scaleObject('pixel', 1.6, 1.6);
	addLuaSprite('pixel', false)

	setProperty('pixel.visible', false);

end

function onUpdate(elapsed)
    --Change To Pixel
	if curStep == 1696 then
		setProperty('pixel.visible', true);
		setProperty('MainBG.visible', false);

	    for i=0,4,1 do
		    setPropertyFromGroup('opponentStrums', i, 'texture', 'PIXEL_NOTE_assets');
		    setPropertyFromGroup('playerStrums', i, 'texture', 'PIXEL_NOTE_assets');
	    end
	end

	if curStep == 1680 then --This one MUST be at least 16 or 32 steps earlier (depends of the version of Psych Engine)
        for i = 0, getProperty('unspawnNotes.length')-1 do
		    setPropertyFromGroup('unspawnNotes', i, 'texture', 'PIXEL_NOTE_assets');
        end
	end
	--Back to normal
	if curStep == 1824 then
		setProperty('pixel.visible', false);
		setProperty('MainBG.visible', true);

	    for i=0,4,1 do
		    setPropertyFromGroup('opponentStrums', i, 'texture', 'NOTE_assets');
		    setPropertyFromGroup('playerStrums', i, 'texture', 'NOTE_assets');
	    end
	end

	if curStep == 1808 then --This one MUST be at least 16 or 32 steps earlier (depends of the version of Psych Engine)
        for i = 0, getProperty('unspawnNotes.length')-1 do
		    setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets');
        end
	end
end